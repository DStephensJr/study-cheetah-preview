import{A as e,B as t,C as n,D as r,E as i,G as a,I as o,J as s,K as c,M as l,P as u,Q as d,T as f,V as p,W as m,X as h,Y as g,Z as _,a as v,at as y,b,c as x,ct as S,d as C,f as w,g as T,j as E,k as D,l as O,m as k,n as A,nt as j,o as M,ot as N,p as P,q as F,r as I,rt as L,s as R,st as z,u as B,ut as V,w as H,x as U,y as W}from"../chunks/Bqz_OlNm.js";import"../chunks/ovXPNC-9.js";import"../chunks/YrkHVkuo.js";import"../chunks/xihTtKlq.js";import"../chunks/DCqvNbpo.js";import{n as ee}from"../chunks/CTtTt3_r.js";import{n as te}from"../chunks/D-OvkmzJ.js";import{n as ne,o as re,r as ie,t as G}from"../chunks/EfuZgBKj.js";import{t as ae}from"../chunks/DtorvwVv.js";import{a as oe,i as se,n as ce,r as le,t as ue}from"../chunks/Ck9DGmi7.js";import{_ as de,a as fe,b as pe,c as me,d as he,f as ge,g as K,h as _e,i as ve,l as ye,m as be,n as q,o as J,p as xe,r as Se,s as Y,t as Ce,u as we,v as Te,y as Ee}from"../chunks/C1kottxQ.js";import{n as De}from"../chunks/B800OebF.js";var X=V({load:()=>Oe}),Oe=async()=>({readyToRender:!0}),ke=i(`<button class="chapter-toggle svelte-1e78rkn" type="button"><svg aria-hidden="true" viewBox="0 0 20 20"><path d="m7 4 6 6-6 6"></path></svg></button>`),Ae=i(`<div><!></div>`),Z=i(`<li><div class="chapter-row svelte-1e78rkn"><button><span class="chapter-number svelte-1e78rkn"> </span> <span class="chapter-label svelte-1e78rkn"> </span></button> <!></div> <!></li>`),je=i(`<ol class="chapter-entries svelte-1e78rkn"></ol>`),Me=i(`<button class="close-button svelte-1e78rkn" aria-label="Close reader">✕</button>`),Ne=i(`<p class="chapter-title svelte-1e78rkn"> </p>`),Q=i(`<button class="features-button svelte-1e78rkn" type="button" aria-label="Book enhancements">Features</button>`),$=i(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">View</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reading view"><option>Vertical scroll</option><option>Single page</option><option>Facing pages</option><option>Best fit</option></select></label>`),Pe=i(`<div class="header-content controls-mode svelte-1e78rkn"><!> <button class="menu-button svelte-1e78rkn" type="button" aria-label="Chapter menu" aria-controls="chapter-menu" title="Chapter menu">☰</button> <div class="header-text svelte-1e78rkn"><h1 class="book-title svelte-1e78rkn"> </h1> <!></div> <div class="header-settings svelte-1e78rkn"><!> <!> <!> <!></div> <!></div>`),Fe=i(`<div class="header-content passive-mode svelte-1e78rkn"><div class="passive-header-text svelte-1e78rkn"><p class="book-title svelte-1e78rkn"> </p> <!></div></div>`),Ie=i(`<div class="chapter-menu svelte-1e78rkn" id="chapter-menu"><div class="chapter-menu-header svelte-1e78rkn"><h2 class="svelte-1e78rkn">Chapters</h2> <button class="close-menu svelte-1e78rkn" type="button" aria-label="Close menu">✕</button></div> <nav class="chapter-list svelte-1e78rkn" aria-label="Table of contents"><!></nav></div>`),Le=i(`<header tabindex="-1"><!> <!></header>`);function Re(e,r){L(r,!0);let i=(e,o=S,s)=>{let c=_(()=>z(s?.(),``));var f=je();W(f,23,o,e=>e.id,(e,o,s)=>{let f=d(()=>r.chapters.findIndex(e=>e.id===u(o).id)),p=d(()=>`${u(c)}${u(s)+1}`);var m=Z(),h=a(m),_=a(h);let v;var y=a(_),x=a(y,!0);N(y);var S=F(y,2),C=a(S,!0);N(S),N(_);var w=F(_,2),T=e=>{var n=ke(),r=a(n);let i;N(n),t((e,t,a)=>{O(n,`aria-label`,e),O(n,`aria-expanded`,t),O(n,`aria-controls`,`chapter-children-${u(f)}`),n.disabled=l(),i=k(r,0,`svelte-1e78rkn`,null,i,a)},[()=>`${u(b).includes(u(o).id)?`Collapse`:`Expand`} ${u(o).label}`,()=>u(b).includes(u(o).id),()=>({expanded:u(b).includes(u(o).id)})]),E(`click`,n,()=>{g(b,u(b).includes(u(o).id)?u(b).filter(e=>e!==u(o).id):[...u(b),u(o).id],!0)}),H(e,n)};U(w,e=>{u(o).subitems?.length&&e(T)}),N(h);var D=F(h,2),A=e=>{var n=Ae();i(a(n),()=>u(o).subitems,()=>`${u(p)}.`),N(n),t(e=>{O(n,`id`,`chapter-children-${u(f)}`),O(n,`hidden`,e)},[()=>!u(b).includes(u(o).id)]),H(e,n)};U(D,e=>{u(o).subitems?.length&&e(A)}),N(m),t(()=>{v=k(_,1,`chapter-item svelte-1e78rkn`,null,v,{active:u(f)===r.currentChapterIndex}),O(_,`aria-current`,u(f)===r.currentChapterIndex?`location`:void 0),_.disabled=l(),n(x,u(p)),n(C,u(o).label)}),E(`click`,_,()=>{r.onChapterSelect(u(f)),r.onChapterMenuChange(!1)}),H(e,m)}),N(f),H(e,f)},o=v(r,`embedded`,3,!1),c=v(r,`readerTheme`,3,`inherit`),l=v(r,`busy`,3,!1),f=v(r,`settingsOpen`,3,!1),p=v(r,`immersive`,3,!1),m=te(),y=d(()=>m.secure&&!m.installed&&!!m.prompt),b=h(s([])),x=d(()=>{let e=new Set(r.chapters.flatMap(e=>e.subitems?.map(e=>e.id)??[]));return r.chapters.filter(t=>!e.has(t.id))});function T(e){return e.subitems?.some(e=>e.id===r.chapters[r.currentChapterIndex]?.id||T(e))??!1}function D(){r.chapterMenuOpen||g(b,[...new Set([...u(b),...r.chapters.filter(T).map(e=>e.id)])],!0),r.onChapterMenuChange(!r.chapterMenuOpen)}var A=Le();let M;var P=a(A),I=e=>{var i=Pe(),s=a(i),h=e=>{var t=Me();E(`click`,t,function(...e){r.onClose?.apply(this,e)}),H(e,t)};U(s,e=>{r.onClose&&e(h)});var g=F(s,2),_=F(g,2),v=a(_),b=a(v,!0);N(v);var x=F(v,2),S=e=>{var i=Ne(),o=a(i,!0);N(i),t(()=>n(o,r.chapterTitle)),H(e,i)};U(x,e=>{r.chapterTitle&&e(S)}),N(_);var T=F(_,2),k=a(T),A=e=>{var t=Q();E(`click`,t,function(...e){r.onFeatures?.apply(this,e)}),H(e,t)};U(k,e=>{r.onFeatures&&e(A)});var j=F(k,2),M=e=>{var n=$(),i=F(a(n),2),o=a(i);o.value=o.__value=`scroll`;var s=F(o);s.value=s.__value=`single`;var c=F(s);c.value=c.__value=`spread`;var u=F(c);u.value=u.__value=`best-fit`,N(i);var d;C(i),N(n),t(()=>{i.disabled=l(),d!==(d=r.displayMode)&&(i.value=(i.__value=r.displayMode)??``,w(i,r.displayMode))}),E(`change`,i,e=>{let t=e.currentTarget.value;(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)&&r.onDisplayModeChange?.(t)}),H(e,n)};U(j,e=>{r.displayMode&&r.onDisplayModeChange&&e(M)});var P=F(j,2),I=e=>{le(e,{get settingsOpen(){return f()}})};U(P,e=>{o()&&e(I)});var L=F(P,2),R=e=>{{let t=d(()=>o()&&!u(y)&&!m.installed);se(e,{get open(){return f()},get onOpenChange(){return r.onSettingsOpenChange},get bookTheme(){return c()},get onBookThemeChange(){return r.onReaderThemeChange},get disabled(){return l()},get showInstallHelp(){return u(t)},get installSecure(){return m.secure}})}};U(L,e=>{r.onReaderThemeChange&&r.onSettingsOpenChange&&e(R)}),N(T);var z=F(T,2),B=e=>{oe(e,{get immersive(){return p()},get disabled(){return l()},get onclick(){return r.onImmersiveChange}})};U(z,e=>{r.onImmersiveChange&&e(B)}),N(i),t(()=>{O(g,`aria-expanded`,r.chapterMenuOpen),g.disabled=l(),n(b,r.bookTitle)}),E(`click`,g,D),H(e,i)},R=e=>{var i=Fe(),o=a(i),s=a(o),c=a(s,!0);N(s);var l=F(s,2),u=e=>{var i=Ne(),o=a(i,!0);N(i),t(()=>n(o,r.chapterTitle)),H(e,i)};U(l,e=>{r.chapterTitle&&e(u)}),N(o),N(i),t(()=>n(c,r.bookTitle)),H(e,i)};U(P,e=>{r.controlsVisible?e(I):e(R,-1)});var B=F(P,2),V=e=>{var t=Ie(),n=a(t),o=F(a(n),2);N(n);var s=F(n,2);i(a(s),()=>u(x)),N(s),N(t),E(`click`,o,()=>r.onChapterMenuChange(!1)),H(e,t)};U(B,e=>{r.controlsVisible&&r.chapterMenuOpen&&e(V)}),N(A),t(()=>M=k(A,1,`reading-header svelte-1e78rkn`,null,M,{"controls-visible":r.controlsVisible,embedded:o()})),H(e,A),j()}e([`click`,`change`]);function ze(e){let t=e-1;return t*t*t+1}function Be(e){let t=typeof e==`string`&&e.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);return t?[parseFloat(t[1]),t[2]||`px`]:[e,`px`]}function Ve(e,{delay:t=0,duration:n=400,easing:r=ze,x:i=0,y:a=0,opacity:o=0}={}){let s=getComputedStyle(e),c=+s.opacity,l=s.transform===`none`?``:s.transform,u=c*(1-o),[d,f]=Be(i),[p,m]=Be(a);return{delay:t,duration:n,easing:r,css:(e,t)=>`
			transform: ${l} translate(${(1-e)*d}${f}, ${(1-e)*p}${m});
			opacity: ${c-u*t}`}}var He=i(`<div role="group"><div class="popup-heading svelte-4847e9"><span> </span> <output> </output></div> <div class="adjustment-row svelte-4847e9"><button class="adjust-button svelte-4847e9" type="button">-</button> <input type="range" class="svelte-4847e9"/> <button class="adjust-button svelte-4847e9" type="button">+</button></div></div>`);function Ue(e,r){L(r,!0);let i=v(r,`align`,3,`left`),o=h(null),s=null,c=d(()=>u(o)??r.value);function f(e){g(o,e,!0),r.onPreview?.(e)}function p(e){e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),r.onEscape())}A(()=>r.onPreview?.(null));var m=He();let _;var y=a(m),b=a(y),S=a(b,!0);N(b);var C=F(b,2),w=a(C,!0);N(C),N(y);var T=F(y,2),D=a(T),M=F(D,2);x(M);var P=F(M,2);N(T),N(m),t((e,t)=>{_=k(m,1,`adjustment-popup svelte-4847e9`,null,_,{"align-right":i()===`right`,"align-center":i()===`center`}),O(m,`id`,r.id),O(m,`aria-label`,`${r.label} adjustment`),n(S,r.label),n(w,e),O(D,`aria-label`,r.decreaseLabel),D.disabled=r.disabled||r.decreaseDisabled,O(M,`min`,r.min),O(M,`max`,r.max),O(M,`step`,r.step),B(M,u(c)),O(M,`aria-label`,r.label),O(M,`aria-valuetext`,t),M.disabled=r.disabled,O(P,`aria-label`,r.increaseLabel),P.disabled=r.disabled||r.increaseDisabled},[()=>r.format(u(c)),()=>r.valueText(u(c))]),E(`click`,D,function(...e){r.onDecrease?.apply(this,e)}),E(`keydown`,D,p),E(`pointerdown`,M,e=>{s=e.currentTarget.valueAsNumber}),E(`input`,M,e=>{f(e.currentTarget.valueAsNumber)}),E(`pointerup`,M,e=>{e.currentTarget.valueAsNumber===s&&f(null),s=null}),l(`pointercancel`,M,()=>{s=null,f(null)}),E(`change`,M,async e=>{try{await r.onChange(e.currentTarget.valueAsNumber)}finally{f(null)}}),E(`keydown`,M,p),E(`click`,P,function(...e){r.onIncrease?.apply(this,e)}),E(`keydown`,P,p),H(e,m),j()}e([`click`,`keydown`,`pointerdown`,`input`,`pointerup`,`change`]);var We=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><text x="1" y="21" font-size="21" class="svelte-5cwycy">A</text><text x="19" y="21" font-size="13" class="svelte-5cwycy">A</text></svg>`),Ge=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><path d="M5 3v18M2 6l3-3 3 3M2 18l3 3 3-3M13 4h16M13 9h16M13 15h16M13 20h16" class="svelte-5cwycy"></path></svg>`),Ke=i(`<div class="typography-control reader-adjustment-control svelte-5cwycy"><button class="control-button typography-trigger svelte-5cwycy" type="button"><!></button> <!></div>`);function qe(e,n){L(n,!0);let r,i=d(()=>n.kind===`font-size`?`Font size`:`Line height`),o=d(()=>`reader-${n.kind}-popup`);function s(e){n.open&&(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),n.onClose(),r.focus())}function c(e){n.onChange(Math.min(n.max,Math.max(n.min,Math.round((n.value+e)*100)/100)))}var l=Ke(),f=a(l),p=a(f),m=e=>{H(e,We())},h=e=>{H(e,Ge())};U(p,e=>{n.kind===`font-size`?e(m):e(h,-1)}),N(f),M(f,e=>r=e,()=>r);var g=F(f,2),_=e=>{{let t=d(()=>`Decrease ${u(i).toLowerCase()}`),r=d(()=>`Increase ${u(i).toLowerCase()}`),a=d(()=>n.value<=n.min),l=d(()=>n.value>=n.max),f=d(()=>n.kind===`line-height`?`right`:`left`);Ue(e,{get id(){return u(o)},get label(){return u(i)},get value(){return n.value},get min(){return n.min},get max(){return n.max},step:.01,format:e=>`${e.toFixed(2)}x`,valueText:e=>`${e.toFixed(2)} times`,get decreaseLabel(){return u(t)},get increaseLabel(){return u(r)},get disabled(){return n.disabled},get decreaseDisabled(){return u(a)},get increaseDisabled(){return u(l)},get align(){return u(f)},onDecrease:()=>c(-.1),onIncrease:()=>c(.1),get onChange(){return n.onChange},onEscape:()=>s()})}};U(g,e=>{n.open&&e(_)}),N(l),t(()=>{O(f,`aria-label`,u(i)),O(f,`aria-expanded`,n.open),O(f,`aria-controls`,n.open?u(o):void 0),O(f,`title`,u(i)),f.disabled=n.disabled}),E(`click`,f,function(...e){n.onToggle?.apply(this,e)}),E(`keydown`,f,s),H(e,l),j()}e([`click`,`keydown`]);var Je=i(`<p class="activity-announcement svelte-1tz9bb9" role="status" aria-live="polite"> </p>`),Ye=i(`<div class="control-group line-height-controls svelte-1tz9bb9"><!></div>`),Xe=i(`<div class="footer-content controls-mode svelte-1tz9bb9"><!> <div class="control-group font-controls svelte-1tz9bb9"><!></div> <div class="control-group progress-controls svelte-1tz9bb9"><div class="progress-slider reader-adjustment-control svelte-1tz9bb9"><div class="progress-thumb-focus svelte-1tz9bb9"><button class="progress-thumb svelte-1tz9bb9" type="button"> </button></div> <!></div></div> <!></div>`),Ze=i(`<p class="activity-footer-status svelte-1tz9bb9" role="status" aria-live="polite"><span class="activity-status-full svelte-1tz9bb9"> </span> <span class="activity-status-compact svelte-1tz9bb9" aria-hidden="true"> </span> <span class="activity-announcement svelte-1tz9bb9"> </span></p>`),Qe=i(`<span class="progress-compact svelte-1tz9bb9" aria-hidden="true"> </span>`),$e=i(`<button type="button" class="activity-footer-button svelte-1tz9bb9"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="svelte-1tz9bb9"><path></path></svg> <span class="svelte-1tz9bb9"> </span></button>`),et=i(`<div class="activity-footer-actions svelte-1tz9bb9"></div>`),tt=i(`<div><div><!> <p class="passive-footer-metric svelte-1tz9bb9"><span class="progress-full svelte-1tz9bb9"> </span> <!></p> <!></div></div>`),nt=i(`<button class="crossword-hint svelte-1tz9bb9" type="button" aria-live="polite" aria-label="Dismiss keyboard hint: Hold a plus-marked key or its physical equivalent for diacritics."><span>Hold a + key or its physical equivalent for diacritics. Tap to dismiss.</span></button>`),rt=i(`<footer><!> <!></footer>`);function it(e,r){L(r,!0);let i=v(r,`lineHeight`,3,1),o=v(r,`chapterPositionLabel`,3,void 0),s=v(r,`previousPageDisabled`,3,!1),c=v(r,`nextPageDisabled`,3,!1),f=v(r,`chapterMenuOpen`,3,!1),_=v(r,`openControl`,15,null),y=v(r,`busy`,3,!1),b=h(null),x=h(void 0),S=h(void 0),C,w=d(()=>u(b)??r.progressPercent);function D(e){_(_()===e?null:e),_()&&r.onAdjustmentOpen?.()}function A(e){_()&&e.target instanceof Element&&!e.target.closest(`.reader-adjustment-control`)&&_(null)}function P(e){(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),_(null),u(x)?.focus())}p(()=>{(!r.controlsVisible||f())&&_(null)});function I(e){document.activeElement===u(S)&&C.querySelector(`.activity-footer-button:not(:disabled), .progress-thumb:not(:disabled)`)?.focus(),r.onDismissCrosswordHint?.(e)}p(()=>{let e=r.crosswordHintKey;if(!e)return;let t=window.setTimeout(()=>I(e),9e4);return()=>window.clearTimeout(t)});var R=rt();l(`pointerdown`,m,A),l(`blur`,m,()=>_(null));let z;var B=a(R),V=e=>{var l=Xe(),f=a(l),p=e=>{var i=Je(),o=a(i);N(i),t(()=>n(o,`${r.activityFooter.status??``} ${r.activityFooter.announcement??``}`)),H(e,i)};U(f,e=>{r.activityFooter&&e(p)});var m=F(f,2),h=a(m);{let e=d(()=>_()===`font-size`);qe(h,{kind:`font-size`,get value(){return r.fontSize},min:.75,max:2,get open(){return u(e)},get disabled(){return y()},onToggle:()=>D(`font-size`),onClose:()=>_(null),get onChange(){return r.onFontSizeChange}})}N(m);var v=F(m,2),S=a(v),C=a(S),T=a(C),k=a(T);N(T),M(T,e=>g(x,e),()=>u(x)),N(C);var A=F(C,2),j=e=>{{let t=d(()=>y()||!r.onProgressChange),n=d(()=>!r.onPreviousPage||s()),i=d(()=>!r.onNextPage||c());Ue(e,{id:`reader-progress-popup`,label:`Reading position`,get value(){return r.progressPercent},min:0,max:100,step:1,align:`center`,format:e=>`${Math.round(e)}%`,valueText:e=>`${Math.round(e)}% of book`,decreaseLabel:`Previous page`,increaseLabel:`Next page`,get disabled(){return u(t)},get decreaseDisabled(){return u(n)},get increaseDisabled(){return u(i)},onDecrease:()=>r.onPreviousPage?.(),onIncrease:()=>r.onNextPage?.(),onChange:e=>r.onProgressChange?.(e),onPreview:e=>g(b,e,!0),onEscape:()=>P()})}};U(A,e=>{_()===`progress`&&e(j)}),N(S),N(v);var I=F(v,2),L=e=>{var t=Ye(),n=a(t);{let e=d(()=>_()===`line-height`);qe(n,{kind:`line-height`,get value(){return i()},min:1,max:2,get open(){return u(e)},get disabled(){return y()},onToggle:()=>D(`line-height`),onClose:()=>_(null),get onChange(){return r.onLineHeightChange}})}N(t),H(e,t)};U(I,e=>{r.onLineHeightChange&&e(L)}),N(l),t((e,t)=>{O(S,`title`,`${o()??`${r.currentChapterIndex+1} / ${r.totalChapters}`}: ${r.pageLabel}`),O(T,`aria-label`,e),O(T,`aria-expanded`,_()===`progress`),O(T,`aria-controls`,_()===`progress`?`reader-progress-popup`:void 0),T.disabled=y()||!r.onProgressChange,n(k,`${t??``}%`)},[()=>`Reading position, ${Math.round(u(w))}% of book`,()=>Math.round(u(w))]),E(`click`,T,()=>D(`progress`)),E(`keydown`,T,P),H(e,l)},ee=e=>{var i=tt();let o;var s=a(i);let c;var l=a(s),d=e=>{var i=Ze(),o=a(i),s=a(o,!0);N(o);var c=F(o,2),l=a(c,!0);N(c);var u=F(c,2),d=a(u,!0);N(u),N(i),t(()=>{n(s,r.activityFooter.status),n(l,r.activityFooter.compactStatus),n(d,r.activityFooter.announcement)}),H(e,i)};U(l,e=>{r.activityFooter&&e(d)});var f=F(l,2),p=a(f),m=a(p,!0);N(p);var h=F(p,2),g=e=>{var i=Qe(),o=a(i);N(i),t(()=>n(o,`${r.progressPercent??``}%`)),H(e,i)};U(h,e=>{r.activityFooter&&e(g)}),N(f);var _=F(f,2),v=e=>{var i=et();W(i,21,()=>r.activityFooter.buttons,e=>e.label,(e,r)=>{var i=$e(),o=a(i),s=a(o);N(o);var c=F(o,2),l=a(c,!0);N(c),N(i),t(()=>{O(i,`aria-label`,u(r).label),O(i,`aria-pressed`,u(r).pressed),i.disabled=u(r).disabled,O(s,`d`,u(r).path),n(l,u(r).text)}),E(`click`,i,function(...e){u(r).action?.apply(this,e)}),H(e,i)}),N(i),H(e,i)};U(_,e=>{r.activityFooter&&e(v)}),N(s),N(i),t(()=>{o=k(i,1,`footer-content passive-mode svelte-1tz9bb9`,null,o,{"activity-mode":!!r.activityFooter,"keyboard-mode":r.activityFooter?.buttons.length===4}),c=k(s,1,`passive-footer-shell svelte-1tz9bb9`,null,c,{"activity-footer-shell":!!r.activityFooter}),n(m,r.progressLabel)}),H(e,i)};U(B,e=>{r.controlsVisible?e(V):e(ee,-1)});var te=F(B,2),ne=e=>{var t=nt();M(t,e=>g(S,e),()=>u(S)),E(`click`,t,()=>r.crosswordHintKey&&I(r.crosswordHintKey)),T(2,t,()=>Ve,()=>({y:60,duration:window.matchMedia(`(prefers-reduced-motion: reduce)`).matches?0:200})),H(e,t)};U(te,e=>{r.crosswordHintKey&&e(ne)}),N(R),M(R,e=>C=e,()=>C),t(()=>z=k(R,1,`reading-footer svelte-1tz9bb9`,null,z,{"controls-visible":r.controlsVisible})),H(e,R),j()}e([`click`,`keydown`]);var at=i(`<p class="chapter-title svelte-v52sy3"> </p>`),ot=i(`<p>Find the Greek words in any of eight directions, including backward. Grid letters omit accents and breathing marks.</p>`),st=i(`<p>Use the English clues to fill in the Greek words. Accents and breathing marks are not required.</p>`),ct=i(`<p>Write the English meaning and its letter beside each Greek word.</p>`),lt=i(`<td class="svelte-v52sy3"><span class="svelte-v52sy3"> </span></td>`),ut=i(`<tr></tr>`),dt=i(`<li class="svelte-v52sy3"> </li>`),ft=i(`<div class="word-search-layout svelte-v52sy3"><table class="word-search-grid svelte-v52sy3" lang="el" aria-label="Greek word search"><tbody></tbody></table> <section class="word-search-vocabulary svelte-v52sy3"><h2 class="svelte-v52sy3">Words to find</h2> <ul class="word-search-words svelte-v52sy3" lang="el"></ul></section></div>`),pt=i(`<li class="svelte-v52sy3"><strong> </strong> </li>`),mt=i(`<section><h2 class="svelte-v52sy3"> </h2> <ul class="svelte-v52sy3"></ul></section>`),ht=i(`<span class="svelte-v52sy3"> </span>`),gt=i(`<td class="crossword-cell svelte-v52sy3"></td>`),_t=i(`<td class="crossword-empty svelte-v52sy3"></td>`),vt=i(`<div class="crossword-layout svelte-v52sy3"><div class="crossword-clues svelte-v52sy3"></div> <table class="crossword-grid svelte-v52sy3" aria-label="Blank Greek crossword"><tbody></tbody></table></div>`),yt=i(`<li class="prompt-row svelte-v52sy3"><span class="greek-word svelte-v52sy3"> </span><span class="meaning-blank svelte-v52sy3"></span><span class="letter-box svelte-v52sy3"></span><span class="result-space"></span></li>`),bt=i(`<li class="choice-row svelte-v52sy3"><span class="choice-letter svelte-v52sy3"> </span><span> </span></li>`),xt=i(`<div class="matching-columns svelte-v52sy3"><section><h2 class="svelte-v52sy3">Greek words</h2><ul class="svelte-v52sy3"></ul></section> <section><h2 class="svelte-v52sy3">English meanings</h2><ul class="svelte-v52sy3"></ul></section></div>`),St=i(`<section class="worksheet-print svelte-v52sy3" aria-label="Printable worksheet"><!> <h1 class="svelte-v52sy3"> </h1> <!> <p>Name: ________________________ Date: ______________</p> <!></section>`);function Ct(e,r){L(r,!0);var i=St(),o=a(i),s=e=>{var i=at(),o=a(i,!0);N(i),t(()=>n(o,r.activity.chapterTitle)),H(e,i)};U(o,e=>{r.activity.chapterTitle&&e(s)});var l=F(o,2),d=a(l,!0);N(l);var p=F(l,2),m=e=>{H(e,ot())},h=e=>{H(e,st())},g=e=>{H(e,ct())};U(p,e=>{r.activity.kind===`word-search-v1`?e(m):r.activity.kind===`crossword-v1`?e(h,1):e(g,-1)});var _=F(p,4),v=e=>{var i=ft(),o=a(i),s=a(o);W(s,21,()=>r.activity.grid,b,(e,r)=>{var i=ut();W(i,21,()=>[...u(r)],b,(e,r)=>{var i=lt(),o=a(i),s=a(o,!0);N(o),N(i),t(()=>n(s,u(r))),H(e,i)}),N(i),H(e,i)}),N(s),N(o);var c=F(o,2),l=F(a(c),2);W(l,21,()=>r.activity.words,e=>e.id,(e,r)=>{var i=dt(),o=a(i,!0);N(i),t(()=>n(o,u(r).text)),H(e,i)}),N(l),N(c),N(i),H(e,i)},x=e=>{var i=vt(),o=a(i);W(o,20,()=>[`across`,`down`],b,(e,i)=>{var o=mt(),s=a(o),c=a(s,!0);N(s);var l=F(s,2);W(l,21,()=>r.activity.clues.filter(e=>e.direction===i),e=>e.id,(e,r)=>{var i=pt(),o=a(i),s=a(o);N(o);var c=F(o);N(i),t(()=>{n(s,`${u(r).number??``}.`),n(c,` ${u(r).text??``}`)}),H(e,i)}),N(l),N(o),t(()=>n(c,i===`across`?`Across`:`Down`)),H(e,o)}),N(o);var s=F(o,2),l=a(s);W(l,21,()=>r.activity.cells,b,(e,i,o)=>{var s=ut();W(s,21,()=>u(i),b,(e,i,s)=>{var l=f(),d=c(l),p=e=>{var i=gt();W(i,21,()=>r.activity.clues.filter(e=>e.row===o&&e.column===s).slice(0,1),b,(e,r)=>{var i=ht(),o=a(i,!0);N(i),t(()=>n(o,u(r).number)),H(e,i)}),N(i),H(e,i)},m=e=>{H(e,_t())};U(d,e=>{u(i)?e(p):e(m,-1)}),H(e,l)}),N(s),H(e,s)}),N(l),N(s),N(i),t(()=>O(s,`lang`,r.activity.language)),H(e,i)},S=e=>{var i=xt(),o=a(i),s=F(a(o));W(s,21,()=>r.activity.prompts,e=>e.id,(e,r)=>{var i=yt(),o=a(i),s=a(o,!0);N(o),y(3),N(i),t(()=>{O(o,`lang`,u(r).language),n(s,u(r).text)}),H(e,i)}),N(s),N(o);var c=F(o,2),l=F(a(c));W(l,23,()=>r.activity.choices,e=>e.id,(e,r,i)=>{var o=bt(),s=a(o),c=a(s,!0);N(s);var l=F(s),d=a(l,!0);N(l),N(o),t(e=>{n(c,e),O(l,`lang`,u(r).language),n(d,u(r).text)},[()=>de(u(i))]),H(e,o)}),N(l),N(c),N(i),H(e,i)};U(_,e=>{r.activity.kind===`word-search-v1`?e(v):r.activity.kind===`crossword-v1`?e(x,1):e(S,-1)}),N(i),t(()=>n(d,r.activity.title)),H(e,i),j()}var wt=i(`<li class="svelte-5ift61"><strong> </strong>: <!></li>`),Tt=i(`<p role="alert" class="svelte-5ift61"> </p>`),Et=i(`<button type="button" class="svelte-5ift61">Close without saving</button>`),Dt=i(`<dialog class="reader-feature-notice svelte-5ift61" aria-labelledby="reader-feature-title" aria-describedby="reader-feature-message"><h2 id="reader-feature-title" class="svelte-5ift61"> </h2> <p id="reader-feature-message" class="svelte-5ift61"> </p> <a target="_blank" rel="noopener noreferrer" class="svelte-5ift61">Visit Study Cheetah (opens in a new tab)</a> <h3 class="svelte-5ift61">Features requested by this book</h3> <ul class="svelte-5ift61"></ul> <p class="svelte-5ift61">Active means the reader's enhancement is enabled. Each activity is validated when opened.</p> <p class="svelte-5ift61">Unavailable enhancements keep their ordinary book content. This link opens the reader website; it does not upload your book.</p> <label class="svelte-5ift61"><input type="checkbox" class="svelte-5ift61"/> Don't show this again for this book's current features</label> <!> <div class="actions svelte-5ift61"><!> <button type="button" class="svelte-5ift61">Continue reading</button></div></dialog>`);function Ot(e,r){L(r,!0);let i,o=h(!1),s=h(null),c=Se.getInstance();function l(e){console.error(`[Reader] Saving or loading enhancement notice preference failed:`,e),g(s,`Could not remember your notice preference: ${e instanceof Error?e.message:String(e)}`)}function f(){try{c.setReaderNoticeDismissed(r.capability,u(o)),g(s,null),i.close()}catch(e){l(e)}}I(()=>{try{g(o,c.isReaderNoticeDismissed(r.capability),!0)}catch(e){l(e)}r.onready(()=>{i.open||i.showModal()}),(u(s)||!u(o)&&r.capability.requested.some(e=>!r.capability.active.includes(e)))&&i.showModal()});var p=Dt(),m=a(p),_=a(m,!0);N(m);var v=F(m,2),b=a(v,!0);N(v);var S=F(v,2),C=F(S,4);W(C,20,()=>r.capability.requested,e=>e,(e,i)=>{var o=wt(),s=a(o),c=a(s,!0);N(s);var l=F(s,2),f=e=>{H(e,D(`Active`))},p=d(()=>r.capability.active.includes(i)),m=e=>{H(e,D(`Supported, not active`))},h=d(()=>r.capability.supported.includes(i)),g=e=>{H(e,D(`Not supported by this reader yet`))};U(l,e=>{u(p)?e(f):u(h)?e(m,1):e(g,-1)}),N(o),t(()=>n(c,i)),H(e,o)}),N(C);var w=F(C,6),T=a(w);x(T),y(),N(w);var k=F(w,2),A=e=>{var r=Tt(),i=a(r,!0);N(r),t(()=>n(i,u(s))),H(e,r)};U(k,e=>{u(s)&&e(A)});var P=F(k,2),z=a(P),B=e=>{var t=Et();E(`click`,t,()=>i.close()),H(e,t)};U(z,e=>{u(s)&&e(B)});var V=F(z,2);N(P),N(p),M(p,e=>i=e,()=>i),t(()=>{n(_,r.capability.notice.title),n(b,r.capability.notice.message),O(S,`href`,r.capability.notice.url)}),R(T,()=>u(o),e=>g(o,e)),E(`click`,V,f),H(e,p),j()}e([`click`]);var kt=`body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
  padding-block: 0.5rem;\r
}\r
[data-study-cheetah-enhanced="matching-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-height: 0;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced] > h1 { text-align: center; }\r
body > [data-study-cheetah-enhanced="matching-v1"] > h1 { margin-block-start: 0; }\r
[data-study-cheetah-enhanced="matching-v1"] [data-study-cheetah-matching-instructions] { display: none; }\r
[data-study-cheetah-enhanced] .matching-columns {\r
  display: grid;\r
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);\r
  gap: clamp(0.75em, 3vw, 2em);\r
  flex: 1 1 auto;\r
  min-height: 6em;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section {\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section > h2 { text-decoration: underline; }\r
[data-study-cheetah-enhanced] [data-matching-prompts],\r
[data-study-cheetah-enhanced] [data-matching-choices] {\r
  display: grid;\r
  reading-flow: grid-order;\r
  align-content: start;\r
  gap: 0.4em;\r
  min-height: 0;\r
  padding: 4px;\r
  margin: 0;\r
  list-style: none;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced] li {\r
  box-sizing: border-box;\r
  position: relative;\r
  min-height: 44px;\r
  padding: 0.35em;\r
  overflow-wrap: anywhere;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 1.8em 1em;\r
  align-items: center;\r
  gap: 0.4em;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li::before {\r
  content: none;\r
}\r
[data-study-cheetah-enhanced] .answer-blank {\r
  box-sizing: border-box;\r
  min-width: 1.6em;\r
  max-width: 3em;\r
  min-height: 1.6em;\r
  padding: 0 0.15em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  text-align: center;\r
  font-weight: bold;\r
  line-height: 1.5;\r
  background: var(--ui-control-bg, transparent);\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li {\r
  display: grid;\r
  grid-template-columns: 2em minmax(0, 1fr);\r
  align-items: center;\r
  column-gap: 2ch;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li::before {\r
  content: attr(data-choice-label);\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
  font-weight: bold;\r
  text-align: center;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] .answer-blank { display: none; }\r
[data-study-cheetah-enhanced] .answer-blank {\r
  white-space: normal;\r
  color: var(--reader-control-greek, var(--reader-matching-greek, var(--coloroldgreek, #0070c0)));\r
}\r
[data-study-cheetah-enhanced] .sc-match-answer { grid-column: 2; grid-row: 1; margin-inline-end: calc(2ch - 0.4em); }\r
[data-study-cheetah-enhanced] [data-matching-prompts] .answer-blank { grid-column: 3; grid-row: 1; }\r
[data-study-cheetah-enhanced] .sc-match-result { grid-column: 4; grid-row: 1; width: 1em; height: 1em; }\r
[data-study-cheetah-enhanced] .sc-match-result svg {\r
  width: 100%;\r
  height: 100%;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 3.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] [data-result="correct"] { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] [data-result="incorrect"] { color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced] .sc-match-answer { text-align: right; min-width: 0; border-bottom: 0; color: var(--reader-page-fg, inherit); }\r
[data-study-cheetah-enhanced] .sc-match-select {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  min-height: 0;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  color: var(--reader-page-fg, inherit);\r
  background: transparent;\r
}\r
[data-study-cheetah-enhanced] .sc-match-select[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); }\r
[data-study-cheetah-enhanced] ol:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] .sc-match-footer { flex: 0 0 auto; margin-top: 0.75em; font-size: 0.8em; }\r
[data-study-cheetah-enhanced] .sc-match-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer p { margin: 0; }\r
[data-study-cheetah-enhanced] .sc-match-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(6em, 1fr) minmax(0, max-content);\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced] .sc-match-status { min-width: 0; }\r
[data-study-cheetah-enhanced] .sc-match-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-match-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
body:has(> [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"]) {\r
padding-inline-end: 48px;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-match-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-match-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-match-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-match-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] .sc-match-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`,At=`[data-study-cheetah-enhanced] .worksheet-name { display: none; }\r
[data-study-cheetah-enhanced][data-sc-external-footer] :is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row) { display: none; }\r
[data-study-cheetah-enhanced] .sc-activity-error-panel {\r
  position: fixed;\r
  z-index: 20;\r
  inset: auto 16px 8px;\r
  max-height: min(50vh, 18em);\r
  overflow: auto;\r
  box-sizing: border-box;\r
  padding: 0.75em;\r
  border: 2px solid var(--ui-border-strong, currentColor);\r
  background: var(--ui-control-bg, #fff);\r
  color: var(--ui-control-fg, #000);\r
  font: 0.875rem/1.4 sans-serif;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-error-panel p { margin: 0 0 0.5em; overflow-wrap: anywhere; }\r
[data-study-cheetah-enhanced] .sc-activity-error-panel .sc-activity-button { min-width: 44px; }\r
[data-study-cheetah-enhanced] .sc-activity-button {\r
  box-sizing: border-box;\r
  min-height: 44px;\r
  padding: 0.3em 0.6em;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  font: inherit;\r
  font-weight: bold;\r
  color: inherit;\r
  background: var(--ui-control-bg, transparent);\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-check, .sc-crossword-check) {\r
  color: var(--reader-control-check, var(--reader-matching-correct, #166534));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-reset, .sc-word-search-reset, .sc-crossword-reset) {\r
  color: var(--reader-control-reset, var(--reader-matching-reset, #a84300));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-print, .sc-word-search-print, .sc-crossword-print) {\r
  color: var(--reader-control-print, #000);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:hover:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-hover, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:active:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-active, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:disabled { cursor: default; }\r
[data-study-cheetah-enhanced] .sc-activity-button:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 0.5em;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) svg {\r
  flex: 0 0 auto;\r
  width: 1.2em;\r
  height: 1.2em;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-status-compact { display: none; }\r
@media (max-width: 480px) {\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row) {\r
    grid-template-columns: minmax(0, 1fr) max-content;\r
  }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-status, .sc-word-search-status, .sc-crossword-status) {\r
    min-width: 0;\r
    overflow-x: auto;\r
    text-align: left;\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-full {\r
    position: absolute;\r
    width: 1px;\r
    height: 1px;\r
    overflow: hidden;\r
    clip-path: inset(50%);\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-compact { display: inline; }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) {\r
    flex-wrap: nowrap;\r
    justify-content: flex-end;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
    width: 44px;\r
    min-width: 44px;\r
    padding: 0;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button > span {\r
    display: none;\r
  }\r
}\r
@media print {\r
  .study-cheetah-activity-ui { display: none !important; }\r
}\r
`;function jt(e,t){let n=e.querySelector(`:is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row)`),r=n?.querySelector(`[role="status"]`),i=r?.querySelector(`.sc-activity-status-full`),a=r?.querySelector(`.sc-activity-status-compact`),o=r?.querySelector(`:is(.sc-match-announcement, .sc-word-search-announcement, .sc-crossword-announcement)`),s=n?[...n.querySelectorAll(`.sc-activity-button`)]:[];if(!n||!i||!a||!o||!s.length)throw Error(`Activity footer is unavailable.`);let c=()=>t({status:i.textContent??``,compactStatus:a.textContent??``,announcement:o.textContent??``,buttons:s.map(e=>{let t=e.getAttribute(`aria-label`),n=e.querySelector(`span`)?.textContent,r=e.querySelector(`svg path`)?.getAttribute(`d`);if(!t||!n||!r)throw Error(`Activity footer button is invalid.`);let i=e.getAttribute(`aria-pressed`);return{label:t,text:n,path:r,disabled:e.disabled,...i===null?{}:{pressed:i===`true`},action:()=>e.click()}})}),l=new MutationObserver(c);return l.observe(n,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:[`disabled`,`aria-pressed`]}),e.setAttribute(`data-sc-external-footer`,``),c(),()=>{l.disconnect(),e.removeAttribute(`data-sc-external-footer`)}}function Mt(e,t,n){let r=e.ownerDocument;e.setAttribute(`aria-label`,e.textContent),e.textContent=``;let i=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);i.setAttribute(`viewBox`,`0 0 24 24`),i.setAttribute(`aria-hidden`,`true`),i.setAttribute(`focusable`,`false`);let a=r.createElementNS(i.namespaceURI,`path`);a.setAttribute(`d`,n),i.append(a);let o=r.createElement(`span`);o.textContent=t,e.append(i,o)}function Nt(e,t){let n=e.ownerDocument,r=[];function i(e,t,n){let i=e.getAttribute(t);e.setAttribute(t,n),r.push(()=>{i===null?e.removeAttribute(t):e.setAttribute(t,i)})}function a(e,t,i){let a=n.createElement(t);return a.className=`study-cheetah-activity-ui ${i}`,e.append(a),r.push(()=>a.remove()),a}function o(e,t,n){let i=a(e,`button`,`sc-activity-button`);return i.type=`button`,i.textContent=t,i.addEventListener(`click`,n),r.push(()=>i.removeEventListener(`click`,n)),i}function s(){let t=a(e,`div`,`sc-activity-error-panel`),n=a(t,`p`,`sc-activity-error-message`);n.setAttribute(`role`,`alert`);let r=a(t,`p`,`sc-activity-save-status`);r.textContent=`Progress is not saved.`,o(t,`Dismiss warning`,()=>{t.hidden=!0}),t.hidden=!0;let i=-1;return(e,r)=>{r!==i&&(t.hidden=e===null,i=r),e===null&&(t.hidden=!0),n.textContent=e}}let c=window.matchMedia(`(orientation: portrait)`),l=n.defaultView.matchMedia(`(orientation: portrait)`),u=()=>{e.setAttribute(`data-study-cheetah-orientation`,c.matches||l.matches?`portrait`:`landscape`)};i(e,`data-study-cheetah-orientation`,`portrait`),u(),c.addEventListener(`change`,u),l.addEventListener(`change`,u),r.push(()=>{c.removeEventListener(`change`,u),l.removeEventListener(`change`,u)});let d=n.createElement(`style`);return d.textContent=`${At}\n${t}`,n.head.append(d),r.push(()=>d.remove()),{doc:n,cleanups:r,attribute:i,append:a,button:o,errorPanel:s}}function Pt(e,t,n){let{doc:r,cleanups:i,attribute:a,append:o,button:s,errorPanel:c}=Nt(e,kt),l=Se.getInstance(),u=[...e.querySelectorAll(`[data-matching-prompts] > li`)],d=[...e.querySelectorAll(`[data-matching-choices] > li`)],f=[...e.querySelectorAll(`[data-matching-prompts], [data-matching-choices]`)],p={},m=null,h=!1,g=0,_=!1,v=null,y=0,b=``,x={promptIds:t.prompts.map(e=>e.id),choiceIds:t.choices.map(e=>e.id)};function S(e,t,n){let r=e.querySelector(t)??o(e,`span`,n);a(r,`class`,`${r.className} ${n}`),a(r,`aria-hidden`,`true`);let s=r.textContent;return i.push(()=>{r.textContent=s}),r}try{let e=l.getMatchingProgress(n.publicationId,t);e&&(p=e.answers,h=e.submitted,g=e.attempts),x=Object.keys(p).length>0?e?.order??x:n.order??pe(t)}catch(e){_=!0,z(e)}n.onorder?.(x);function C(e){return de(x.choiceIds.indexOf(e))}a(e,`data-study-cheetah-enhanced`,`matching-v1`);for(let t of e.querySelectorAll(`:scope > p`))t.textContent?.trim()===`Match the Greek word with the correct English translation. Write the English meaning and its letter beside each Greek word.`&&a(t,`data-study-cheetah-matching-instructions`,``);for(let[e,t]of f.entries())a(t,`tabindex`,`0`),a(t,`aria-label`,e===0?`Greek words list`:`English meanings list`),e===0&&a(t,`aria-description`,`Select a word, then type a choice letter. Use up and down arrows to select words, or Control and up or down to scroll the meanings.`);function w(e){let n=t.prompts.findIndex(t=>t.id===e);T[n].control.focus({preventScroll:!0});let r=f[0],i=r.getBoundingClientRect(),a=u[n].getBoundingClientRect();a.top<i.top?r.scrollTop-=i.top-a.top:a.bottom>i.bottom&&(r.scrollTop+=a.bottom-i.bottom)}let T=u.map((e,n)=>{let r=t.prompts[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${x.promptIds.indexOf(r.id)};`);let i=S(e,`.matching-answer`,`sc-match-answer`),o=S(e,`.answer-blank`,`answer-blank`),c=S(e,`.matching-result`,`sc-match-result`),l=s(e,``,()=>{m=r.id,b=`Choose an English meaning for ${r.id}.`,V(),l.focus({preventScroll:!0})});return l.classList.add(`sc-match-select`),l.setAttribute(`aria-label`,`Greek ${r.id}: ${r.text}`),{answer:i,blank:o,result:c,control:l}}),E=d.map((e,n)=>{let r=t.choices[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${x.choiceIds.indexOf(r.id)};`),a(e,`data-choice-label`,C(r.id));let i=s(e,``,()=>{!m||_||(p=K(t,p,m,r.id),b=`Matched ${m} with ${r.text}.`,m=null,h=!1,B(),V())});return i.classList.add(`sc-match-select`),i.setAttribute(`aria-label`,`English: ${r.text}`),{control:i}}),D=e=>{if(!m||_||e.defaultPrevented||e.isComposing||e.metaKey||e.altKey||T[t.prompts.findIndex(e=>e.id===m)]?.control!==e.target)return;if((e.key===`ArrowUp`||e.key===`ArrowDown`)&&!e.shiftKey){e.preventDefault();let t=e.key===`ArrowDown`?1:-1;if(e.ctrlKey)f[1].scrollTop+=t*48;else{let e=x.promptIds.indexOf(m),n=x.promptIds[e+t];n&&(m=n,b=`Choose an English meaning for ${n}.`,V(),w(n))}return}if(e.ctrlKey||!/^[a-z]$/i.test(e.key))return;let n=e.key.toUpperCase().charCodeAt(0)-65,r=x.choiceIds[n];if(!r||(e.preventDefault(),e.repeat))return;let i=t.choices.find(e=>e.id===r);p=K(t,p,m,r);let a=m;m=x.promptIds[x.promptIds.indexOf(m)+1]??m,b=`Matched ${a} with ${i.text}.`,h=!1,B(),V(),w(m)};e.addEventListener(`keydown`,D),i.push(()=>e.removeEventListener(`keydown`,D));let O=o(e,`div`,`sc-match-footer`),k=c(),A=o(O,`div`,`sc-match-footer-row`),j=o(A,`p`,`sc-match-status`);j.setAttribute(`role`,`status`),j.setAttribute(`aria-live`,`polite`);let M=o(j,`span`,`sc-activity-status-full`),N=o(j,`span`,`sc-activity-status-compact`);N.setAttribute(`aria-hidden`,`true`);let P=o(j,`span`,`sc-match-announcement`),F=o(A,`div`,`sc-match-controls`),I=s(F,`Check answers`,()=>{h=!0,g+=1,b=``,B(),V()});I.classList.add(`sc-match-check`);let L=s(F,`Reset answers`,()=>{try{l.deleteMatchingProgress(n.publicationId,t),p={},m=null,h=!1,_=!1,b=`Answers cleared.`,B()}catch(e){z(e)}V()});L.classList.add(`sc-match-reset`);let R=s(F,`Print worksheet`,n.onprint);R.classList.add(`sc-match-print`);for(let[e,t,n]of[[I,`Check`,`M5 12l4 4L19 6`],[L,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[R,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])Mt(e,t,n);function z(e){console.error(`[Reader] Matching exercise progress:`,e),v=`Could not load or save exercise progress. ${e instanceof Error?e.message:String(e)}`,y++}function B(){try{l.saveMatchingProgress(n.publicationId,t,{revision:t.revision,answers:p,submitted:h,attempts:g,updated:Date.now(),order:x}),v=null}catch(e){z(e)}}function V(){let e=Object.keys(p).length,n=Ee(t,p);M.textContent=`${h?`${n} of ${t.prompts.length} correct.${n===t.prompts.length?` Exercise complete.`:``}`:`${e} of ${t.prompts.length} matched.`} Checks: ${g}.`,N.textContent=`${h?n:e}/${t.prompts.length} ${h?`correct`:`matched`}; ${g} ${g===1?`check`:`checks`}`,P.textContent=` ${b}`,k(v,y),I.disabled=_||e===0;for(let[e,{control:n,answer:i,blank:a,result:o}]of T.entries()){let s=t.prompts[e],c=t.choices.findIndex(e=>e.id===p[s.id]),l=t.choices[c],u=h&&!!l,d=l?.answerId===s.id;if(i.textContent=l?.text??``,a.textContent=l?C(l.id):``,l?.language?i.lang=l.language:i.removeAttribute(`lang`),n.disabled=_,n.setAttribute(`aria-pressed`,String(m===s.id)),n.setAttribute(`aria-description`,`${l?`Matches ${l.text}`:`Not matched`}${u?d?` Correct`:` Incorrect`:``}`),o.replaceChildren(),u){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.setAttribute(`viewBox`,`0 0 20 20`),e.setAttribute(`data-result`,d?`correct`:`incorrect`);let t=r.createElementNS(e.namespaceURI,`path`);t.setAttribute(`d`,d?`M3 10l4 4L17 4`:`M4 4l12 12M16 4L4 16`),e.append(t),o.append(e)}}for(let[e,{control:n}]of E.entries()){let r=t.choices[e],i=Object.entries(p).find(([,e])=>e===r.id)?.[0];n.disabled=_||!m,n.setAttribute(`aria-description`,`Choice ${C(r.id)}. ${i?`Used by ${i}`:`Not used`}`)}}return V(),()=>{for(let e of i.reverse())e()}}var Ft=`body:has(> [data-study-cheetah-enhanced="word-search-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
  color: inherit;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-study-cheetah-word-search-instructions] { display: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="word-search-v1"] > [data-word-search-layout] { flex-grow: 1; align-content: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr);\r
  gap: 0.6em 1em;\r
  align-items: start;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) {\r
  grid-template-columns: minmax(0, var(--sc-word-search-board-space, 1fr)) minmax(0, 1fr);\r
  column-gap: 10em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit][data-word-search-measure="side"] {\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] > .word-search-board {\r
  box-sizing: border-box;\r
  min-width: 0;\r
  padding: 1em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] .word-search-vocabulary {\r
  justify-self: start;\r
  width: max-content;\r
  max-width: 100%;\r
  min-width: 0;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-words], [data-word-search-words] > li) {\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-words] {\r
  font-size: 1.25em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  grid-template-columns: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) .word-search-vocabulary {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr);\r
  max-height: var(--sc-word-search-height);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  min-height: 0;\r
  padding-block: 0.15em;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .word-search-vocabulary h2 {\r
  display: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] [data-word-search-grid] {\r
  width: var(--sc-word-search-width, 100%);\r
  min-width: 0;\r
  max-width: none;\r
  margin-inline: auto;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] td > span {\r
  block-size: var(--sc-word-search-cell, auto);\r
  font-size: max(1em, var(--sc-word-search-letter, 1em));\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-cell {\r
  position: absolute;\r
  top: 0;\r
  left: 0;\r
  max-width: none;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  background: transparent;\r
  color: var(--reader-page-fg, inherit);\r
  cursor: pointer;\r
  touch-action: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-grid] { user-select: none; touch-action: none; }\r
:is([data-study-cheetah-enhanced="word-search-v1"][data-sc-word-search-overlay-host],\r
  [data-study-cheetah-enhanced="word-search-v1"] [data-sc-word-search-overlay-host]) { position: relative; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-capsules {\r
  position: absolute;\r
  pointer-events: none;\r
  overflow: visible;\r
}\r
.sc-word-search-capsules rect { fill: none; }\r
.sc-word-search-found-capsule { stroke: var(--reader-matching-correct, #166534); }\r
.sc-word-search-selected-capsule { stroke: var(--reader-page-fg, currentColor); }\r
.sc-word-search-cell:focus-visible { outline: 2px solid currentColor; outline-offset: -3px; }\r
[data-sc-word-search-pointer-focus="true"] .sc-word-search-cell:focus-visible { outline: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-touch-preview {\r
  position: fixed;\r
  inset: auto;\r
  box-sizing: border-box;\r
  width: max-content;\r
  max-width: calc(100vw - 1rem);\r
  margin: 0;\r
  padding: 0.3em 0.75em;\r
  border: 2px solid currentColor;\r
  border-radius: 9999px;\r
  background: var(--reader-page-bg, Canvas);\r
  color: var(--reader-page-fg, CanvasText);\r
  font-size: max(1.25em, var(--sc-word-search-letter, 1em));\r
  line-height: 1.4;\r
  letter-spacing: 0.1em;\r
  text-align: center;\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-found-word {\r
  color: var(--reader-matching-correct, #166534);\r
  font-weight: bold;\r
  text-decoration: line-through;\r
}\r
.sc-word-search-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-word-search-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer p { margin: 0; }\r
.sc-word-search-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-word-search-status { min-width: 0; text-align: left; }\r
.sc-word-search-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-word-search-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-word-search-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-word-search-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-word-search-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-word-search-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] .sc-word-search-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`;function It(e,t,n){let r=e.querySelector(`[data-word-search-grid]`),i=[...e.querySelectorAll(`[data-word-search-grid] td`)];if(!r||i.length!==t.grid.length*t.grid[0].length)throw Error(`The word-search grid does not match its worksheet.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l,errorPanel:u}=Nt(e,Ft),d=r.parentElement;a.defaultView.getComputedStyle(d).position===`static`&&s(d,`data-sc-word-search-overlay-host`,``);let f=a.createElementNS(`http://www.w3.org/2000/svg`,`svg`);f.setAttribute(`class`,`study-cheetah-activity-ui sc-word-search-capsules`),f.setAttribute(`aria-hidden`,`true`),f.setAttribute(`focusable`,`false`),d.append(f),o.push(()=>f.remove());let p=Se.getInstance(),m=t.grid[0].length,h=t.grid.join(``),g=[],_=null,v=null,y=null,b=null,x=!1,S,C=!1,w=0,T=!1,E=null,D=0,O=``;function k(e){console.error(`[Reader] Word-search progress:`,e),E=`Could not load or save puzzle progress. ${e instanceof Error?e.message:String(e)}`,D++}try{g=p.getWordSearchProgress(n.publicationId,t)?.found??[]}catch(e){T=!0,k(e)}s(e,`data-study-cheetah-enhanced`,`word-search-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Find the Greek words in any of eight directions, including backward. Grid letters are lowercase without accents or breathing marks.`,`Find words in all eight directions. Lowercase grid letters omit accents.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-word-search-instructions`,``);s(r,`role`,`grid`),s(r,`aria-rowcount`,String(t.grid.length)),s(r,`aria-colcount`,String(m)),s(r,`aria-description`,`Drag from the first letter to the last, or tap both ends. Keyboard: use arrow keys, Enter or Space to select each end, and Escape to cancel.`),s(r,`data-sc-word-search-pointer-focus`,`false`);let A=i.map((e,t)=>{s(e,`role`,`gridcell`);let n=e.querySelector(`span`);n&&s(n,`aria-hidden`,`true`);let r=c(e,`button`,`sc-word-search-cell`);return r.type=`button`,r.dataset.cellIndex=String(t),r.setAttribute(`aria-label`,`Row ${Math.floor(t/m)+1}, column ${t%m+1}: ${h[t]}`),r}),j=c(e,`div`,`sc-word-search-touch-preview`);j.popover=`manual`,j.lang=`el`,j.setAttribute(`aria-hidden`,`true`),j.hidden=!0;let M=c(c(e,`div`,`sc-word-search-footer`),`div`,`sc-word-search-footer-row`),N=c(M,`p`,`sc-word-search-status`);N.setAttribute(`role`,`status`),N.setAttribute(`aria-live`,`polite`);let P=c(N,`span`,`sc-activity-status-full`),F=c(N,`span`,`sc-activity-status-compact`);F.setAttribute(`aria-hidden`,`true`);let I=c(N,`span`,`sc-word-search-announcement`),L=u(),R=c(M,`div`,`sc-word-search-controls`),z=l(R,`Reset puzzle`,()=>{ne();try{p.deleteWordSearchProgress(n.publicationId,t),g=[],_=null,T=!1,O=`Found words cleared.`,H()}catch(e){k(e)}pe()});z.classList.add(`sc-word-search-reset`);let B=l(R,`Print worksheet`,n.onprint);B.classList.add(`sc-word-search-print`),Mt(z,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`),Mt(B,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`);let V=[...e.querySelectorAll(`[data-word-search-words] > li`)];for(let e of V)s(e,`class`,e.className);function H(){try{p.saveWordSearchProgress(n.publicationId,t,{revision:t.revision,puzzle:_e(t),found:g,updated:Date.now()}),E=null}catch(e){k(e)}}function U(e,n){let r=ge(t,e,n);r?g.some(e=>e.wordId===r.id)?O=`${r.text} is already found.`:(g=[...g,{wordId:r.id,start:e,end:n}],O=`Found ${r.text}.`,H()):O=`No listed word selected. Choose a straight row, column, or diagonal.`,_=null}function W(e){T||(w=e,_===null?(_=e,O=`First letter selected. Choose the last letter.`):U(_,e),pe())}function ee(){return v!==null&&y!==null?be(t,C?v:_??v,y)??[]:_===null?[]:[_]}function te(){let e=r.getBoundingClientRect(),t=r.offsetWidth,n=r.offsetHeight;if(!t||!n||!e.width||!e.height){f.replaceChildren();return}f.style.width=`${t}px`,f.style.height=`${n}px`,f.setAttribute(`viewBox`,`0 0 ${t} ${n}`);let o=t/e.width,s=n/e.height,c=f.getBoundingClientRect();f.style.left=`${(Number.parseFloat(f.style.left)||0)+(e.left-c.left)*o}px`,f.style.top=`${(Number.parseFloat(f.style.top)||0)+(e.top-c.top)*s}px`;let l=a.createDocumentFragment();function u(t,n,r,c){let u=i[t].getBoundingClientRect(),d=i[n].getBoundingClientRect(),p=(u.left+u.width/2-e.left)*o,m=(u.top+u.height/2-e.top)*s,h=(d.left+d.width/2-u.left-u.width/2)*o,g=(d.top+d.height/2-u.top-u.height/2)*s,_=Math.min(u.width*o,u.height*s),v=_*.4,y=a.createElementNS(f.namespaceURI,`rect`);y.setAttribute(`class`,r),c&&y.setAttribute(`data-sc-word-id`,c),y.setAttribute(`x`,String(p-v)),y.setAttribute(`y`,String(m-v)),y.setAttribute(`width`,String(Math.hypot(h,g)+2*v)),y.setAttribute(`height`,String(2*v)),y.setAttribute(`rx`,String(v)),y.setAttribute(`stroke-width`,String(_*.08)),y.setAttribute(`transform`,`rotate(${Math.atan2(g,h)*180/Math.PI} ${p} ${m})`),l.append(y)}for(let e of g)u(e.start,e.end,`sc-word-search-found-capsule`,e.wordId);let d=ee();d.length&&u(d[0],d[d.length-1],`sc-word-search-selected-capsule`),f.replaceChildren(l)}function ne(){clearTimeout(S),S=void 0,j.matches(`:popover-open`)&&j.hidePopover(),j.hidden=!0,j.textContent=``}function re(){if(j.hidden)return;let e=r.getBoundingClientRect(),t=j.getBoundingClientRect(),n=Math.max(8,Math.min(e.left+e.width/2-t.width/2,a.documentElement.clientWidth-t.width-8));j.style.left=`${n}px`,j.style.top=`${Math.max(8,e.top-t.height-8)}px`}function ie(){let e=ee();if(!e.length){ne();return}j.textContent=e.map(e=>h[e]).join(``),j.hidden=!1,j.matches(`:popover-open`)||j.showPopover(),re()}function G(e){let t=a.elementFromPoint(e.clientX,e.clientY)?.closest(`.sc-word-search-cell`);return t&&r.contains(t)?Number(t.dataset.cellIndex):null}let ae=e=>{if(T||e.button!==0||b!==null)return;let t=G(e);t!==null&&(e.preventDefault(),ne(),x=e.pointerType===`touch`,v=y=t,b=e.pointerId,C=!1,w=t,r.setAttribute(`data-sc-word-search-pointer-focus`,`true`),A[t].focus({preventScroll:!0}),r.setPointerCapture(e.pointerId),pe())},oe=e=>{if(e.pointerId!==b||v===null)return;let t=G(e);t!==y&&(y=t,y!==null&&y!==v&&(C=!0),pe())},se=e=>{if(e.pointerId!==b||v===null)return;let t=G(e);y=t;let n=x;n&&ie(),x=!1,t===null?(_=null,O=`Selection cancelled.`):C?U(v,t):W(t),b=v=y=null,pe(),n&&!j.hidden&&(S=setTimeout(ne,1e3))},ce=e=>{e&&e.pointerId!==b||(x=!1,ne(),b=v=y=_=null,pe())},le=e=>{let t=e.target.closest(`.sc-word-search-cell`);e.detail===0&&t&&(ne(),W(Number(t.dataset.cellIndex)))},ue=e=>{r.setAttribute(`data-sc-word-search-pointer-focus`,`false`);let t=e.target.closest(`.sc-word-search-cell`);if(!t||e.altKey||e.ctrlKey||e.metaKey)return;let n=Number(t.dataset.cellIndex),a=n;if(e.key===`ArrowLeft`)a=n%m?n-1:n;else if(e.key===`ArrowRight`)a=n%m<m-1?n+1:n;else if(e.key===`ArrowUp`)a=Math.max(n-m,n%m);else if(e.key===`ArrowDown`)a=Math.min(n+m,i.length-m+n%m);else if(e.key===`Enter`||e.key===` `)W(n);else if(e.key===`Escape`)ce(),O=`Selection cancelled.`;else return;e.preventDefault(),w=a,pe(),A[a].focus()},de=e=>{(!(e.relatedTarget instanceof a.defaultView.Node)||!r.contains(e.relatedTarget))&&r.setAttribute(`data-sc-word-search-pointer-focus`,`false`)};r.addEventListener(`pointerdown`,ae),r.addEventListener(`pointermove`,oe),r.addEventListener(`pointerup`,se),r.addEventListener(`pointercancel`,ce),r.addEventListener(`lostpointercapture`,ce),r.addEventListener(`click`,le),r.addEventListener(`keydown`,ue),r.addEventListener(`focusout`,de),a.addEventListener(`scroll`,re,!0),a.defaultView?.addEventListener(`resize`,re),o.push(()=>{ne(),r.removeEventListener(`pointerdown`,ae),r.removeEventListener(`pointermove`,oe),r.removeEventListener(`pointerup`,se),r.removeEventListener(`pointercancel`,ce),r.removeEventListener(`lostpointercapture`,ce),r.removeEventListener(`click`,le),r.removeEventListener(`keydown`,ue),r.removeEventListener(`focusout`,de),a.removeEventListener(`scroll`,re,!0),a.defaultView?.removeEventListener(`resize`,re)});let fe=new ResizeObserver(te);fe.observe(e),fe.observe(d),fe.observe(r),o.push(()=>fe.disconnect());function pe(){let e=new Set(g.flatMap(e=>be(t,e.start,e.end)??[])),n=new Set(ee());te(),x&&ie();for(let[t,r]of A.entries())r.tabIndex=t===w?0:-1,r.disabled=T,r.classList.toggle(`sc-word-search-found`,e.has(t)),r.classList.toggle(`sc-word-search-selected`,n.has(t)),r.setAttribute(`aria-pressed`,String(n.has(t))),r.setAttribute(`aria-description`,e.has(t)?`Part of a found word`:`Not found`);for(let e of V)e.classList.toggle(`sc-word-search-found-word`,g.some(t=>t.wordId===e.dataset.wordId));P.textContent=`${g.length} of ${t.words.length} words found.${g.length===t.words.length?` Puzzle complete.`:``}`,F.textContent=`${g.length}/${t.words.length} found`,I.textContent=O?` ${O}`:``,L(E,D)}pe();let me=e.querySelector(`:scope > [data-word-search-layout]`),he=me?.querySelector(`.word-search-vocabulary`);return me&&he&&o.push(Lt(e,me,r,he,m,t.grid.length)),()=>{for(let e of o.reverse())e()}}function Lt(e,t,n,r,i,a){let o=Array.from(e.children).filter(e=>e!==t),s=e=>Number.parseFloat(e)||0,c=r.querySelector(`[data-word-search-words]`),l=c.getAttribute(`tabindex`);t.dataset.wordSearchFit=`stack`;function u(){l===null?c.removeAttribute(`tabindex`):c.setAttribute(`tabindex`,l)}function d(){if(!e.clientHeight||!e.clientWidth)return;let l=getComputedStyle(e),d=o.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),f=e.clientHeight-s(l.paddingTop)-s(l.paddingBottom)-s(l.rowGap)*d.length;for(let e of d){let t=getComputedStyle(e);f-=e.getBoundingClientRect().height+s(t.marginTop)+s(t.marginBottom)}t.dataset.wordSearchMeasure=`stack`;let p=getComputedStyle(t),m=t.clientWidth,h=getComputedStyle(n.parentElement),g=s(h.paddingLeft)+s(h.paddingRight),_=s(h.paddingTop)+s(h.paddingBottom),v=f-_,y=Math.ceil(s(getComputedStyle(n).fontSize)*i),b=Math.max(y,Math.min(m-g,(v-r.offsetHeight-s(p.rowGap))*i/a));t.dataset.wordSearchMeasure=`side`;let x=s(getComputedStyle(t).columnGap),S=r.offsetWidth,C=Math.max(y,v*i/a)+g,w=m-x,T=Math.min(w-S,w*C/(C+S)),E=T-g,D=Math.max(y,Math.min(E,v*i/a));delete t.dataset.wordSearchMeasure;let O=t.dataset.wordSearchFit===`side`,k=e.clientWidth>=e.clientHeight+(O?-4:4),A=E>=y+(O?0:4)&&(D>b+4||D>=b-(O?4:0)&&k||O&&D>b),j=Math.floor(A?D:b);A!==O&&(t.dataset.wordSearchFit=A?`side`:`stack`),t.style.setProperty(`--sc-word-search-width`,`${j}px`),t.style.setProperty(`--sc-word-search-cell`,`${j/i}px`),t.style.setProperty(`--sc-word-search-letter`,`${j/i*.58}px`),t.style.setProperty(`--sc-word-search-height`,`${j*a/i}px`),t.style.setProperty(`--sc-word-search-board-space`,`${Math.max(0,T)}px`),A&&c.scrollHeight>c.clientHeight?c.tabIndex=0:u()}let f=new ResizeObserver(d);f.observe(e),f.observe(r);for(let e of o)f.observe(e);return d(),()=>{f.disconnect(),delete t.dataset.wordSearchFit,t.style.removeProperty(`--sc-word-search-width`),t.style.removeProperty(`--sc-word-search-cell`),t.style.removeProperty(`--sc-word-search-letter`),t.style.removeProperty(`--sc-word-search-height`),t.style.removeProperty(`--sc-word-search-board-space`),u()}}var Rt=`body:has(> [data-study-cheetah-enhanced="crossword-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="crossword-v1"] [data-study-cheetah-crossword-instructions] { display: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-layout {\r
  flex-grow: 1;\r
  grid-template-columns: max-content var(--sc-crossword-width, minmax(0, 1fr));\r
  justify-content: center;\r
  align-content: center;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-grid { width: var(--sc-crossword-width, 100%); max-width: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr) minmax(0, 1fr);\r
  max-height: max(var(--sc-crossword-height), 10em);\r
  min-height: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] [data-crossword-wide="true"] .crossword-clues {\r
  grid-template-columns: max-content max-content;\r
  grid-template-rows: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues h2 { margin: 0 0 0.4em; line-height: 1.2; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: auto; min-height: 0; margin: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues li { position: relative; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue {\r
  padding: 0.1em 0.2em;\r
  border: 1px solid transparent;\r
  color: inherit;\r
  background: transparent;\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); font-weight: bold; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="correct"]::after { content: " \\2713"; color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="incorrect"]::after { content: " \\2717"; color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-input {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  box-sizing: border-box;\r
  border: 2px solid transparent;\r
  padding: 0;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: inherit;\r
  font-size: 1.25em;\r
  text-align: center;\r
  cursor: pointer;\r
  caret-color: transparent;\r
  -webkit-touch-callout: none;\r
  -webkit-user-select: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-number { pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-number { z-index: 1; pointer-events: none; color: var(--ui-control-fg, inherit); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-selected { background: var(--ui-control-bg-active, color-mix(in srgb, currentColor 12%, transparent)); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-current { border-color: currentColor; }\r
[data-study-cheetah-enhanced="crossword-v1"] :is(.sc-crossword-input, .sc-crossword-clue):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-crossword-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer p { margin: 0; }\r
.sc-crossword-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-crossword-status { min-width: 0; text-align: left; }\r
.sc-crossword-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-crossword-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-keyboard {\r
  width: min(100%, 650px);\r
  align-self: center;\r
  margin-top: 0.25em;\r
}\r
.sc-crossword-keyboard-rows { overflow-x: auto; }\r
.sc-crossword-keyboard-row { display: flex; justify-content: center; gap: 3px; margin-top: 3px; min-width: 480px; }\r
.sc-crossword-keyboard-key {\r
  position: relative;\r
  box-sizing: border-box;\r
  display: grid;\r
  place-items: center;\r
  flex: 1 1 0;\r
  max-width: 62px;\r
  min-width: 44px;\r
  height: 44px;\r
  padding: 0;\r
  margin: 0;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: 1em/1 sans-serif;\r
}\r
.sc-crossword-keyboard-key:is(button) { cursor: pointer; touch-action: manipulation; }\r
.sc-crossword-keyboard-key:is(button):hover:not(:disabled) { background: var(--ui-control-bg-hover, transparent); }\r
.sc-crossword-keyboard-key:is(button):is(:active, .sc-crossword-keyboard-pressed):not(:disabled) {\r
  background: var(--ui-control-bg-active, transparent);\r
  box-shadow: inset 0 0 0 2px currentColor;\r
}\r
.sc-crossword-keyboard-key:is(button):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-keyboard-key:is(button):disabled { opacity: 0.5; cursor: default; }\r
.sc-crossword-keyboard-placeholder { opacity: 0.5; height: 20px; }\r
.sc-crossword-keyboard-placeholder .sc-crossword-keyboard-original { display: none; }\r
.sc-crossword-keyboard-key-wide { max-width: none; font-size: 0.6em; }\r
.sc-crossword-keyboard-original { position: absolute; top: 2px; left: 3px; font-size: 0.5em; }\r
.sc-crossword-keyboard-key.sc-crossword-keyboard-mode { font-size: 0.7em; }\r
.sc-crossword-keyboard-mode .sc-crossword-keyboard-original { font-size: 8px; }\r
.sc-crossword-keyboard-has-marks::after {\r
  content: "+";\r
  position: absolute;\r
  top: 2px;\r
  right: 3px;\r
  font: bold 0.6em/1 sans-serif;\r
}\r
.sc-crossword-keyboard-number[aria-pressed="true"] { box-shadow: inset 0 0 0 2px currentColor; }\r
.sc-crossword-keyboard-shift[aria-pressed="true"] { box-shadow: inset 0 0 0 2px currentColor; }\r
.sc-crossword-keyboard-shift[data-locked="true"] { border-style: double; border-width: 3px; }\r
\r
@media (max-height: 400px) {\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
    display: block;\r
    max-height: var(--sc-crossword-height);\r
    overflow-y: auto;\r
  }\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: block; }\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: visible; }\r
  .sc-crossword-keyboard-placeholder { height: 13px; font-size: 12px; }\r
  .sc-crossword-keyboard-key-wide { font-size: 8px; }\r
  .sc-crossword-keyboard-original { top: 0; left: 2px; }\r
  .sc-crossword-keyboard-row { gap: 2px; margin-top: 2px; }\r
}\r
\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-crossword-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-crossword-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-crossword-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-crossword-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] .sc-crossword-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`,zt=[[[`1`,``],[`2`,``],[`3`,``],[`4`,``],[`5`,``],[`6`,``],[`7`,``],[`8`,``],[`9`,``],[`0`,``]],[[`Q`,`θ`],[`W`,`ω`],[`E`,`ε`],[`R`,`ρ`],[`T`,`τ`],[`Y`,`ψ`],[`U`,`υ`],[`I`,`ι`],[`O`,`ο`],[`P`,`π`]],[[`Diacritics`,``],[`A`,`α`],[`S`,`σ`],[`D`,`δ`],[`F`,`φ`],[`G`,`γ`],[`H`,`η`],[`J`,`ς`],[`K`,`κ`],[`L`,`λ`]],[[`Shift`,``],[`Z`,`ζ`],[`X`,`χ`],[`C`,`ξ`],[`V`,`ν`],[`B`,`β`],[`N`,`ν`],[`M`,`μ`],[`Backspace`,``]]],Bt=new Map(zt.flat().filter(([,e])=>e)),Vt=500;function Ht(e,t,n){let r=e.querySelector(`.crossword-grid`),i=[...e.querySelectorAll(`[data-entry-id]`)];if(!r||i.length!==t.clues.length)throw Error(`Crossword worksheet does not match its clues.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l,errorPanel:u}=Nt(e,Rt),d=Se.getInstance(),f={},p=t.clues[0],m=Y(p)[0],h=p.direction,g=!1,_=0,v=!1,y=null,b=0,x=``,S=null,C=null,w,T=null,E=`off`,D=!1,O=!1,k=new Map,A=[...t.clues].sort((e,t)=>e.number-t.number||(e.direction===t.direction?0:e.direction===`across`?-1:1));function j(){w!==void 0&&window.clearTimeout(w),w=void 0,T=null}function M(){return t.letterCase===`mixed`&&(O||E===`locked`)!==(D||E===`once`)}function N(e){let n=we(e);return t.letterCase===`lowercase`?n.toLowerCase().normalize(`NFC`):n}function P(e){let t=M()?e.toUpperCase():e;return E===`once`&&(E=`off`),t}function F(){E===`once`&&(E=`off`)}function I(e){e&&e.selectionStart!==e.selectionEnd&&e.setSelectionRange(e.value.length,e.value.length)}function L(e){console.error(`[Reader] Crossword progress:`,e),y=`Could not load or save crossword progress. ${e instanceof Error?e.message:String(e)}`,b++}try{let e=d.getCrosswordProgress(n.publicationId,t);e&&(f=Object.fromEntries(Object.entries(e.letters).map(([e,t])=>[e,N(t)])),g=e.submitted,_=e.attempts)}catch(e){v=!0,L(e)}s(e,`data-study-cheetah-enhanced`,`crossword-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Use the English clues to fill in the Greek words. Accents and breathing marks are not required.`,`Use the English clues to fill in the Greek words. Include accents and breathing marks.`,`Fill in the Greek words.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-crossword-instructions`,``);s(r,`role`,`grid`),s(r,`aria-description`,`${t.letterCase===`lowercase`?`This puzzle uses lowercase letters. `:``}Select a clue or square, then type US letters using the on-screen Greek mapping, type Greek directly, or use the on-screen keyboard. Tap a suitable filled square, hold a marked key, or tap and release Control for diacritics. Select number 1 to accept, or Escape to cancel. Click a selected crossing again or press Enter to change direction. Use arrow keys to move. Tab selects the next clue; Shift+Tab selects the previous clue, wrapping by number with Across before Down. Escape moves to the puzzle controls for normal tabbing.`);let R=t.clues.map(e=>{let t=i.find(t=>t.dataset.entryId===e.id);if(!t)throw Error(`Crossword worksheet is missing a clue.`);for(let e of t.children)s(e,`hidden`,``);let n=l(t,`${e.number}. ${e.text}`,()=>{z(e,Y(e)[0],!0)});return n.classList.add(`sc-crossword-clue`),n});function z(e,t,n){if(j(),t===m?e.id!==p.id&&S?.resumePosition&&(S={position:S.position,value:S.value,replaceOnTyping:S.replaceOnTyping}):S=null,(t!==m||e.id!==p.id)&&(C=null),p=e,h=e.direction,m=t,x=`${e.number} ${e.direction}: ${e.text}.`,Q(),n){let e=k.get(t);e?.focus(),I(e)}}function B(e,n){let r=t.clues.filter(t=>Y(t).includes(e)),i=r.find(e=>e.direction===h),a=r.find(e=>e.direction!==h),o=(n&&e===m?a:i)??i??a;o&&z(o,e,!1)}function V(){try{d.saveCrosswordProgress(n.publicationId,t,{revision:t.revision,puzzle:me(t),letters:f,submitted:g,attempts:_,updated:Date.now()}),y=null}catch(e){L(e)}}function H(e,t,n=!0){if(e!==m||v)return;let r=k.get(e);if(!t)delete f[e],C=null;else{try{f[e]=N(t)}catch{x=`Enter one Greek letter per square.`,Q(),n&&I(r);return}C=e}g=!1;let[i,a]=e.split(`,`).map(Number);x=n?``:t?`${f[e]} entered in row ${i+1}, column ${a+1}.`:`Row ${i+1}, column ${a+1} cleared.`,V();let o=Y(p),s=o[o.indexOf(e)+1];t&&s&&(m=s),Q(),n&&(t&&s?k.get(s)?.focus():I(r))}function U(){q.hidden&&(q.hidden=!1,ge.setAttribute(`aria-pressed`,`true`),n.onkeyboardvisibilitychange?.(!0))}function W(){let e=f[m];if(e)return ye(e)?m:null;let t=Y(p),n=t[t.indexOf(m)-1];return n&&n===C&&f[n]&&ye(f[n])?n:null}function ee(e,t=m,n=!1){let r=a.activeElement instanceof a.defaultView.HTMLInputElement&&a.activeElement.classList.contains(`sc-crossword-input`),i=t===m?void 0:m;m=t,S={position:m,value:we(e),...n?{replaceOnTyping:!0}:{},...i?{resumePosition:i}:{}},U(),x=`Diacritics for ${S.value}. Choose a mark, then 1 to accept or Escape to cancel.`,Q(),r&&k.get(t)?.focus()}function te(){if(v||S)return;let e=W();e?ee(f[e],e):(x=`Select or enter a letter that supports diacritics.`,Q())}function ne(){let e=S?.resumePosition,t=a.activeElement instanceof a.defaultView.HTMLInputElement&&a.activeElement.classList.contains(`sc-crossword-input`);S=null,e&&(m=e,t&&k.get(e)?.focus())}function re(){ne(),x=`Diacritics cancelled.`,Q()}function ie(){S?re():te()}function G(e,t,n=!1){let r;try{r=N(e)}catch{x=`Enter one Greek letter per square.`,Q();return}if(S?.replaceOnTyping){let e=S;S=null;let[i,...a]=r.normalize(`NFD`),[o,...s]=e.value.normalize(`NFD`);a.length===0&&i.toLowerCase()===o.toLowerCase()&&(r=(i+s.join(``)).normalize(`NFC`)),n&&ye(r)?ee(r):H(e.position,r,t);return}let i=!!S;if(S){let e=S;S=null,H(e.position,e.value,t)}(i||n)&&ye(r)?ee(r):H(m,r,t)}function ae(e){if(!S)return;let t=S;S=null,H(t.position,t.value,e)}function oe(e){if(!S)return;let t=J(S.value).find(t=>t.number===e);t?.enabled&&(S={position:S.position,value:t.value,...S.resumePosition?{resumePosition:S.resumePosition}:{}},x=`${t.name} ${t.selected?`removed`:`selected`}: ${t.value}.`,Q())}for(let[i,a]of t.cells.entries())for(let[l,u]of a.entries()){if(!u)continue;let a=r.rows[i].cells[l],d=ve(i,l);s(a,`role`,`gridcell`);let p=c(a,`input`,`sc-crossword-input`);p.type=`text`,p.inputMode=`none`,p.lang=t.language,p.autocomplete=`off`,p.spellcheck=!1,p.dataset.crosswordCell=d,k.set(d,p);let g=!1,_=()=>{g=d===m&&e.ownerDocument.activeElement===p},v=()=>{d!==m&&B(d,!1),I(p)},y=()=>{g&&B(d,!0),g=!1,I(p);let e=f[d];e&&ye(e)&&S?.position!==d&&ee(e,d,!0)},b=e=>e.preventDefault(),x=()=>I(p),C=e=>`inputType`in e&&typeof e.inputType==`string`&&[`insertFromPaste`,`insertFromPasteAsQuotation`,`insertFromDrop`,`deleteByCut`,`deleteByDrag`].includes(e.inputType),w=e=>{if(`isComposing`in e&&!e.isComposing&&`inputType`in e&&(e.inputType===`insertText`||e.inputType===`insertReplacementText`)&&`data`in e&&typeof e.data==`string`&&e.data)return e.data},T=e=>{if(C(e)){e.preventDefault();return}if(`inputType`in e&&typeof e.inputType==`string`&&(e.inputType.startsWith(`insert`)||e.inputType.startsWith(`delete`))&&n.ontyping?.(),e.cancelable&&`inputType`in e&&(e.inputType===`deleteContentBackward`||e.inputType===`deleteContentForward`)){e.preventDefault(),S=null,H(d,``);return}let t=w(e);!e.cancelable||t===void 0||(e.preventDefault(),F(),G(t,!0))},E=e=>{if(`isComposing`in e&&e.isComposing)return;if(d!==m||C(e)){p.value=f[d]??``;return}n.ontyping?.();let t=w(e)??p.value;t?(F(),G(t,!0)):(S=null,H(d,``))},D=e=>{e.data?(n.ontyping?.(),F(),G(e.data,!0)):(p.value=f[d]??``,d===m&&I(p))},O=e=>{if((e.ctrlKey||e.metaKey)&&[`a`,`c`,`x`,`v`].includes(e.key.toLowerCase())){e.preventDefault();return}if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;if(e.key===`Backspace`||e.key===`Delete`){e.preventDefault(),S=null,H(d,``);return}if(e.key===`Enter`){e.preventDefault(),B(d,!0);return}let n={ArrowLeft:[0,-1,`across`],ArrowRight:[0,1,`across`],ArrowUp:[-1,0,`down`],ArrowDown:[1,0,`down`]}[e.key];if(!n)return;e.preventDefault();let[r,a,o]=n;for(let e=i+r,n=l+a;e>=0&&e<t.rows&&n>=0&&n<t.columns;e+=r,n+=a){let t=ve(e,n);if(k.has(t)){h=o,B(t,!1),k.get(t)?.focus();break}}};p.addEventListener(`pointerdown`,_),p.addEventListener(`focus`,v),p.addEventListener(`click`,y),p.addEventListener(`beforeinput`,T),p.addEventListener(`input`,E),p.addEventListener(`compositionend`,D),p.addEventListener(`keydown`,O),p.addEventListener(`select`,x);let A=[`copy`,`cut`,`paste`,`contextmenu`,`selectstart`,`dragstart`,`drop`];for(let e of A)p.addEventListener(e,b);o.push(()=>{p.removeEventListener(`pointerdown`,_),p.removeEventListener(`focus`,v),p.removeEventListener(`click`,y),p.removeEventListener(`beforeinput`,T),p.removeEventListener(`input`,E),p.removeEventListener(`compositionend`,D),p.removeEventListener(`keydown`,O),p.removeEventListener(`select`,x);for(let e of A)p.removeEventListener(e,b)})}let se=c(c(e,`div`,`sc-crossword-footer`),`div`,`sc-crossword-footer-row`),ce=c(se,`p`,`sc-crossword-status`);ce.setAttribute(`role`,`status`),ce.setAttribute(`aria-live`,`polite`);let le=c(ce,`span`,`sc-activity-status-full`),ue=c(ce,`span`,`sc-activity-status-compact`);ue.setAttribute(`aria-hidden`,`true`);let de=c(ce,`span`,`sc-crossword-announcement`),pe=u(),he=c(se,`div`,`sc-crossword-controls`),ge=l(he,`Greek keyboard`,()=>{q.hidden=!q.hidden,ge.setAttribute(`aria-pressed`,String(!q.hidden)),n.onkeyboardvisibilitychange?.(!q.hidden),q.hidden||n.onkeyboardshow?.(),q.hidden&&(ne(),Ae(),Q())});ge.setAttribute(`aria-pressed`,String(n.keyboardVisible!==!1));let K=l(he,`Check answers`,()=>{ne(),g=!0,_++,x=``,V(),Q()});K.classList.add(`sc-crossword-check`);let _e=l(he,`Reset puzzle`,()=>{try{d.deleteCrosswordProgress(n.publicationId,t),S=null,C=null,f={},g=!1,_=0,v=!1,x=`Answers cleared.`,V()}catch(e){L(e)}Q()});_e.classList.add(`sc-crossword-reset`);let be=l(he,`Print worksheet`,n.onprint);be.classList.add(`sc-crossword-print`);for(let[e,t,n]of[[ge,`Keyboard`,`M3 5h18v14H3zM6 9h1M10 9h1M14 9h1M18 9h1M6 12h1M10 12h1M14 12h1M18 12h1M7 16h10`],[K,`Check`,`M5 12l4 4L19 6`],[_e,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[be,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])Mt(e,t,n);let q=c(e,`div`,`sc-crossword-keyboard`);q.hidden=n.keyboardVisible===!1,q.setAttribute(`role`,`group`),q.setAttribute(`aria-label`,`Greek on-screen keyboard`);let xe=a.createElement(`div`);xe.className=`sc-crossword-keyboard-rows`,q.append(xe);let Ce=[],Te=new Map,Ee=new Map,De=null,X=null;for(let e of zt){let t=a.createElement(`div`);t.className=`sc-crossword-keyboard-row`;for(let[r,i]of e){let e=/^[0-9]$/.test(r),s=a.createElement(i||e||r===`Backspace`||r===`Diacritics`||r===`Shift`?`button`:`span`);if(s.className=`sc-crossword-keyboard-key${r.length>1?` sc-crossword-keyboard-key-wide`:``}`,s instanceof a.defaultView.HTMLButtonElement){s.type=`button`,e&&(s.classList.add(`sc-crossword-keyboard-number`),Ee.set(r,s)),s.setAttribute(`aria-label`,i?`${i} (${r})`:r===`Backspace`?`Clear current square`:r),r===`Diacritics`&&(s.classList.add(`sc-crossword-keyboard-mode`),De=s),r===`Shift`&&(s.classList.add(`sc-crossword-keyboard-shift`),X=s);let t,c=!1,l=null,u=0,d=0,p=()=>{t!==void 0&&window.clearTimeout(t),t=void 0,l=null};if(i&&ye(i)){s.classList.add(`sc-crossword-keyboard-has-marks`),s.setAttribute(`aria-description`,`Hold for diacritics.`),s.addEventListener(`pointerdown`,e=>{e.button!==0||v||(c=!1,l=e.pointerId,u=e.clientX,d=e.clientY,t=window.setTimeout(()=>{t=void 0,l!==null&&(c=!0,s.focus({preventScroll:!0}),n.ontyping?.(),G(P(i),!1,!0))},Vt))});let e=e=>{e.pointerId===l&&Math.hypot(e.clientX-u,e.clientY-d)>10&&(c=!0,p())},r=e=>{e.pointerId===l&&p()};a.addEventListener(`pointermove`,e),a.addEventListener(`pointerup`,r),a.addEventListener(`pointercancel`,r),s.addEventListener(`keydown`,()=>{c=!1}),s.addEventListener(`contextmenu`,e=>e.preventDefault()),o.push(()=>{p(),a.removeEventListener(`pointermove`,e),a.removeEventListener(`pointerup`,r),a.removeEventListener(`pointercancel`,r)})}s.addEventListener(`click`,()=>{if(c){c=!1;return}n.ontyping?.(),s.focus({preventScroll:!0}),i?G(P(i),!1):e?r===`1`?ae(!1):oe(r):r===`Diacritics`?ie():r===`Shift`?(E=E===`off`?`once`:E===`once`?`locked`:`off`,Q()):(f[m]||S)&&(S=null,H(m,``,!1))}),Ce.push(s),i&&Te.set(r,s)}else s.setAttribute(`aria-hidden`,`true`),s.classList.add(`sc-crossword-keyboard-placeholder`);if(i||e||r===`Diacritics`){let e=a.createElement(`span`);e.className=`sc-crossword-keyboard-original`,e.textContent=r===`Diacritics`?`Ctrl`:r,s.append(e)}let c=a.createElement(`span`);c.textContent=i||(e?``:r===`Diacritics`?`Marks`:r),(i||e)&&(c.lang=`el`),s.append(c),t.append(s)}xe.append(t)}let Oe=new Map,ke=!1,Ae=()=>{j();for(let e of Oe.values())e.classList.remove(`sc-crossword-keyboard-pressed`);Oe.clear(),De?.classList.remove(`sc-crossword-keyboard-pressed`),ke=!1;let e=D;D=!1,e&&Q()},Z=e=>{let t=e.shiftKey,n=e.getModifierState(`CapsLock`);(t!==D||n!==O)&&(D=t,O=n,Q())},je=e=>{let t=e.code||e.key.toUpperCase();if(T!==t&&j(),e.key===`Control`&&!e.repeat&&!e.altKey&&!e.metaKey&&!e.shiftKey){let t=e.target;ke=!v&&t instanceof a.defaultView.Element&&!!t.closest(`.sc-crossword-input, .sc-crossword-keyboard`),ke&&De?.classList.add(`sc-crossword-keyboard-pressed`);return}e.key!==`Control`&&(ke=!1);let r=e.target;if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.isComposing&&!v&&r instanceof a.defaultView.Element&&r.closest(`.sc-crossword-input, .sc-crossword-keyboard`)&&(e.key.length===1||e.key===`Backspace`||e.key===`Delete`)&&n.ontyping?.(),e.defaultPrevented||e.ctrlKey||e.metaKey||e.altKey||e.isComposing||v||!(r instanceof a.defaultView.Element)||!r.closest(`.sc-crossword-input, .sc-crossword-keyboard`))return;if(e.key===`Tab`){e.preventDefault(),S=null;let t=A[(A.indexOf(p)+(e.shiftKey?-1:1)+A.length)%A.length];z(t,Y(t)[0],!0);return}if(e.key===`Escape`){if(e.preventDefault(),Ae(),S){re();return}n.onfocuscontrols?n.onfocuscontrols():(K.disabled?_e:K).focus();return}let i=r.classList.contains(`sc-crossword-input`),o=/^Digit[0-9]$/.test(e.code)?e.code.slice(-1):e.key;if(S&&/^[0-9]$/.test(o)){e.preventDefault(),o===`1`?ae(i):oe(o);return}if(e.key===`Backspace`||e.key===`Delete`){e.preventDefault(),S=null,H(m,``,i);return}let s=e.key.toUpperCase(),c=Bt.get(s),l=Te.get(s);if(!c||!l||(e.preventDefault(),e.repeat||Oe.has(t)))return;Oe.set(t,l),l.classList.add(`sc-crossword-keyboard-pressed`);let u=m,d=p.id,h=!!S&&!S.replaceOnTyping;G(P(c),i);let g=f[u];if(!h&&!S&&C===u&&g&&ye(g)){let e=m;T=t,w=window.setTimeout(()=>{w=void 0;let n=T===t&&Oe.has(t)&&!v&&!S&&m===e&&p.id===d&&C===u&&f[u]===g;T=null,n&&ee(g,u)},Vt)}},Me=e=>{if(e.key===`Control`){let t=ke&&!e.altKey&&!e.metaKey&&!e.shiftKey&&!!a.activeElement?.closest(`.sc-crossword-input, .sc-crossword-keyboard`);ke=!1,De?.classList.remove(`sc-crossword-keyboard-pressed`),t&&ie()}let t=e.code||e.key.toUpperCase();T===t&&j(),Oe.get(t)?.classList.remove(`sc-crossword-keyboard-pressed`),Oe.delete(t)},Ne=t=>{(!(t.relatedTarget instanceof a.defaultView.Node)||!e.contains(t.relatedTarget))&&Ae()};e.addEventListener(`keydown`,je),e.addEventListener(`pointerdown`,j),e.addEventListener(`focusout`,Ne),a.addEventListener(`keydown`,Z,!0),a.addEventListener(`keyup`,Z,!0),a!==window.document&&(window.document.addEventListener(`keydown`,Z,!0),window.document.addEventListener(`keyup`,Z,!0)),a.addEventListener(`keyup`,Me),a.addEventListener(`visibilitychange`,Ae),a.defaultView.addEventListener(`blur`,Ae),o.push(()=>{e.removeEventListener(`keydown`,je),e.removeEventListener(`pointerdown`,j),e.removeEventListener(`focusout`,Ne),a.removeEventListener(`keydown`,Z,!0),a.removeEventListener(`keyup`,Z,!0),a!==window.document&&(window.document.removeEventListener(`keydown`,Z,!0),window.document.removeEventListener(`keyup`,Z,!0)),a.removeEventListener(`keyup`,Me),a.removeEventListener(`visibilitychange`,Ae),a.defaultView.removeEventListener(`blur`,Ae),Ae()});function Q(){let e=Y(p),n=t.clues.filter(e=>fe(e,f)).length;le.textContent=g?`${n} of ${t.clues.length} correct.${n===t.clues.length?` Puzzle complete.`:``}`:`${Object.keys(f).length} of ${k.size} squares filled. Not checked.`,ue.textContent=g?`${n}/${t.clues.length} OK`:`${Object.keys(f).length}/${k.size} set`,de.textContent=x?` ${x}`:``,pe(y,b),K.disabled=v||Object.keys(f).length===0;for(let e of Ce)e.disabled=v;for(let[e,t]of Te){let n=Bt.get(e),r=M()?n.toUpperCase():n;t.setAttribute(`aria-label`,`${r} (${e})`),t.lastElementChild&&t.lastElementChild.textContent!==r&&(t.lastElementChild.textContent=r)}if(X){let e=t.letterCase===`lowercase`;X.disabled=v||e,X.dataset.shift=E,X.dataset.locked=String(!e&&(E===`locked`||O)),X.setAttribute(`aria-pressed`,String(!e&&(E!==`off`||D||O))),X.setAttribute(`aria-description`,e?`This puzzle uses lowercase letters only.`:E===`locked`?`Shift lock on. Activate to turn off.`:E===`once`?`Shift on for the next letter. Activate again to lock.`:`${O?`Physical Caps Lock on. `:D?`Physical Shift held. `:``}Activate for one letter, then again to lock.`);let n=!e&&(E===`locked`||O)?`Lock`:`Shift`;X.lastElementChild&&X.lastElementChild.textContent!==n&&(X.lastElementChild.textContent=n)}if(De){let e=!!S;De.disabled=v||!e&&!W(),De.setAttribute(`aria-label`,e?`Cancel diacritics`:`Diacritics`);let t=De.lastElementChild;t&&(t.textContent=e?`Cancel`:`Marks`)}let r=S?J(S.value):[];for(let[e,t]of Ee){let n=r.find(t=>t.number===e),i=!!S&&(e===`1`||!!n?.enabled);t.disabled=v||!i,t.classList.toggle(`sc-crossword-keyboard-placeholder`,!S),t.setAttribute(`aria-hidden`,String(!S)),t.tabIndex=S&&i?0:-1,t.setAttribute(`aria-label`,e===`1`&&S?`Accept ${S.value} (1)`:n?`${n.name} (${e}): ${n.enabled?n.value:`unavailable`}`:e),n?t.setAttribute(`aria-pressed`,String(n.selected)):t.removeAttribute(`aria-pressed`);let a=t.lastElementChild;a&&(a.textContent=S?e===`1`?S.value:n?.enabled?n.value:`–`:e)}R.forEach((e,n)=>{e.disabled=v,e.setAttribute(`aria-pressed`,String(t.clues[n].id===p.id));let r=t.clues[n],i=Y(r),a=g&&i.some(e=>f[e])?fe(r,f)?`correct`:`incorrect`:``;e.dataset.result=a,e.setAttribute(`aria-description`,a===`correct`?`Correct`:a===`incorrect`?`Not correct`:`Not checked`)});for(let[n,r]of k){let[i,a]=n.split(`,`).map(Number),o=f[n]??``;r.value!==o&&(r.value=o),r.disabled=v,r.tabIndex=n===m?0:-1,r.classList.toggle(`sc-crossword-selected`,e.includes(n)),r.classList.toggle(`sc-crossword-current`,n===m);let s=t.clues.filter(e=>Y(e).includes(n)).map(e=>`${e.number} ${e.direction}: ${e.text}`).join(`; `);r.setAttribute(`aria-label`,`Row ${i+1}, column ${a+1}. ${s}`)}}Q();let $=e.querySelector(`.crossword-layout`),Pe=$?.querySelector(`.crossword-clues`);if($&&Pe){let n=[...e.children].filter(e=>e!==$),r=e=>Number.parseFloat(e)||0,i=()=>{if(!e.clientHeight||!e.clientWidth)return;let i=getComputedStyle(e),a=n.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),o=e.clientHeight-r(i.paddingTop)-r(i.paddingBottom)-r(i.rowGap)*a.length;for(let e of a){let t=getComputedStyle(e);o-=e.getBoundingClientRect().height+r(t.marginTop)+r(t.marginBottom)}o-=t.rows+2;let s=e.clientWidth-r(i.paddingLeft)-r(i.paddingRight);$.dataset.crosswordWide=String(s>=700);let c=r(getComputedStyle($).columnGap),l=s-Pe.offsetWidth-c,u=t.columns*24,d=Math.floor(Math.max(u,Math.min(l,o*t.columns/t.rows)));$.style.setProperty(`--sc-crossword-width`,`${d}px`),$.style.setProperty(`--sc-crossword-height`,`${Math.ceil(d*t.rows/t.columns)}px`)},a=new ResizeObserver(i);a.observe(e);for(let e of n)a.observe(e);i(),o.push(()=>{a.disconnect(),$.style.removeProperty(`--sc-crossword-width`),$.style.removeProperty(`--sc-crossword-height`),delete $.dataset.crosswordWide})}return()=>{for(let e of o.reverse())e()}}function Ut(e,t,n,r){let i=e.contentDocument,a=i?.defaultView,o=e.parentElement;if(!i||!a||!o)throw Error(`Activity publication frame is unavailable.`);let s=n.kind===`matching-v1`,c=n.kind===`crossword-v1`,l=s?`data-reader-matching-source`:c?`data-reader-crossword-source`:`data-reader-word-search-source`,u=e.ownerDocument.createElement(`iframe`);u.className=s?`reader-matching-frame`:c?`reader-crossword-frame`:`reader-word-search-frame`,u.title=`Interactive exercise: ${n.title}`,u.style.cssText=`position:absolute;inset:0;width:100%;height:100%;border:0;`,o.append(u);let d=u.contentDocument;if(!d)throw u.remove(),Error(`Could not create the reader-owned activity frame.`);let f=d.createElement(`meta`);f.httpEquiv=`Content-Security-Policy`,f.content=`default-src 'none'; style-src 'unsafe-inline'`,d.head.append(f),d.title=n.title,d.documentElement.lang=i.documentElement.lang;let p=d.createElement(`style`);p.textContent=`
    html, body { box-sizing: border-box; margin: 0; width: 100%; height: 100%; overflow: hidden; }
    h1 { margin: 0 0 1em; font-size: 1.3em; }
    h2 { margin: 0 0 0.75em; font-size: 1.1em; }
    .word-search-board { overflow: auto; }
    [data-word-search-grid] {
      width: 100%; min-width: 0; table-layout: fixed; border-collapse: collapse; margin: 0 auto;
      color: var(--reader-matching-greek, #0070c0);
    }
    [data-word-search-grid] td { position: relative; border: 0; padding: 0; text-align: center; }
    [data-word-search-grid] td > span { display: grid; place-items: center; aspect-ratio: 1; width: 100%; line-height: 1; }
    [data-word-search-words] { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); margin: 0; padding: 0; list-style: none; gap: 0.3em 1em; }
    [data-word-search-words] > li { color: var(--reader-matching-greek, #0070c0); }
    .crossword-layout { display: grid; gap: 1em; align-items: center; }
    .crossword-clues { gap: 1em; }
    .crossword-clues ol { list-style: none; padding: 0; }
    .crossword-grid { table-layout: fixed; border-collapse: collapse; }
    .crossword-grid td { position: relative; padding: 0; }
    .crossword-grid td::before { content: ''; display: block; padding-top: 100%; }
    .crossword-cell { border: 1px solid currentColor; }
    .crossword-number { position: absolute; top: 0; left: 2px; font: 10px sans-serif; }
  `,d.head.append(p);let m=d.createElement(`main`);m.setAttribute(`data-study-cheetah-activity`,n.kind),m.setAttribute(`data-activity-id`,n.id),m.setAttribute(`data-activity-revision`,n.revision),n.chapterTitle&&m.setAttribute(`data-chapter-title`,n.chapterTitle),s||(m.className=c?`crossword`:`word-search`);let h=d.createElement(`h1`);h.textContent=n.title,m.append(h);for(let e of t.querySelectorAll(`:scope > p`)){if(a.getComputedStyle(e).display===`none`)continue;let t=d.createElement(`p`);t.textContent=e.textContent,m.append(t)}if(n.kind===`matching-v1`){let e=d.createElement(`div`);e.className=`matching-columns`;for(let[t,r,i]of[[`Greek words`,n.prompts,!0],[`English meanings`,n.choices,!1]]){let n=d.createElement(`section`),a=d.createElement(`h2`);a.textContent=t;let o=d.createElement(`ol`);o.setAttribute(i?`data-matching-prompts`:`data-matching-choices`,``);for(let e of r){let t=d.createElement(`li`);t.setAttribute(i?`data-match-id`:`data-choice-id`,e.id);let n=d.createElement(`span`);n.setAttribute(i?`data-prompt-text`:`data-choice-text`,``),n.textContent=e.text,e.language&&(n.lang=e.language,t.lang=e.language),t.append(n),o.append(t)}n.append(a,o),e.append(n)}m.append(e)}else if(n.kind===`crossword-v1`){let e=d.createElement(`div`);e.className=`crossword-layout`;let t=d.createElement(`div`);t.className=`crossword-clues`;for(let e of[`across`,`down`]){let r=d.createElement(`section`),i=d.createElement(`h2`);i.textContent=e===`across`?`Across`:`Down`;let a=d.createElement(`ol`);for(let t of n.clues.filter(t=>t.direction===e)){let e=d.createElement(`li`);e.dataset.entryId=t.id,a.append(e)}r.append(i,a),t.append(r)}let r=d.createElement(`table`);r.className=`crossword-grid`;let i=d.createElement(`tbody`);for(let[e,t]of n.cells.entries()){let r=d.createElement(`tr`);for(let[i,a]of t.entries()){let t=d.createElement(`td`);t.className=a?`crossword-cell`:`crossword-empty`;let o=n.clues.find(t=>t.row===e&&t.column===i);if(o){let e=d.createElement(`span`);e.className=`crossword-number`,e.textContent=String(o.number),t.append(e)}r.append(t)}i.append(r)}r.append(i),e.append(t,r),m.append(e)}else{let e=d.createElement(`div`);e.setAttribute(`data-word-search-layout`,``);let t=d.createElement(`div`);t.className=`word-search-board`;let r=d.createElement(`table`);r.setAttribute(`data-word-search-grid`,``),r.setAttribute(`aria-label`,`Greek word search, ${n.grid.length} rows by ${n.grid[0].length} columns`),r.lang=`el`;let i=d.createElement(`tbody`);for(let e of n.grid){let t=d.createElement(`tr`);for(let n of e){let e=d.createElement(`td`),r=d.createElement(`span`);r.textContent=n,e.append(r),t.append(e)}i.append(t)}r.append(i),t.append(r);let a=d.createElement(`section`);a.className=`word-search-vocabulary`;let o=d.createElement(`h2`);o.textContent=`Words to find`;let s=d.createElement(`ul`);s.setAttribute(`data-word-search-words`,``),s.lang=`el`;for(let e of n.words){let t=d.createElement(`li`);t.setAttribute(`data-word-id`,e.id),t.textContent=e.text,s.append(t)}a.append(o,s),e.append(t,a),m.append(e)}d.body.append(m);let g;try{g=n.kind===`matching-v1`?Pt(m,n,r):n.kind===`crossword-v1`?Ht(m,n,r):It(m,n,r)}catch(e){throw u.remove(),e}let _=e.getAttribute(`aria-hidden`),v=e.getAttribute(`tabindex`),y=e.style.opacity;e.setAttribute(`aria-hidden`,`true`),e.setAttribute(`tabindex`,`-1`),e.setAttribute(l,``),e.style.opacity=`0`;let b=()=>{let e=a.getComputedStyle(i.body),r=a.getComputedStyle(i.documentElement);d.documentElement.style.fontSize=r.fontSize,d.documentElement.style.backgroundColor=r.backgroundColor;for(let t of[`width`,`height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`transform`,`transform-origin`,`font-size`,`font-family`,`line-height`,`color`,`background-color`,`--reader-page-fg`,`--reader-page-bg`,`--reader-matching-correct`,`--reader-matching-incorrect`,`--reader-matching-reset`,`--reader-matching-greek`,...G,`--reader-control-greek`,`--reader-control-check`,`--reader-control-reset`,`--reader-control-print`])d.body.style.setProperty(t,e.getPropertyValue(t));d.body.style.lineHeight=e.lineHeight===`normal`?`normal`:String(parseFloat(e.lineHeight)/parseFloat(e.fontSize));let o=a.getComputedStyle(t);if(m.style.rowGap=o.rowGap,m.style.columnGap=o.columnGap,n.kind===`word-search-v1`){let e=t.querySelector(`[data-word-search-words]`),n=m.querySelector(`[data-word-search-words]`),r=a.getComputedStyle(e);for(let e of[`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`row-gap`,`column-gap`])n.style.setProperty(e,r.getPropertyValue(e))}let s=[...t.querySelectorAll(`h1,h2`)];for(let[e,t]of[...m.querySelectorAll(`h1,h2`)].entries()){let n=s[e];if(!n)continue;let r=a.getComputedStyle(n);for(let e of[`font-size`,`font-family`,`font-weight`,`line-height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`])t.style.setProperty(e,r.getPropertyValue(e))}};b();let x=new MutationObserver(b);x.observe(i.head,{subtree:!0,childList:!0,characterData:!0,attributes:!0}),x.observe(i.body,{attributes:!0}),x.observe(i.documentElement,{attributes:!0});let S=new ResizeObserver(b);return S.observe(e),{root:m,cleanup:()=>{x.disconnect(),S.disconnect(),g(),u.remove(),e.removeAttribute(l),_===null?e.removeAttribute(`aria-hidden`):e.setAttribute(`aria-hidden`,_),v===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,v),e.style.opacity=y}}}function Wt(e){let{pointerX:t,pointerY:n,screenWidth:r,screenHeight:i,hasPreviousChapter:a,hasNextChapter:o}=e,s=r*.33,c=r*.67,l=i*.33,u=i*.67;return t<s&&a?`previous`:t>c&&o?`next`:t>=s&&t<=c&&n>=l&&n<=u?`toggle-ui`:`none`}var Gt=5e3;function Kt(){let e=document.activeElement;e instanceof Element&&(e.closest(`.chapter-menu`)?document.querySelector(`.reading-header .menu-button`)?.focus():e.closest(`.adjustment-popup`)?e.closest(`.reader-adjustment-control`)?.querySelector(`button[aria-expanded]`)?.focus():e.closest(`.theme-settings-panel`)&&e.closest(`.theme-settings`)?.querySelector(`.settings-trigger`)?.focus())}function qt(e,t,n,r,i=()=>!1){let a;function o(){clearTimeout(a),a=void 0}function s(){o(),e()&&(a=setTimeout(()=>{t()?n():i()?s():r()},Gt))}return{pause:o,reset:s}}var Jt=i(`<div class="loading-overlay svelte-1jg2usx"><div class="spinner svelte-1jg2usx" aria-hidden="true"></div> <p>Opening book...</p></div>`),Yt=i(`<button class="svelte-1jg2usx">Retry</button>`);i(`<button class="svelte-1jg2usx">Back to library</button>`);var Xt=i(`<div class="error-overlay svelte-1jg2usx" role="alert"><p class="error-title svelte-1jg2usx">Could not open book</p> <p class="error-body svelte-1jg2usx"> </p> <!></div>`),Zt=i(`<img alt="" class="cover-image"/>`),Qt=i(`<p> </p>`),$t=i(`<div class="cover-fallback" aria-hidden="true"><p> </p> <!></div>`),en=i(`<button class="cover-overlay" type="button" aria-label="Start reading"><div class="cover-page svelte-1jg2usx" role="img"><!></div></button>`),tn=i(`<p class="save-error svelte-1jg2usx" role="alert"> </p>`),nn=i(`<div aria-hidden="true"></div> <div aria-hidden="true"></div>`,1),rn=i(`<div role="main"><dialog class="safari-warning svelte-1jg2usx" aria-labelledby="safari-warning-title" aria-describedby="safari-warning-description"><h2 id="safari-warning-title" class="svelte-1jg2usx">Safari reader limitations</h2> <p id="safari-warning-description" class="svelte-1jg2usx">Tap the left or right edge to turn pages. Other book interactions and
      some keyboard shortcuts may not work in Safari. Use the
      header or footer to show the chapter menu in the header and position slider in the footer.</p> <form method="dialog"><button type="submit" class="svelte-1jg2usx">Continue reading</button></form></dialog> <!> <!> <div class="epub-viewport svelte-1jg2usx"><!> <!> <!> <!></div> <!> <!></div> <!>`,1);function an(e,r){L(r,!0);let i=`study-cheetah.reader.display-mode`,f=Se.getInstance(),m=Ce.getInstance(),_=ee(),v=ae(),y=h(null),b=h(s([])),x=h(0),S=h(`best-fit`),C=h(null),w=h(1),T=h(!0),D=h(!1),A=h(!1),R=h(null),z=h(!1),B=h(null),V,W=h(!1),te=h(!0),G=h(!0),oe=h(null),se=h(null),le=h(null),de=h(null),fe=h(null),pe=h(void 0),me=h([]),ge=h(new Map),K=h(new Set),_e=h(new Map),ve=h(new Map),ye=h(null),be,J=null,Y=!1,we=!1,Ee,X,Oe=0,ke=0,Ae=0,Z=!1,je=new Set,Me=Promise.resolve(),Ne=!1,Q=new AbortController,$=new Map,Pe=new Map,Fe=new Map,Ie=d(()=>u(b)[u(x)]),Le=d(()=>{let e=u(me).filter(e=>u(C)&&e.spineIndex>=u(C).start.index&&e.spineIndex<=u(C).end.index);return[...e].reverse().find(t=>t.spineIndex===e[0].spineIndex)}),ze=d(()=>u(Le)?.activity),Be=d(()=>u(Le)&&!u(W)?u(ge).get($e(u(Le).viewId,u(Le).activity)):void 0),Ve=d(()=>u(Be)&&u(ze)?.kind===`crossword-v1`&&u(de)?JSON.stringify([u(de).publicationId,u(ze).id]):void 0),He=d(()=>u(Ve)&&!u(K).has(u(Ve))?u(Ve):void 0),Ue=d(()=>{let e=u(C);if(!e||u(W)||u(G)||u(oe))return null;let t=t=>t>=e.start.index&&t<=e.end.index;return[...u(_e).values()].some(t)?[...u(ve).values()].some(t)?`activity`:`ordinary`:null}),We=d(()=>u(ye)??u(ze)),Ge=d(()=>u(C)?.atEnd?100:Math.round((u(C)?.start.percentage??0)*100)),Ke=d(()=>v.resolved.endsWith(`-dark`)?`dark`:`light`),qe=d(()=>ne(u(y)?.accessibility.theme,v.readerTheme)),Je=d(()=>ie(u(qe),v.palette,u(Ke))),Ye=h(s(re(!1))),Xe=d(()=>`Section page ${u(C)?.start.displayed.page??1} of ${u(C)?.start.displayed.total??1}`),Ze=d(()=>u(W)?`Tap to start reading`:`${u(Ge)}% complete`),Qe;function $e(e,t){return JSON.stringify([e,t.kind,t.id])}function et(e){u(K).has(e)||g(K,new Set(u(K)).add(e))}function tt(e){if(u(K).has(e)){let t=new Set(u(K));t.delete(e),g(K,t)}}function nt(){g(T,!1),o().then(()=>{document.querySelector(`.reading-footer .activity-footer-actions button:not([aria-pressed]):not(:disabled)`)?.focus()})}let rt=qt(()=>u(T),()=>(u(D)||u(A)||u(R)!==null)&&!document.querySelector(`.reading-header .install-help[open]`),()=>{Kt(),g(D,!1),g(A,!1),g(R,null)},()=>{g(T,!1)},()=>!!document.querySelector(`dialog[open], .reading-header .install-help[open]`));p(()=>{u(T)||(g(D,!1),g(A,!1),g(R,null)),u(D),u(A),u(R),je.size?rt.pause():rt.reset()}),p(()=>{u(qe),v.palette,u(Ke),St()});function at(e,t){Y||(console.error(`[Reader] ${e}:`,t),g(oe,`${t instanceof Error?t.message:String(t)}\n\nStage: ${e}`))}function ot(){let e=new URLSearchParams(window.location.search),t=e.get(`mode`)??(e.has(`horizontalPaging`)||e.has(`twoPage`)?null:localStorage.getItem(i));if(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)return t;t!==null&&console.warn(`[Reader] Unrecognized reading view:`,t);let n=e.get(`horizontalPaging`)??localStorage.getItem(`study-cheetah.reader.horizontal-paging`),r=e.get(`twoPage`)??localStorage.getItem(`study-cheetah.reader.two-page`);return n===`1`||n===`true`?`single`:r===`1`||r===`true`?`spread`:n===`0`||n===`false`?`scroll`:`best-fit`}function st(){if(!u(y)||!Ne)return Me;Ne=!1;let e=u(y);return Me=Me.then(()=>f.updateBook(e)).then(()=>{g(se,null)}).catch(e=>{console.error(`[Reader] Saving reading preferences and position failed:`,e),Ne=!0,g(se,`Could not save your reading position and preferences.`)}),Me}function ct(){if(Ne=!0,u(y))try{f.checkpointReadingState(u(y))}catch(e){console.error(`[Reader] Checkpointing reading preferences and position failed:`,e),g(se,`Could not save your reading position and preferences.`)}clearTimeout(X),X=setTimeout(()=>{st()},500)}function lt(e){if(g(C,e),u(b)[u(x)]?.spineIndex!==e.start.index){let t=u(b).findIndex(t=>t.spineIndex===e.start.index);t>=0&&g(x,t,!0)}!u(y)||we||Y||(g(y,{...u(y),currentLocation:{chapterId:u(Ie)?.id??String(e.start.index),chapterIndex:u(x),elementOffset:0,percentageComplete:Math.round((e.start.percentage??0)*100),cfiFragment:e.start.cfi}},!0),ct())}function ut(e){if(e!==J||Y)return;let t=e.currentLocation();t&&lt(t)}function dt(){for(let e of $.values())e();$.clear(),g(me,[]),g(ge,new Map),g(_e,new Map),g(ve,new Map)}function ft(e){let t=!1,n=()=>{t=!0};return e.addEventListener(`study-cheetah-event-probe`,n),e.dispatchEvent(new Event(`study-cheetah-event-probe`)),e.removeEventListener(`study-cheetah-event-probe`,n),t}function pt(e){return!!e&&`closest`in e&&typeof e.closest==`function`&&!!e.closest(`a, button, input, select, textarea, summary, [contenteditable="true"], [role="button"], [role="link"], [data-study-cheetah-enhanced]`)}function mt(e){if(u(A)&&e.key===`Escape`){e.preventDefault(),g(A,!1),document.querySelector(`.settings-trigger`)?.focus();return}if(!je.size&&(u(D)||u(A)||u(R))&&e.target instanceof Element&&e.target.closest(`.reading-header, .reading-footer`)&&rt.reset(),document.querySelector(`dialog[open]`)||e.defaultPrevented||e.ctrlKey||e.metaKey||pt(e.target))return;if(e.altKey){!e.shiftKey&&(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),Mt(e.key===`ArrowDown`?1:-1));return}if(e.key===`Escape`){if(V.ownsFullscreen())return;e.preventDefault(),ht();return}let t=e.key===`ArrowRight`||e.key===`PageDown`,n=e.key===`ArrowLeft`||e.key===`PageUp`;!t&&!n||(e.preventDefault(),kt(t?1:-1))}function ht(){rt.pause(),g(T,!u(T)),u(T)&&_t()}function gt(){u(z)?(g(B,null),V.leave(),g(z,!1)):(g(B,null),V.enter(),g(z,!0),rt.pause(),g(T,!1))}function _t(){rt.reset()}function vt(e,t){if(u(W)||u(G)||document.querySelector(`dialog[open]`))return;if(!u(T)&&(t<=60||t>=window.innerHeight-60)){ht();return}let n=Wt({pointerX:e,pointerY:t,screenWidth:window.innerWidth,screenHeight:window.innerHeight,hasPreviousChapter:!0,hasNextChapter:!u(C)?.atEnd});n===`toggle-ui`?ht():(n===`next`||n===`previous`)&&kt(n===`next`?1:-1)}function yt(e){e.on(`relocated`,t=>{e===J&&!Y&&lt(t)}),e.on(`layout`,t=>{e===J&&g(w,t.divisor,!0)}),e.on(`rendered`,(t,n)=>{if(e!==J||Y)return;$.get(n.id)?.();let r=n.document,i=n.iframe;if(!r||!i)return;i.title=`Book content`;let a=ft(r),o=n.section.index;if(typeof o==`number`){let e=new Map(u(_e)),t=new Map(u(ve));a?e.delete(n.id):e.set(n.id,o),r.querySelector(`[data-study-cheetah-activity]`)?t.set(n.id,o):t.delete(n.id),g(_e,e),g(ve,t)}let s=[],c=new Set,l=u(de);if(l){let e=[];for(let t of l.features){let o=[];try{let c=n.section.index;if(typeof c!=`number`)throw Error(`Exercise reading-order position is unavailable.`);let d=[...r.querySelectorAll(`[data-study-cheetah-activity="${t}"]`)].map(e=>{let s=t===`word-search-v1`?xe(e):t===`crossword-v1`?he(e):Te(e),d=e.parentElement===r.body&&r.querySelectorAll(`[data-study-cheetah-activity]`).length===1,f={publicationId:l.publicationId,onprint:()=>{bt(s)},...d?{onfocuscontrols:nt}:{}};d&&(e.setAttribute(`data-sc-external-footer`,``),o.push(()=>e.removeAttribute(`data-sc-external-footer`)));let p=e;if(s.kind===`word-search-v1`){if(o.push(It(e,s,f)),!a&&e.parentElement===r.body){let t=Ut(i,e,s,f);p=t.root,o.push(t.cleanup)}}else if(s.kind===`crossword-v1`){let t=JSON.stringify([l.publicationId,s.id]),n={...f,keyboardVisible:Fe.get(t)??!0,onkeyboardvisibilitychange:e=>{Fe.set(t,e)},onkeyboardshow:()=>tt(t),ontyping:()=>et(t)};if(o.push(Ht(e,s,n)),!a&&e.parentElement===r.body){let t=Ut(i,e,s,n);p=t.root,o.push(t.cleanup)}}else{let t=JSON.stringify([l.publicationId,s.id,s.revision]);if(o.push(Pt(e,s,{...f,order:Pe.get(t),onorder:e=>{Pe.set(t,e)}})),!a&&e.parentElement===r.body){let n=Ut(i,e,s,{...f,order:Pe.get(t),onorder:e=>{Pe.set(t,e)}});p=n.root,o.push(n.cleanup)}}if(d){let e=$e(n.id,s);o.push(jt(p,t=>{g(ge,new Map(u(ge)).set(e,t))})),o.push(()=>{let t=new Map(u(ge));t.delete(e),g(ge,t)})}return{viewId:n.id,spineIndex:c,activity:s}});e.push(...d),s.push(...o)}catch(e){c.add(t);for(let e of o)e();console.error(`[Reader] Invalid ${t} exercise:`,e),g(le,`Interactive exercise unavailable: ${e instanceof Error?e.message:String(e)}`)}}g(me,[...u(me).filter(e=>e.viewId!==n.id),...e])}if(u(fe)){let e=u(fe).active.filter(e=>!c.has(e));s.push(q(r,u(fe),e))}let d=0,f=0,p=e=>{g(A,!1),d=e.clientX,f=e.clientY},m=e=>{if(pt(e.target)||r.getSelection()?.isCollapsed===!1||Math.hypot(e.clientX-d,e.clientY-f)>10)return;let t=i.getBoundingClientRect();vt(t.left+e.clientX,t.top+e.clientY)};r.addEventListener(`pointerdown`,p),r.addEventListener(`pointerup`,m),r.addEventListener(`keydown`,mt),$.set(n.id,()=>{for(let e of s)e();r.removeEventListener(`pointerdown`,p),r.removeEventListener(`pointerup`,m),r.removeEventListener(`keydown`,mt)})}),e.on(`removed`,(e,t)=>{$.get(t.id)?.(),$.delete(t.id),g(me,u(me).filter(e=>e.viewId!==t.id));let n=new Map(u(_e)),r=new Map(u(ve));n.delete(t.id),r.delete(t.id),g(_e,n),g(ve,r)}),e.on(`displayerror`,t=>{e===J&&!Y&&at(`chapter-display`,t)})}async function bt(e){g(ye,e,!0);try{await o(),window.print()}catch(e){console.error(`[Reader] Printing worksheet failed:`,e),g(le,`Could not print worksheet: ${e instanceof Error?e.message:String(e)}`)}finally{g(ye,null)}}async function xt(e,t){let n,r=()=>{},i=new Promise((t,i)=>{r=i,n=setTimeout(()=>i(Error(`Chapter rendering timed out (15s).`)),15e3),e.on(`displayerror`,r)}),a=()=>r(Error(`Reader closed before chapter rendering completed.`));Q.signal.addEventListener(`abort`,a,{once:!0});try{await Promise.race([e.display(t),i])}finally{clearTimeout(n),e.off(`displayerror`,r),Q.signal.removeEventListener(`abort`,a)}}function St(){g(Ye,re(!!document.documentElement.getAttribute(`data-ui-theme`)?.endsWith(`dark`)),!0),u(y)&&m.applyTheme(u(y).id,{...u(y).accessibility,theme:u(qe),appPalette:v.palette,appTone:u(Ke)})}async function wt(e){if(!u(y)||Y)return;let t=u(S)===`best-fit`&&!await m.supportsBestFit(u(y).id)?`spread`:u(S);if(Y)return;dt();let n=m.attachRenderer(u(y).id,be,t);J=n,yt(n),await n.started,!(Y||n!==J)&&(n.spread(t===`spread`?`auto`:`none`,1e3),St(),await xt(n,e),ut(n))}async function Tt(){try{g(S,ot(),!0);let e;if(e=await De(),!e)throw Error(`The selected book was not found in your library.`);if(Y)return;g(y,e,!0),_.applyBookRecord({...e,epubVersion:``});let t=await m.loadBook(e.id,e.opfsPath),n=await m.getMetadata(e.id);if(Y)return;if(g(y,{...e,epubVersion:n.version??``},!0),_.applyBookRecord(u(y)),n.version&&n.version!==e.epubVersion)try{await f.updateBookEpubVersion(e.id,e.hash,n.version)}catch(e){console.warn(`[Reader] Could not save corrected EPUB version:`,e)}try{g(de,await m.getActivityCapability(e.id),!0),g(fe,await m.getExtensionCapability(e.id),!0)}catch(e){console.error(`[Reader] Invalid publication extension declaration:`,e),g(le,`Book enhancements unavailable: ${e instanceof Error?e.message:String(e)}`)}if(g(b,await m.getChapters(e.id),!0),Y||(t.locations.length()===0&&await t.locations.generate(1e3),Y)||(g(x,Math.max(0,Math.min(e.currentLocation?.chapterIndex??0,u(b).length-1)),!0),g(W,!0),await wt(e.currentLocation?.cfiFragment??(e.currentLocation?u(b)[u(x)]?.href:void 0)??0),Y))return;e.currentLocation&&(Ee=setTimeout(Dt,2e3)),_t()}catch(e){Y||at(`reader-init`,e)}finally{Y||(g(G,!1),g(te,!1))}}async function Et(e){if(u(G)||!J||e===u(S))return;let t=J.currentLocation()?.start.cfi??u(y)?.currentLocation?.cfiFragment??0;g(G,!0),we=!0,g(S,e,!0);try{localStorage.setItem(i,e),await wt(t)}catch(e){at(`reading-view`,e)}finally{we=!1,g(G,!1),J&&ut(J)}}function Dt(){clearTimeout(Ee),g(W,!1)}async function kt(e){let t=J;if(!t||u(G)||u(oe))return;if(u(W)){e===1&&Dt();return}let n=t.currentLocation();if(e===-1&&n?.atStart){g(W,!0);return}if(!(e===1&&n?.atEnd)){g(G,!0);try{e===1?await t.next():await t.prev(),ut(t)}catch(e){at(`page-navigation`,e)}finally{g(G,!1)}}}async function At(e){let t=u(b)[e],n=J;if(!(!t||!n||u(G))){g(G,!0),Dt();try{await xt(n,t.href??t.spineIndex),g(x,e,!0),ut(n)}catch(e){at(`chapter-navigation`,e)}finally{g(G,!1)}}}async function Mt(e){let t=J;if(!(!u(y)||!t||u(G)||u(oe)||!u(b).length))try{let n=t.currentLocation();if(!n)throw Error(`Reading position is not ready for chapter navigation.`);let r=m.getChapterPosition(u(y).id,u(b),n,u(x)),i=e===1?r.chapterIndex+1:r.atBeginning?r.chapterIndex-1:r.chapterIndex;for(;i>=0&&i<u(b).length&&u(b)[i].spineIndex<0;)i+=e;i>=0&&i<u(b).length&&await At(i)}catch(e){at(`chapter-navigation`,e)}}async function Nt(e){let t=J;if(!(!u(y)||!t||u(G)||u(oe))){g(G,!0);try{let n=m.getCfiFromPercentage(u(y).id,e/100);Dt(),await xt(t,n),ut(t)}catch(e){at(`position-navigation`,e)}finally{g(G,!1)}}}async function Ft(e,t){let n=J;if(!u(y)||!n||u(G))return;let r=n.currentLocation()?.start.cfi??0;g(y,{...u(y),accessibility:{...u(y).accessibility,[e]:Math.min(2,Math.max(e===`fontSize`?.75:1,Math.round(t*100)/100))}},!0),g(G,!0),we=!0;try{n.clear(),St(),await xt(n,r)}catch(e){at(`typography`,e)}finally{we=!1,g(G,!1),ut(n),ct()}}function Lt(e){!u(y)||u(G)||(g(y,{...u(y),accessibility:{...u(y).accessibility,theme:e}},!0),St(),ct())}function Rt(e){Z=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`),(Z||pt(e.target))&&(je.add(e.pointerId),rt.pause()),ke=e.clientX,Ae=e.clientY}function zt(e){if(pt(e.target)||Math.hypot(e.clientX-ke,e.clientY-Ae)>10)return;let t=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`);if(Z||t){Z&&t&&!u(T)&&ht();return}vt(e.clientX,e.clientY)}function Bt(){Z=!1}function Vt(e){!je.size&&(u(D)||u(A)||u(R))&&e.target instanceof Element&&e.target.closest(`.chapter-menu, .adjustment-popup, .theme-settings-panel`)&&rt.reset()}function Gt(e){je.delete(e.pointerId)&&!je.size&&rt.reset()}function an(){je.clear(),rt.reset()}function on(e){!je.size&&(u(D)||u(A)||u(R))&&rt.reset(),u(W)&&e.deltaY>0&&(e.preventDefault(),Dt())}I(()=>{V=ue(()=>{g(z,!1),g(T,!0),_t()},e=>{g(B,e,!0)});let e=navigator.userAgent;/\bVersion\/[\d.]+.*\bSafari\//.test(e)&&!/\b(?:Chrome|Chromium|CriOS|FxiOS|Edg|EdgiOS|EdgA|OPR|OPiOS|DuckDuckGo)\//i.test(e)&&Qe.showModal(),window.addEventListener(`keydown`,mt),window.addEventListener(`pointerup`,Gt),window.addEventListener(`pointercancel`,Gt),window.addEventListener(`blur`,an);let t=new ResizeObserver(()=>{cancelAnimationFrame(Oe),Oe=requestAnimationFrame(()=>{if(!J||u(G)||Y||!be.clientWidth||!be.clientHeight)return;let e=J.currentLocation()?.start.cfi;J.resize(be.clientWidth,be.clientHeight,e)})});t.observe(be);let n=new MutationObserver(()=>St());return n.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-ui-theme`]}),Tt(),()=>{Y=!0,V.destroy(),Q.abort(),t.disconnect(),n.disconnect(),cancelAnimationFrame(Oe),window.removeEventListener(`keydown`,mt),window.removeEventListener(`pointerup`,Gt),window.removeEventListener(`pointercancel`,Gt),window.removeEventListener(`blur`,an),rt.pause(),clearTimeout(Ee),clearTimeout(X),st(),dt(),u(y)&&m.detachRenderer(u(y).id),J=null}});var sn=rn(),cn=c(sn);let ln;var un=a(cn);M(un,e=>Qe=e,()=>Qe);var dn=F(un,2),fn=e=>{Ot(e,{get capability(){return u(fe)},onready:e=>{g(pe,e,!0)}})};U(dn,e=>{u(fe)&&!u(te)&&!u(W)&&e(fn)});var pn=F(dn,2),mn=e=>{{let t=d(()=>_.appName||u(y).title||u(y).filename),n=d(()=>u(ze)?.chapterTitle??u(Ie)?.label),r=d(()=>u(y).accessibility.theme??`inherit`),i=d(()=>void 0);Re(e,{get bookTitle(){return u(t)},get chapterTitle(){return u(n)},get controlsVisible(){return u(T)},get readerTheme(){return u(r)},get displayMode(){return u(S)},get busy(){return u(G)},onDisplayModeChange:Et,onReaderThemeChange:Lt,get settingsOpen(){return u(A)},onSettingsOpenChange:e=>{g(A,e,!0),e&&(g(D,!1),g(R,null))},get onClose(){return u(i)},get embedded(){return!0},get onFeatures(){return u(pe)},get chapters(){return u(b)},get currentChapterIndex(){return u(x)},get chapterMenuOpen(){return u(D)},onChapterMenuChange:e=>{g(D,e,!0),e&&g(A,!1)},onChapterSelect:At,get immersive(){return u(z)},onImmersiveChange:gt})}};U(pn,e=>{u(y)&&e(mn)});var hn=F(pn,2),gn=a(hn),_n=e=>{H(e,Jt())},vn=e=>{var r=Xt(),i=F(a(r),2),o=a(i,!0);N(i);var s=F(i,2),c=e=>{var t=Yt();E(`click`,t,()=>window.location.reload()),H(e,t)};U(s,e=>{e(c)}),N(r),t(()=>n(o,u(oe))),H(e,r)},yn=e=>{var r=en(),i=a(r),o=a(i),s=e=>{var n=Zt();t(()=>O(n,`src`,u(y).coverImage)),H(e,n)},c=e=>{var r=$t(),i=a(r),o=a(i,!0);N(i);var s=F(i,2),c=e=>{var r=Qt(),i=a(r,!0);N(r),t(()=>n(i,u(y).author)),H(e,r)};U(s,e=>{u(y).author&&e(c)}),N(r),t(()=>n(o,u(y).title??u(y).filename)),H(e,r)};U(o,e=>{u(y).coverImage?e(s):e(c,-1)}),N(i),N(r),t(()=>O(i,`aria-label`,`Cover for ${u(y).title??u(y).filename}`)),E(`click`,r,Dt),H(e,r)};U(gn,e=>{u(te)?e(_n):u(oe)?e(vn,1):u(W)&&u(y)&&e(yn,2)});var bn=F(gn,2),xn=e=>{var r=tn(),i=a(r,!0);N(r),t(()=>n(i,u(se))),H(e,r)};U(bn,e=>{u(se)&&e(xn)});var Sn=F(bn,2),Cn=e=>{var r=tn(),i=a(r,!0);N(r),t(()=>n(i,u(le))),H(e,r)};U(Sn,e=>{u(le)&&e(Cn)});var wn=F(Sn,2),Tn=e=>{var n=nn(),r=c(n);let i;var a=F(r,2);let o;t(()=>{i=k(r,1,`page-turn-zone previous svelte-1jg2usx`,null,i,{activity:u(Ue)===`activity`}),o=k(a,1,`page-turn-zone next svelte-1jg2usx`,null,o,{activity:u(Ue)===`activity`})}),H(e,n)};U(wn,e=>{u(Ue)&&e(Tn)}),N(hn),M(hn,e=>be=e,()=>be);var En=F(hn,2),Dn=e=>{{let t=d(()=>u(Ie)?.label??`Front matter`),n=d(()=>!u(W)&&!!u(C)?.atEnd);it(e,{get controlsVisible(){return u(T)},get fontSize(){return u(y).accessibility.fontSize},get lineHeight(){return u(y).accessibility.lineHeight},get progressPercent(){return u(Ge)},get currentChapterIndex(){return u(x)},get totalChapters(){return u(b).length},get chapterPositionLabel(){return u(t)},get pageLabel(){return u(Xe)},get progressLabel(){return u(Ze)},get activityFooter(){return u(Be)},get crosswordHintKey(){return u(He)},onDismissCrosswordHint:et,get busy(){return u(G)},onFontSizeChange:e=>Ft(`fontSize`,e),onLineHeightChange:e=>Ft(`lineHeight`,e),onProgressChange:Nt,onPreviousPage:()=>kt(-1),onNextPage:()=>kt(1),get previousPageDisabled(){return u(W)},get nextPageDisabled(){return u(n)},get chapterMenuOpen(){return u(D)},onAdjustmentOpen:()=>{g(D,!1),g(A,!1)},get openControl(){return u(R)},set openControl(e){g(R,e,!0)}})}};U(En,e=>{u(y)&&e(Dn)}),ce(F(En,2),{get message(){return u(B)},onDismiss:()=>{g(B,null)}}),N(cn);var On=F(cn,2),kn=e=>{Ct(e,{get activity(){return u(We)}})};U(On,e=>{u(We)&&e(kn)}),t(()=>{ln=k(cn,1,`reader-shell svelte-1jg2usx`,null,ln,{"show-ui":u(T),immersive:u(z)}),P(cn,`--reader-page-bg: ${u(Je).background}; --reader-page-fg: ${u(Je).foreground}; --reader-page-muted: ${u(Je).muted}; --reader-page-accent: ${u(Je).accent}; --reader-page-border: ${u(Je).border}; --reader-control-check: ${u(Ye).check}; --reader-control-reset: ${u(Ye).reset}; --reader-control-print: ${u(Ye).print};`),O(hn,`aria-busy`,u(G)),O(hn,`data-display-mode`,u(S)),O(hn,`data-start-cfi`,u(C)?.start.cfi),O(hn,`data-end-cfi`,u(C)?.end.cfi),O(hn,`data-spine-index`,u(C)?.start.index),O(hn,`data-page`,u(C)?.start.displayed.page),O(hn,`data-total-pages`,u(C)?.start.displayed.total),O(hn,`data-visible-pages`,u(w))}),E(`pointerdown`,cn,Rt),E(`pointerup`,cn,zt),l(`pointercancel`,cn,Bt),E(`pointermove`,cn,Vt),l(`wheel`,cn,on),E(`pointerdown`,un,e=>e.stopPropagation()),E(`pointerup`,un,e=>e.stopPropagation()),H(e,sn),j()}e([`pointerdown`,`pointerup`,`pointermove`,`click`]);export{an as component,X as universal};