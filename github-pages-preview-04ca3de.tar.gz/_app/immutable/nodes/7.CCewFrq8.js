import{A as e,B as t,C as n,E as r,F as i,G as a,J as o,K as s,N as c,O as l,S as u,T as d,U as f,W as p,X as m,Y as h,Z as g,a as _,at as v,b as y,c as b,d as x,f as S,it as C,j as w,k as T,l as E,lt as D,m as O,n as k,nt as A,o as j,ot as M,p as N,q as P,r as F,s as I,st as L,tt as R,u as z,v as B,w as V,y as H,z as U}from"../chunks/BiXsnc5P.js";import"../chunks/BJB_vpwv.js";import"../chunks/YrkHVkuo.js";import"../chunks/xihTtKlq.js";import"../chunks/CtSNMX7J.js";import{n as ee}from"../chunks/8skaqA67.js";import{n as W}from"../chunks/iaHtoEc7.js";import{n as te,o as ne,r as re,t as ie}from"../chunks/EfuZgBKj.js";import{t as ae}from"../chunks/CLj8_sRO.js";import{a as G,i as oe,n as se,r as K,t as ce}from"../chunks/k1oTkBme.js";import{_ as le,a as ue,b as de,c as fe,d as pe,f as me,g as q,h as he,i as ge,l as _e,m as J,n as ve,o as Y,p as X,r as ye,s as Z,t as be,u as xe,v as Se,y as Ce}from"../chunks/V2eL8t36.js";import{n as we}from"../chunks/DaWgv5gk.js";var Te=D({load:()=>Ee}),Ee=async()=>({readyToRender:!0}),De=d(`<button class="chapter-toggle svelte-1e78rkn" type="button"><svg aria-hidden="true" viewBox="0 0 20 20"><path d="m7 4 6 6-6 6"></path></svg></button>`),Oe=d(`<div><!></div>`),ke=d(`<li><div class="chapter-row svelte-1e78rkn"><button><span class="chapter-number svelte-1e78rkn"> </span> <span class="chapter-label svelte-1e78rkn"> </span></button> <!></div> <!></li>`),Q=d(`<ol class="chapter-entries svelte-1e78rkn"></ol>`),Ae=d(`<button class="close-button svelte-1e78rkn" aria-label="Close reader">✕</button>`),je=d(`<p class="chapter-title svelte-1e78rkn"> </p>`),Me=d(`<button class="features-button svelte-1e78rkn" type="button" aria-label="Book enhancements">Features</button>`),Ne=d(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">View</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reading view"><option>Vertical scroll</option><option>Single page</option><option>Facing pages</option><option>Best fit</option></select></label>`),$=d(`<div class="header-content controls-mode svelte-1e78rkn"><!> <button class="menu-button svelte-1e78rkn" type="button" aria-label="Chapter menu" aria-controls="chapter-menu" title="Chapter menu">☰</button> <div class="header-text svelte-1e78rkn"><h1 class="book-title svelte-1e78rkn"> </h1> <!></div> <div class="header-settings svelte-1e78rkn"><!> <!> <!> <!></div> <!></div>`),Pe=d(`<div class="header-content passive-mode svelte-1e78rkn"><div class="passive-header-text svelte-1e78rkn"><p class="book-title svelte-1e78rkn"> </p> <!></div></div>`),Fe=d(`<div class="chapter-menu svelte-1e78rkn" id="chapter-menu"><div class="chapter-menu-header svelte-1e78rkn"><h2 class="svelte-1e78rkn">Chapters</h2> <button class="close-menu svelte-1e78rkn" type="button" aria-label="Close menu">✕</button></div> <nav class="chapter-list svelte-1e78rkn" aria-label="Table of contents"><!></nav></div>`),Ie=d(`<header tabindex="-1"><!> <!></header>`);function Le(t,r){A(r,!0);let i=(t,a=L,l)=>{let f=m(()=>M(l?.(),``));var h=Q();B(h,23,a,e=>e.id,(t,a,l)=>{let m=g(()=>r.chapters.findIndex(e=>e.id===c(a).id)),h=g(()=>`${c(f)}${c(l)+1}`);var _=ke(),b=p(_),x=p(b);let S;var C=p(x),w=p(C,!0);v(C);var D=s(C,2),k=p(D,!0);v(D),v(x);var A=s(x,2),j=t=>{var r=De(),i=p(r);let s;v(r),U((e,t,n)=>{E(r,`aria-label`,e),E(r,`aria-expanded`,t),E(r,`aria-controls`,`chapter-children-${c(m)}`),r.disabled=d(),s=O(i,0,`svelte-1e78rkn`,null,s,n)},[()=>`${c(T).includes(c(a).id)?`Collapse`:`Expand`} ${c(a).label}`,()=>c(T).includes(c(a).id),()=>({expanded:c(T).includes(c(a).id)})]),e(`click`,r,()=>{o(T,c(T).includes(c(a).id)?c(T).filter(e=>e!==c(a).id):[...c(T),c(a).id],!0)}),n(t,r)};y(A,e=>{c(a).subitems?.length&&e(j)}),v(b);var M=s(b,2),N=e=>{var t=Oe();i(p(t),()=>c(a).subitems,()=>`${c(h)}.`),v(t),U(e=>{E(t,`id`,`chapter-children-${c(m)}`),E(t,`hidden`,e)},[()=>!c(T).includes(c(a).id)]),n(e,t)};y(M,e=>{c(a).subitems?.length&&e(N)}),v(_),U(()=>{S=O(x,1,`chapter-item svelte-1e78rkn`,null,S,{active:c(m)===r.currentChapterIndex}),E(x,`aria-current`,c(m)===r.currentChapterIndex?`location`:void 0),x.disabled=d(),u(w,c(h)),u(k,c(a).label)}),e(`click`,x,()=>{r.onChapterSelect(c(m)),r.onChapterMenuChange(!1)}),n(t,_)}),v(h),n(t,h)},a=_(r,`embedded`,3,!1),l=_(r,`readerTheme`,3,`inherit`),d=_(r,`busy`,3,!1),f=_(r,`settingsOpen`,3,!1),b=_(r,`immersive`,3,!1),C=W(),w=g(()=>C.secure&&!C.installed&&!!C.prompt),T=h(P([])),D=g(()=>{let e=new Set(r.chapters.flatMap(e=>e.subitems?.map(e=>e.id)??[]));return r.chapters.filter(t=>!e.has(t.id))});function k(e){return e.subitems?.some(e=>e.id===r.chapters[r.currentChapterIndex]?.id||k(e))??!1}function j(){r.chapterMenuOpen||o(T,[...new Set([...c(T),...r.chapters.filter(k).map(e=>e.id)])],!0),r.onChapterMenuChange(!r.chapterMenuOpen)}var N=Ie();let F;var I=p(N),z=t=>{var i=$(),o=p(i),m=t=>{var i=Ae();e(`click`,i,function(...e){r.onClose?.apply(this,e)}),n(t,i)};y(o,e=>{r.onClose&&e(m)});var h=s(o,2),_=s(h,2),T=p(_),D=p(T,!0);v(T);var O=s(T,2),k=e=>{var t=je(),i=p(t,!0);v(t),U(()=>u(i,r.chapterTitle)),n(e,t)};y(O,e=>{r.chapterTitle&&e(k)}),v(_);var A=s(_,2),M=p(A),N=t=>{var i=Me();e(`click`,i,function(...e){r.onFeatures?.apply(this,e)}),n(t,i)};y(M,e=>{r.onFeatures&&e(N)});var P=s(M,2),F=t=>{var i=Ne(),a=s(p(i),2),o=p(a);o.value=o.__value=`scroll`;var c=s(o);c.value=c.__value=`single`;var l=s(c);l.value=l.__value=`spread`;var u=s(l);u.value=u.__value=`best-fit`,v(a);var f;x(a),v(i),U(()=>{a.disabled=d(),f!==(f=r.displayMode)&&(a.value=(a.__value=r.displayMode)??``,S(a,r.displayMode))}),e(`change`,a,e=>{let t=e.currentTarget.value;(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)&&r.onDisplayModeChange?.(t)}),n(t,i)};y(P,e=>{r.displayMode&&r.onDisplayModeChange&&e(F)});var I=s(P,2),L=e=>{K(e,{get settingsOpen(){return f()}})};y(I,e=>{a()&&e(L)});var R=s(I,2),z=e=>{{let t=g(()=>a()&&!c(w)&&!C.installed);oe(e,{get open(){return f()},get onOpenChange(){return r.onSettingsOpenChange},get bookTheme(){return l()},get onBookThemeChange(){return r.onReaderThemeChange},get disabled(){return d()},get showInstallHelp(){return c(t)},get installSecure(){return C.secure}})}};y(R,e=>{r.onReaderThemeChange&&r.onSettingsOpenChange&&e(z)}),v(A);var B=s(A,2),V=e=>{G(e,{get immersive(){return b()},get disabled(){return d()},get onclick(){return r.onImmersiveChange}})};y(B,e=>{r.onImmersiveChange&&e(V)}),v(i),U(()=>{E(h,`aria-expanded`,r.chapterMenuOpen),h.disabled=d(),u(D,r.bookTitle)}),e(`click`,h,j),n(t,i)},V=e=>{var t=Pe(),i=p(t),a=p(i),o=p(a,!0);v(a);var c=s(a,2),l=e=>{var t=je(),i=p(t,!0);v(t),U(()=>u(i,r.chapterTitle)),n(e,t)};y(c,e=>{r.chapterTitle&&e(l)}),v(i),v(t),U(()=>u(o,r.bookTitle)),n(e,t)};y(I,e=>{r.controlsVisible?e(z):e(V,-1)});var H=s(I,2),ee=t=>{var a=Fe(),o=p(a),l=s(p(o),2);v(o);var u=s(o,2);i(p(u),()=>c(D)),v(u),v(a),e(`click`,l,()=>r.onChapterMenuChange(!1)),n(t,a)};y(H,e=>{r.controlsVisible&&r.chapterMenuOpen&&e(ee)}),v(N),U(()=>F=O(N,1,`reading-header svelte-1e78rkn`,null,F,{"controls-visible":r.controlsVisible,embedded:a()})),n(t,N),R()}T([`click`,`change`]);var Re=d(`<div role="group"><div class="popup-heading svelte-4847e9"><span> </span> <output> </output></div> <div class="adjustment-row svelte-4847e9"><button class="adjust-button svelte-4847e9" type="button">-</button> <input type="range" class="svelte-4847e9"/> <button class="adjust-button svelte-4847e9" type="button">+</button></div></div>`);function ze(t,r){A(r,!0);let i=_(r,`align`,3,`left`),a=h(null),l=null,d=g(()=>c(a)??r.value);function f(e){o(a,e,!0),r.onPreview?.(e)}function m(e){e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),r.onEscape())}k(()=>r.onPreview?.(null));var y=Re();let x;var S=p(y),C=p(S),T=p(C,!0);v(C);var D=s(C,2),j=p(D,!0);v(D),v(S);var M=s(S,2),N=p(M),P=s(N,2);b(P);var F=s(P,2);v(M),v(y),U((e,t)=>{x=O(y,1,`adjustment-popup svelte-4847e9`,null,x,{"align-right":i()===`right`,"align-center":i()===`center`}),E(y,`id`,r.id),E(y,`aria-label`,`${r.label} adjustment`),u(T,r.label),u(j,e),E(N,`aria-label`,r.decreaseLabel),N.disabled=r.disabled||r.decreaseDisabled,E(P,`min`,r.min),E(P,`max`,r.max),E(P,`step`,r.step),z(P,c(d)),E(P,`aria-label`,r.label),E(P,`aria-valuetext`,t),P.disabled=r.disabled,E(F,`aria-label`,r.increaseLabel),F.disabled=r.disabled||r.increaseDisabled},[()=>r.format(c(d)),()=>r.valueText(c(d))]),e(`click`,N,function(...e){r.onDecrease?.apply(this,e)}),e(`keydown`,N,m),e(`pointerdown`,P,e=>{l=e.currentTarget.valueAsNumber}),e(`input`,P,e=>{f(e.currentTarget.valueAsNumber)}),e(`pointerup`,P,e=>{e.currentTarget.valueAsNumber===l&&f(null),l=null}),w(`pointercancel`,P,()=>{l=null,f(null)}),e(`change`,P,async e=>{try{await r.onChange(e.currentTarget.valueAsNumber)}finally{f(null)}}),e(`keydown`,P,m),e(`click`,F,function(...e){r.onIncrease?.apply(this,e)}),e(`keydown`,F,m),n(t,y),R()}T([`click`,`keydown`,`pointerdown`,`input`,`pointerup`,`change`]);var Be=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><text x="1" y="21" font-size="21" class="svelte-5cwycy">A</text><text x="19" y="21" font-size="13" class="svelte-5cwycy">A</text></svg>`),Ve=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><path d="M5 3v18M2 6l3-3 3 3M2 18l3 3 3-3M13 4h16M13 9h16M13 15h16M13 20h16" class="svelte-5cwycy"></path></svg>`),He=d(`<div class="typography-control reader-adjustment-control svelte-5cwycy"><button class="control-button typography-trigger svelte-5cwycy" type="button"><!></button> <!></div>`);function Ue(t,r){A(r,!0);let i,a=g(()=>r.kind===`font-size`?`Font size`:`Line height`),o=g(()=>`reader-${r.kind}-popup`);function l(e){r.open&&(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),r.onClose(),i.focus())}function u(e){r.onChange(Math.min(r.max,Math.max(r.min,Math.round((r.value+e)*100)/100)))}var d=He(),f=p(d),m=p(f),h=e=>{n(e,Be())},_=e=>{n(e,Ve())};y(m,e=>{r.kind===`font-size`?e(h):e(_,-1)}),v(f),j(f,e=>i=e,()=>i);var b=s(f,2),x=e=>{{let t=g(()=>`Decrease ${c(a).toLowerCase()}`),n=g(()=>`Increase ${c(a).toLowerCase()}`),i=g(()=>r.value<=r.min),s=g(()=>r.value>=r.max),d=g(()=>r.kind===`line-height`?`right`:`left`);ze(e,{get id(){return c(o)},get label(){return c(a)},get value(){return r.value},get min(){return r.min},get max(){return r.max},step:.01,format:e=>`${e.toFixed(2)}x`,valueText:e=>`${e.toFixed(2)} times`,get decreaseLabel(){return c(t)},get increaseLabel(){return c(n)},get disabled(){return r.disabled},get decreaseDisabled(){return c(i)},get increaseDisabled(){return c(s)},get align(){return c(d)},onDecrease:()=>u(-.1),onIncrease:()=>u(.1),get onChange(){return r.onChange},onEscape:()=>l()})}};y(b,e=>{r.open&&e(x)}),v(d),U(()=>{E(f,`aria-label`,c(a)),E(f,`aria-expanded`,r.open),E(f,`aria-controls`,r.open?c(o):void 0),E(f,`title`,c(a)),f.disabled=r.disabled}),e(`click`,f,function(...e){r.onToggle?.apply(this,e)}),e(`keydown`,f,l),n(t,d),R()}T([`click`,`keydown`]);var We=d(`<p class="activity-announcement svelte-1tz9bb9" role="status" aria-live="polite"> </p>`),Ge=d(`<div class="control-group line-height-controls svelte-1tz9bb9"><!></div>`),Ke=d(`<div class="footer-content controls-mode svelte-1tz9bb9"><!> <div class="control-group font-controls svelte-1tz9bb9"><!></div> <div class="control-group progress-controls svelte-1tz9bb9"><div class="progress-slider reader-adjustment-control svelte-1tz9bb9"><div class="progress-thumb-focus svelte-1tz9bb9"><button class="progress-thumb svelte-1tz9bb9" type="button"> </button></div> <!></div></div> <!></div>`),qe=d(`<p class="activity-footer-status svelte-1tz9bb9" role="status" aria-live="polite"><span class="activity-status-full svelte-1tz9bb9"> </span> <span class="activity-status-compact svelte-1tz9bb9" aria-hidden="true"> </span> <span class="activity-announcement svelte-1tz9bb9"> </span></p>`),Je=d(`<span class="progress-compact svelte-1tz9bb9" aria-hidden="true"> </span>`),Ye=d(`<button type="button" class="activity-footer-button svelte-1tz9bb9"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" class="svelte-1tz9bb9"><path></path></svg> <span class="svelte-1tz9bb9"> </span></button>`),Xe=d(`<div class="activity-footer-actions svelte-1tz9bb9"></div>`),Ze=d(`<div><div><!> <p class="passive-footer-metric svelte-1tz9bb9"><span class="progress-full svelte-1tz9bb9"> </span> <!></p> <!></div></div>`),Qe=d(`<footer><!></footer>`);function $e(r,i){A(i,!0);let a=_(i,`lineHeight`,3,1),l=_(i,`chapterPositionLabel`,3,void 0),d=_(i,`previousPageDisabled`,3,!1),m=_(i,`nextPageDisabled`,3,!1),b=_(i,`chapterMenuOpen`,3,!1),x=_(i,`openControl`,15,null),S=_(i,`busy`,3,!1),C=h(null),T=h(void 0),D=g(()=>c(C)??i.progressPercent);function k(e){x(x()===e?null:e),x()&&i.onAdjustmentOpen?.()}function M(e){x()&&e.target instanceof Element&&!e.target.closest(`.reader-adjustment-control`)&&x(null)}function N(e){(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),x(null),c(T)?.focus())}t(()=>{(!i.controlsVisible||b())&&x(null)});var P=Qe();w(`pointerdown`,f,M),w(`blur`,f,()=>x(null));let F;var I=p(P),L=t=>{var r=Ke(),f=p(r),h=e=>{var t=We(),r=p(t);v(t),U(()=>u(r,`${i.activityFooter.status??``} ${i.activityFooter.announcement??``}`)),n(e,t)};y(f,e=>{i.activityFooter&&e(h)});var _=s(f,2),b=p(_);{let e=g(()=>x()===`font-size`);Ue(b,{kind:`font-size`,get value(){return i.fontSize},min:.75,max:2,get open(){return c(e)},get disabled(){return S()},onToggle:()=>k(`font-size`),onClose:()=>x(null),get onChange(){return i.onFontSizeChange}})}v(_);var w=s(_,2),O=p(w),A=p(O),M=p(A),P=p(M);v(M),j(M,e=>o(T,e),()=>c(T)),v(A);var F=s(A,2),I=e=>{{let t=g(()=>S()||!i.onProgressChange),n=g(()=>!i.onPreviousPage||d()),r=g(()=>!i.onNextPage||m());ze(e,{id:`reader-progress-popup`,label:`Reading position`,get value(){return i.progressPercent},min:0,max:100,step:1,align:`center`,format:e=>`${Math.round(e)}%`,valueText:e=>`${Math.round(e)}% of book`,decreaseLabel:`Previous page`,increaseLabel:`Next page`,get disabled(){return c(t)},get decreaseDisabled(){return c(n)},get increaseDisabled(){return c(r)},onDecrease:()=>i.onPreviousPage?.(),onIncrease:()=>i.onNextPage?.(),onChange:e=>i.onProgressChange?.(e),onPreview:e=>o(C,e,!0),onEscape:()=>N()})}};y(F,e=>{x()===`progress`&&e(I)}),v(O),v(w);var L=s(w,2),R=e=>{var t=Ge(),r=p(t);{let e=g(()=>x()===`line-height`);Ue(r,{kind:`line-height`,get value(){return a()},min:1,max:2,get open(){return c(e)},get disabled(){return S()},onToggle:()=>k(`line-height`),onClose:()=>x(null),get onChange(){return i.onLineHeightChange}})}v(t),n(e,t)};y(L,e=>{i.onLineHeightChange&&e(R)}),v(r),U((e,t)=>{E(O,`title`,`${l()??`${i.currentChapterIndex+1} / ${i.totalChapters}`}: ${i.pageLabel}`),E(M,`aria-label`,e),E(M,`aria-expanded`,x()===`progress`),E(M,`aria-controls`,x()===`progress`?`reader-progress-popup`:void 0),M.disabled=S()||!i.onProgressChange,u(P,`${t??``}%`)},[()=>`Reading position, ${Math.round(c(D))}% of book`,()=>Math.round(c(D))]),e(`click`,M,()=>k(`progress`)),e(`keydown`,M,N),n(t,r)},z=t=>{var r=Ze();let a;var o=p(r);let l;var d=p(o),f=e=>{var t=qe(),r=p(t),a=p(r,!0);v(r);var o=s(r,2),c=p(o,!0);v(o);var l=s(o,2),d=p(l,!0);v(l),v(t),U(()=>{u(a,i.activityFooter.status),u(c,i.activityFooter.compactStatus),u(d,i.activityFooter.announcement)}),n(e,t)};y(d,e=>{i.activityFooter&&e(f)});var m=s(d,2),h=p(m),g=p(h,!0);v(h);var _=s(h,2),b=e=>{var t=Je(),r=p(t);v(t),U(()=>u(r,`${i.progressPercent??``}%`)),n(e,t)};y(_,e=>{i.activityFooter&&e(b)}),v(m);var x=s(m,2),S=t=>{var r=Xe();B(r,21,()=>i.activityFooter.buttons,e=>e.label,(t,r)=>{var i=Ye(),a=p(i),o=p(a);v(a);var l=s(a,2),d=p(l,!0);v(l),v(i),U(()=>{E(i,`aria-label`,c(r).label),E(i,`aria-pressed`,c(r).pressed),i.disabled=c(r).disabled,E(o,`d`,c(r).path),u(d,c(r).text)}),e(`click`,i,function(...e){c(r).action?.apply(this,e)}),n(t,i)}),v(r),n(t,r)};y(x,e=>{i.activityFooter&&e(S)}),v(o),v(r),U(()=>{a=O(r,1,`footer-content passive-mode svelte-1tz9bb9`,null,a,{"activity-mode":!!i.activityFooter,"keyboard-mode":i.activityFooter?.buttons.length===4}),l=O(o,1,`passive-footer-shell svelte-1tz9bb9`,null,l,{"activity-footer-shell":!!i.activityFooter}),u(g,i.progressLabel)}),n(t,r)};y(I,e=>{i.controlsVisible?e(L):e(z,-1)}),v(P),U(()=>F=O(P,1,`reading-footer svelte-1tz9bb9`,null,F,{"controls-visible":i.controlsVisible})),n(r,P),R()}T([`click`,`keydown`]);var et=d(`<p class="chapter-title svelte-v52sy3"> </p>`),tt=d(`<p>Find the Greek words in any of eight directions, including backward. Grid letters omit accents and breathing marks.</p>`),nt=d(`<p>Use the English clues to fill in the Greek words. Accents and breathing marks are not required.</p>`),rt=d(`<p>Write the English meaning and its letter beside each Greek word.</p>`),it=d(`<td class="svelte-v52sy3"><span class="svelte-v52sy3"> </span></td>`),at=d(`<tr></tr>`),ot=d(`<li class="svelte-v52sy3"> </li>`),st=d(`<div class="word-search-layout svelte-v52sy3"><table class="word-search-grid svelte-v52sy3" lang="el" aria-label="Greek word search"><tbody></tbody></table> <section class="word-search-vocabulary svelte-v52sy3"><h2 class="svelte-v52sy3">Words to find</h2> <ul class="word-search-words svelte-v52sy3" lang="el"></ul></section></div>`),ct=d(`<li class="svelte-v52sy3"><strong> </strong> </li>`),lt=d(`<section><h2 class="svelte-v52sy3"> </h2> <ul class="svelte-v52sy3"></ul></section>`),ut=d(`<span class="svelte-v52sy3"> </span>`),dt=d(`<td class="crossword-cell svelte-v52sy3"></td>`),ft=d(`<td class="crossword-empty svelte-v52sy3"></td>`),pt=d(`<div class="crossword-layout svelte-v52sy3"><div class="crossword-clues svelte-v52sy3"></div> <table class="crossword-grid svelte-v52sy3" aria-label="Blank Greek crossword"><tbody></tbody></table></div>`),mt=d(`<li class="prompt-row svelte-v52sy3"><span class="greek-word svelte-v52sy3"> </span><span class="meaning-blank svelte-v52sy3"></span><span class="letter-box svelte-v52sy3"></span><span class="result-space"></span></li>`),ht=d(`<li class="choice-row svelte-v52sy3"><span class="choice-letter svelte-v52sy3"> </span><span> </span></li>`),gt=d(`<div class="matching-columns svelte-v52sy3"><section><h2 class="svelte-v52sy3">Greek words</h2><ul class="svelte-v52sy3"></ul></section> <section><h2 class="svelte-v52sy3">English meanings</h2><ul class="svelte-v52sy3"></ul></section></div>`),_t=d(`<section class="worksheet-print svelte-v52sy3" aria-label="Printable worksheet"><!> <h1 class="svelte-v52sy3"> </h1> <!> <p>Name: ________________________ Date: ______________</p> <!></section>`);function vt(e,t){A(t,!0);var r=_t(),i=p(r),o=e=>{var r=et(),i=p(r,!0);v(r),U(()=>u(i,t.activity.chapterTitle)),n(e,r)};y(i,e=>{t.activity.chapterTitle&&e(o)});var l=s(i,2),d=p(l,!0);v(l);var f=s(l,2),m=e=>{n(e,tt())},h=e=>{n(e,nt())},g=e=>{n(e,rt())};y(f,e=>{t.activity.kind===`word-search-v1`?e(m):t.activity.kind===`crossword-v1`?e(h,1):e(g,-1)});var _=s(f,4),b=e=>{var r=st(),i=p(r),a=p(i);B(a,21,()=>t.activity.grid,H,(e,t)=>{var r=at();B(r,21,()=>[...c(t)],H,(e,t)=>{var r=it(),i=p(r),a=p(i,!0);v(i),v(r),U(()=>u(a,c(t))),n(e,r)}),v(r),n(e,r)}),v(a),v(i);var o=s(i,2),l=s(p(o),2);B(l,21,()=>t.activity.words,e=>e.id,(e,t)=>{var r=ot(),i=p(r,!0);v(r),U(()=>u(i,c(t).text)),n(e,r)}),v(l),v(o),v(r),n(e,r)},x=e=>{var r=pt(),i=p(r);B(i,20,()=>[`across`,`down`],H,(e,r)=>{var i=lt(),a=p(i),o=p(a,!0);v(a);var l=s(a,2);B(l,21,()=>t.activity.clues.filter(e=>e.direction===r),e=>e.id,(e,t)=>{var r=ct(),i=p(r),a=p(i);v(i);var o=s(i);v(r),U(()=>{u(a,`${c(t).number??``}.`),u(o,` ${c(t).text??``}`)}),n(e,r)}),v(l),v(i),U(()=>u(o,r===`across`?`Across`:`Down`)),n(e,i)}),v(i);var o=s(i,2),l=p(o);B(l,21,()=>t.activity.cells,H,(e,r,i)=>{var o=at();B(o,21,()=>c(r),H,(e,r,o)=>{var s=V(),l=a(s),d=e=>{var r=dt();B(r,21,()=>t.activity.clues.filter(e=>e.row===i&&e.column===o).slice(0,1),H,(e,t)=>{var r=ut(),i=p(r,!0);v(r),U(()=>u(i,c(t).number)),n(e,r)}),v(r),n(e,r)},f=e=>{n(e,ft())};y(l,e=>{c(r)?e(d):e(f,-1)}),n(e,s)}),v(o),n(e,o)}),v(l),v(o),v(r),U(()=>E(o,`lang`,t.activity.language)),n(e,r)},S=e=>{var r=gt(),i=p(r),a=s(p(i));B(a,21,()=>t.activity.prompts,e=>e.id,(e,t)=>{var r=mt(),i=p(r),a=p(i,!0);v(i),C(3),v(r),U(()=>{E(i,`lang`,c(t).language),u(a,c(t).text)}),n(e,r)}),v(a),v(i);var o=s(i,2),l=s(p(o));B(l,23,()=>t.activity.choices,e=>e.id,(e,t,r)=>{var i=ht(),a=p(i),o=p(a,!0);v(a);var l=s(a),d=p(l,!0);v(l),v(i),U(e=>{u(o,e),E(l,`lang`,c(t).language),u(d,c(t).text)},[()=>le(c(r))]),n(e,i)}),v(l),v(o),v(r),n(e,r)};y(_,e=>{t.activity.kind===`word-search-v1`?e(b):t.activity.kind===`crossword-v1`?e(x,1):e(S,-1)}),v(r),U(()=>u(d,t.activity.title)),n(e,r),R()}var yt=d(`<li class="svelte-5ift61"><strong> </strong>: <!></li>`),bt=d(`<p role="alert" class="svelte-5ift61"> </p>`),xt=d(`<button type="button" class="svelte-5ift61">Close without saving</button>`),St=d(`<dialog class="reader-feature-notice svelte-5ift61" aria-labelledby="reader-feature-title" aria-describedby="reader-feature-message"><h2 id="reader-feature-title" class="svelte-5ift61"> </h2> <p id="reader-feature-message" class="svelte-5ift61"> </p> <a target="_blank" rel="noopener noreferrer" class="svelte-5ift61">Visit Study Cheetah (opens in a new tab)</a> <h3 class="svelte-5ift61">Features requested by this book</h3> <ul class="svelte-5ift61"></ul> <p class="svelte-5ift61">Active means the reader's enhancement is enabled. Each activity is validated when opened.</p> <p class="svelte-5ift61">Unavailable enhancements keep their ordinary book content. This link opens the reader website; it does not upload your book.</p> <label class="svelte-5ift61"><input type="checkbox" class="svelte-5ift61"/> Don't show this again for this book's current features</label> <!> <div class="actions svelte-5ift61"><!> <button type="button" class="svelte-5ift61">Continue reading</button></div></dialog>`);function Ct(t,r){A(r,!0);let i,a=h(!1),d=h(null),f=ye.getInstance();function m(e){console.error(`[Reader] Saving or loading enhancement notice preference failed:`,e),o(d,`Could not remember your notice preference: ${e instanceof Error?e.message:String(e)}`)}function _(){try{f.setReaderNoticeDismissed(r.capability,c(a)),o(d,null),i.close()}catch(e){m(e)}}F(()=>{try{o(a,f.isReaderNoticeDismissed(r.capability),!0)}catch(e){m(e)}r.onready(()=>{i.open||i.showModal()}),(c(d)||!c(a)&&r.capability.requested.some(e=>!r.capability.active.includes(e)))&&i.showModal()});var x=St(),S=p(x),w=p(S,!0);v(S);var T=s(S,2),D=p(T,!0);v(T);var O=s(T,2),k=s(O,4);B(k,20,()=>r.capability.requested,e=>e,(e,t)=>{var i=yt(),a=p(i),o=p(a,!0);v(a);var d=s(a,2),f=e=>{n(e,l(`Active`))},m=g(()=>r.capability.active.includes(t)),h=e=>{n(e,l(`Supported, not active`))},_=g(()=>r.capability.supported.includes(t)),b=e=>{n(e,l(`Not supported by this reader yet`))};y(d,e=>{c(m)?e(f):c(_)?e(h,1):e(b,-1)}),v(i),U(()=>u(o,t)),n(e,i)}),v(k);var M=s(k,6),N=p(M);b(N),C(),v(M);var P=s(M,2),L=e=>{var t=bt(),r=p(t,!0);v(t),U(()=>u(r,c(d))),n(e,t)};y(P,e=>{c(d)&&e(L)});var z=s(P,2),V=p(z),H=t=>{var r=xt();e(`click`,r,()=>i.close()),n(t,r)};y(V,e=>{c(d)&&e(H)});var ee=s(V,2);v(z),v(x),j(x,e=>i=e,()=>i),U(()=>{u(w,r.capability.notice.title),u(D,r.capability.notice.message),E(O,`href`,r.capability.notice.url)}),I(N,()=>c(a),e=>o(a,e)),e(`click`,ee,_),n(t,x),R()}T([`click`]);var wt=`body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
  padding-block: 0.5rem;\r
}\r
[data-study-cheetah-enhanced="matching-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-height: 0;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced] > h1 { text-align: center; }\r
body > [data-study-cheetah-enhanced="matching-v1"] > h1 { margin-block-start: 0; }\r
[data-study-cheetah-enhanced="matching-v1"] [data-study-cheetah-matching-instructions] { display: none; }\r
[data-study-cheetah-enhanced] .matching-columns {\r
  display: grid;\r
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);\r
  gap: clamp(0.75em, 3vw, 2em);\r
  flex: 1 1 auto;\r
  min-height: 6em;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section {\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section > h2 { text-decoration: underline; }\r
[data-study-cheetah-enhanced] [data-matching-prompts],\r
[data-study-cheetah-enhanced] [data-matching-choices] {\r
  display: grid;\r
  reading-flow: grid-order;\r
  align-content: start;\r
  gap: 0.4em;\r
  min-height: 0;\r
  padding: 4px;\r
  margin: 0;\r
  list-style: none;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced] li {\r
  box-sizing: border-box;\r
  position: relative;\r
  min-height: 44px;\r
  padding: 0.35em;\r
  overflow-wrap: anywhere;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 1.8em 1em;\r
  align-items: center;\r
  gap: 0.4em;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li::before {\r
  content: none;\r
}\r
[data-study-cheetah-enhanced] .answer-blank {\r
  box-sizing: border-box;\r
  min-width: 1.6em;\r
  max-width: 3em;\r
  min-height: 1.6em;\r
  padding: 0 0.15em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  text-align: center;\r
  font-weight: bold;\r
  line-height: 1.5;\r
  background: var(--ui-control-bg, transparent);\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li {\r
  display: grid;\r
  grid-template-columns: 2em minmax(0, 1fr);\r
  align-items: center;\r
  column-gap: 2ch;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li::before {\r
  content: attr(data-choice-label);\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
  font-weight: bold;\r
  text-align: center;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] .answer-blank { display: none; }\r
[data-study-cheetah-enhanced] .answer-blank {\r
  white-space: normal;\r
  color: var(--reader-control-greek, var(--reader-matching-greek, var(--coloroldgreek, #0070c0)));\r
}\r
[data-study-cheetah-enhanced] .sc-match-answer { grid-column: 2; grid-row: 1; margin-inline-end: calc(2ch - 0.4em); }\r
[data-study-cheetah-enhanced] [data-matching-prompts] .answer-blank { grid-column: 3; grid-row: 1; }\r
[data-study-cheetah-enhanced] .sc-match-result { grid-column: 4; grid-row: 1; width: 1em; height: 1em; }\r
[data-study-cheetah-enhanced] .sc-match-result svg {\r
  width: 100%;\r
  height: 100%;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 3.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] [data-result="correct"] { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] [data-result="incorrect"] { color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced] .sc-match-answer { text-align: right; min-width: 0; border-bottom: 0; color: var(--reader-page-fg, inherit); }\r
[data-study-cheetah-enhanced] .sc-match-select {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  min-height: 0;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  color: var(--reader-page-fg, inherit);\r
  background: transparent;\r
}\r
[data-study-cheetah-enhanced] .sc-match-select[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); }\r
[data-study-cheetah-enhanced] ol:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] .sc-match-footer { flex: 0 0 auto; margin-top: 0.75em; font-size: 0.8em; }\r
[data-study-cheetah-enhanced] .sc-match-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer p { margin: 0; }\r
[data-study-cheetah-enhanced] .sc-match-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(6em, 1fr) minmax(0, max-content);\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced] .sc-match-status { min-width: 0; }\r
[data-study-cheetah-enhanced] .sc-match-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-match-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
body:has(> [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"]) {\r
padding-inline-end: 48px;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-match-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-match-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-match-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-match-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"][data-sc-external-footer] .sc-match-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`,Tt=`[data-study-cheetah-enhanced] .worksheet-name { display: none; }\r
[data-study-cheetah-enhanced][data-sc-external-footer] :is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row) { display: none; }\r
[data-study-cheetah-enhanced] .sc-activity-error-panel {\r
  position: fixed;\r
  z-index: 20;\r
  inset: auto 16px 8px;\r
  max-height: min(50vh, 18em);\r
  overflow: auto;\r
  box-sizing: border-box;\r
  padding: 0.75em;\r
  border: 2px solid var(--ui-border-strong, currentColor);\r
  background: var(--ui-control-bg, #fff);\r
  color: var(--ui-control-fg, #000);\r
  font: 0.875rem/1.4 sans-serif;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-error-panel p { margin: 0 0 0.5em; overflow-wrap: anywhere; }\r
[data-study-cheetah-enhanced] .sc-activity-error-panel .sc-activity-button { min-width: 44px; }\r
[data-study-cheetah-enhanced] .sc-activity-button {\r
  box-sizing: border-box;\r
  min-height: 44px;\r
  padding: 0.3em 0.6em;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  font: inherit;\r
  font-weight: bold;\r
  color: inherit;\r
  background: var(--ui-control-bg, transparent);\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-check, .sc-crossword-check) {\r
  color: var(--reader-control-check, var(--reader-matching-correct, #166534));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-reset, .sc-word-search-reset, .sc-crossword-reset) {\r
  color: var(--reader-control-reset, var(--reader-matching-reset, #a84300));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-print, .sc-word-search-print, .sc-crossword-print) {\r
  color: var(--reader-control-print, #000);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:hover:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-hover, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:active:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-active, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:disabled { cursor: default; }\r
[data-study-cheetah-enhanced] .sc-activity-button:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 0.5em;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) svg {\r
  flex: 0 0 auto;\r
  width: 1.2em;\r
  height: 1.2em;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-status-compact { display: none; }\r
@media (max-width: 480px) {\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row) {\r
    grid-template-columns: minmax(0, 1fr) max-content;\r
  }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-status, .sc-word-search-status, .sc-crossword-status) {\r
    min-width: 0;\r
    overflow-x: auto;\r
    text-align: left;\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-full {\r
    position: absolute;\r
    width: 1px;\r
    height: 1px;\r
    overflow: hidden;\r
    clip-path: inset(50%);\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-compact { display: inline; }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) {\r
    flex-wrap: nowrap;\r
    justify-content: flex-end;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
    width: 44px;\r
    min-width: 44px;\r
    padding: 0;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button > span {\r
    display: none;\r
  }\r
}\r
@media print {\r
  .study-cheetah-activity-ui { display: none !important; }\r
}\r
`;function Et(e,t){let n=e.querySelector(`:is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row)`),r=n?.querySelector(`[role="status"]`),i=r?.querySelector(`.sc-activity-status-full`),a=r?.querySelector(`.sc-activity-status-compact`),o=r?.querySelector(`:is(.sc-match-announcement, .sc-word-search-announcement, .sc-crossword-announcement)`),s=n?[...n.querySelectorAll(`.sc-activity-button`)]:[];if(!n||!i||!a||!o||!s.length)throw Error(`Activity footer is unavailable.`);let c=()=>t({status:i.textContent??``,compactStatus:a.textContent??``,announcement:o.textContent??``,buttons:s.map(e=>{let t=e.getAttribute(`aria-label`),n=e.querySelector(`span`)?.textContent,r=e.querySelector(`svg path`)?.getAttribute(`d`);if(!t||!n||!r)throw Error(`Activity footer button is invalid.`);let i=e.getAttribute(`aria-pressed`);return{label:t,text:n,path:r,disabled:e.disabled,...i===null?{}:{pressed:i===`true`},action:()=>e.click()}})}),l=new MutationObserver(c);return l.observe(n,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:[`disabled`,`aria-pressed`]}),e.setAttribute(`data-sc-external-footer`,``),c(),()=>{l.disconnect(),e.removeAttribute(`data-sc-external-footer`)}}function Dt(e,t,n){let r=e.ownerDocument;e.setAttribute(`aria-label`,e.textContent),e.textContent=``;let i=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);i.setAttribute(`viewBox`,`0 0 24 24`),i.setAttribute(`aria-hidden`,`true`),i.setAttribute(`focusable`,`false`);let a=r.createElementNS(i.namespaceURI,`path`);a.setAttribute(`d`,n),i.append(a);let o=r.createElement(`span`);o.textContent=t,e.append(i,o)}function Ot(e,t){let n=e.ownerDocument,r=[];function i(e,t,n){let i=e.getAttribute(t);e.setAttribute(t,n),r.push(()=>{i===null?e.removeAttribute(t):e.setAttribute(t,i)})}function a(e,t,i){let a=n.createElement(t);return a.className=`study-cheetah-activity-ui ${i}`,e.append(a),r.push(()=>a.remove()),a}function o(e,t,n){let i=a(e,`button`,`sc-activity-button`);return i.type=`button`,i.textContent=t,i.addEventListener(`click`,n),r.push(()=>i.removeEventListener(`click`,n)),i}function s(){let t=a(e,`div`,`sc-activity-error-panel`),n=a(t,`p`,`sc-activity-error-message`);n.setAttribute(`role`,`alert`);let r=a(t,`p`,`sc-activity-save-status`);r.textContent=`Progress is not saved.`,o(t,`Dismiss warning`,()=>{t.hidden=!0}),t.hidden=!0;let i=-1;return(e,r)=>{r!==i&&(t.hidden=e===null,i=r),e===null&&(t.hidden=!0),n.textContent=e}}let c=window.matchMedia(`(orientation: portrait)`),l=n.defaultView.matchMedia(`(orientation: portrait)`),u=()=>{e.setAttribute(`data-study-cheetah-orientation`,c.matches||l.matches?`portrait`:`landscape`)};i(e,`data-study-cheetah-orientation`,`portrait`),u(),c.addEventListener(`change`,u),l.addEventListener(`change`,u),r.push(()=>{c.removeEventListener(`change`,u),l.removeEventListener(`change`,u)});let d=n.createElement(`style`);return d.textContent=`${Tt}\n${t}`,n.head.append(d),r.push(()=>d.remove()),{doc:n,cleanups:r,attribute:i,append:a,button:o,errorPanel:s}}function kt(e,t,n){let{doc:r,cleanups:i,attribute:a,append:o,button:s,errorPanel:c}=Ot(e,wt),l=ye.getInstance(),u=[...e.querySelectorAll(`[data-matching-prompts] > li`)],d=[...e.querySelectorAll(`[data-matching-choices] > li`)],f=[...e.querySelectorAll(`[data-matching-prompts], [data-matching-choices]`)],p={},m=null,h=!1,g=0,_=!1,v=null,y=0,b=``,x={promptIds:t.prompts.map(e=>e.id),choiceIds:t.choices.map(e=>e.id)};function S(e,t,n){let r=e.querySelector(t)??o(e,`span`,n);a(r,`class`,`${r.className} ${n}`),a(r,`aria-hidden`,`true`);let s=r.textContent;return i.push(()=>{r.textContent=s}),r}try{let e=l.getMatchingProgress(n.publicationId,t);e&&(p=e.answers,h=e.submitted,g=e.attempts),x=Object.keys(p).length>0?e?.order??x:n.order??de(t)}catch(e){_=!0,L(e)}n.onorder?.(x);function C(e){return le(x.choiceIds.indexOf(e))}a(e,`data-study-cheetah-enhanced`,`matching-v1`);for(let t of e.querySelectorAll(`:scope > p`))t.textContent?.trim()===`Match the Greek word with the correct English translation. Write the English meaning and its letter beside each Greek word.`&&a(t,`data-study-cheetah-matching-instructions`,``);for(let[e,t]of f.entries())a(t,`tabindex`,`0`),a(t,`aria-label`,e===0?`Greek words list`:`English meanings list`);let w=u.map((e,n)=>{let r=t.prompts[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${x.promptIds.indexOf(r.id)};`);let i=S(e,`.matching-answer`,`sc-match-answer`),o=S(e,`.answer-blank`,`answer-blank`),c=S(e,`.matching-result`,`sc-match-result`),l=s(e,``,()=>{m=r.id,b=`Choose an English meaning for ${r.id}.`,z()});return l.classList.add(`sc-match-select`),l.setAttribute(`aria-label`,`Greek ${r.id}: ${r.text}`),{answer:i,blank:o,result:c,control:l}}),T=d.map((e,n)=>{let r=t.choices[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${x.choiceIds.indexOf(r.id)};`),a(e,`data-choice-label`,C(r.id));let i=s(e,``,()=>{!m||_||(p=q(t,p,m,r.id),b=`Matched ${m} with ${r.text}.`,m=null,h=!1,R(),z())});return i.classList.add(`sc-match-select`),i.setAttribute(`aria-label`,`English: ${r.text}`),{control:i}}),E=o(e,`div`,`sc-match-footer`),D=c(),O=o(E,`div`,`sc-match-footer-row`),k=o(O,`p`,`sc-match-status`);k.setAttribute(`role`,`status`),k.setAttribute(`aria-live`,`polite`);let A=o(k,`span`,`sc-activity-status-full`),j=o(k,`span`,`sc-activity-status-compact`);j.setAttribute(`aria-hidden`,`true`);let M=o(k,`span`,`sc-match-announcement`),N=o(O,`div`,`sc-match-controls`),P=s(N,`Check answers`,()=>{h=!0,g+=1,b=``,R(),z()});P.classList.add(`sc-match-check`);let F=s(N,`Reset answers`,()=>{try{l.deleteMatchingProgress(n.publicationId,t),p={},m=null,h=!1,_=!1,b=`Answers cleared.`,R()}catch(e){L(e)}z()});F.classList.add(`sc-match-reset`);let I=s(N,`Print worksheet`,n.onprint);I.classList.add(`sc-match-print`);for(let[e,t,n]of[[P,`Check`,`M5 12l4 4L19 6`],[F,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[I,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])Dt(e,t,n);function L(e){console.error(`[Reader] Matching exercise progress:`,e),v=`Could not load or save exercise progress. ${e instanceof Error?e.message:String(e)}`,y++}function R(){try{l.saveMatchingProgress(n.publicationId,t,{revision:t.revision,answers:p,submitted:h,attempts:g,updated:Date.now(),order:x}),v=null}catch(e){L(e)}}function z(){let e=Object.keys(p).length,n=Ce(t,p);A.textContent=`${h?`${n} of ${t.prompts.length} correct.${n===t.prompts.length?` Exercise complete.`:``}`:`${e} of ${t.prompts.length} matched.`} Checks: ${g}.`,j.textContent=`${h?n:e}/${t.prompts.length} ${h?`correct`:`matched`}; ${g} ${g===1?`check`:`checks`}`,M.textContent=` ${b}`,D(v,y),P.disabled=_||e===0;for(let[e,{control:n,answer:i,blank:a,result:o}]of w.entries()){let s=t.prompts[e],c=t.choices.findIndex(e=>e.id===p[s.id]),l=t.choices[c],u=h&&!!l,d=l?.answerId===s.id;if(i.textContent=l?.text??``,a.textContent=l?C(l.id):``,l?.language?i.lang=l.language:i.removeAttribute(`lang`),n.disabled=_,n.setAttribute(`aria-pressed`,String(m===s.id)),n.setAttribute(`aria-description`,`${l?`Matches ${l.text}`:`Not matched`}${u?d?` Correct`:` Incorrect`:``}`),o.replaceChildren(),u){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.setAttribute(`viewBox`,`0 0 20 20`),e.setAttribute(`data-result`,d?`correct`:`incorrect`);let t=r.createElementNS(e.namespaceURI,`path`);t.setAttribute(`d`,d?`M3 10l4 4L17 4`:`M4 4l12 12M16 4L4 16`),e.append(t),o.append(e)}}for(let[e,{control:n}]of T.entries()){let r=t.choices[e],i=Object.entries(p).find(([,e])=>e===r.id)?.[0];n.disabled=_||!m,n.setAttribute(`aria-description`,`Choice ${C(r.id)}. ${i?`Used by ${i}`:`Not used`}`)}}return z(),()=>{for(let e of i.reverse())e()}}var At=`body:has(> [data-study-cheetah-enhanced="word-search-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
  color: inherit;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-study-cheetah-word-search-instructions] { display: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="word-search-v1"] > [data-word-search-layout] { flex-grow: 1; align-content: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr);\r
  gap: 0.6em 1em;\r
  align-items: start;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) {\r
  grid-template-columns: minmax(0, var(--sc-word-search-board-space, 1fr)) minmax(0, 1fr);\r
  column-gap: 10em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit][data-word-search-measure="side"] {\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] > .word-search-board {\r
  box-sizing: border-box;\r
  min-width: 0;\r
  padding: 1em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] .word-search-vocabulary {\r
  justify-self: start;\r
  width: max-content;\r
  max-width: 100%;\r
  min-width: 0;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-words], [data-word-search-words] > li) {\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-words] {\r
  font-size: 1.25em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  grid-template-columns: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) .word-search-vocabulary {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr);\r
  max-height: var(--sc-word-search-height);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  min-height: 0;\r
  padding-block: 0.15em;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .word-search-vocabulary h2 {\r
  display: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] [data-word-search-grid] {\r
  width: var(--sc-word-search-width, 100%);\r
  min-width: 0;\r
  max-width: none;\r
  margin-inline: auto;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] td > span {\r
  block-size: var(--sc-word-search-cell, auto);\r
  font-size: max(1em, var(--sc-word-search-letter, 1em));\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-cell {\r
  position: absolute;\r
  top: 0;\r
  left: 0;\r
  max-width: none;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  background: transparent;\r
  color: var(--reader-page-fg, inherit);\r
  cursor: pointer;\r
  touch-action: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-grid] { user-select: none; touch-action: none; }\r
:is([data-study-cheetah-enhanced="word-search-v1"][data-sc-word-search-overlay-host],\r
  [data-study-cheetah-enhanced="word-search-v1"] [data-sc-word-search-overlay-host]) { position: relative; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-capsules {\r
  position: absolute;\r
  pointer-events: none;\r
  overflow: visible;\r
}\r
.sc-word-search-capsules rect { fill: none; }\r
.sc-word-search-found-capsule { stroke: var(--reader-matching-correct, #166534); }\r
.sc-word-search-selected-capsule { stroke: var(--reader-page-fg, currentColor); }\r
.sc-word-search-cell:focus-visible { outline: 2px solid currentColor; outline-offset: -3px; }\r
[data-sc-word-search-pointer-focus="true"] .sc-word-search-cell:focus-visible { outline: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-touch-preview {\r
  position: fixed;\r
  inset: auto;\r
  box-sizing: border-box;\r
  width: max-content;\r
  max-width: calc(100vw - 1rem);\r
  margin: 0;\r
  padding: 0.3em 0.75em;\r
  border: 2px solid currentColor;\r
  border-radius: 9999px;\r
  background: var(--reader-page-bg, Canvas);\r
  color: var(--reader-page-fg, CanvasText);\r
  font-size: max(1.25em, var(--sc-word-search-letter, 1em));\r
  line-height: 1.4;\r
  letter-spacing: 0.1em;\r
  text-align: center;\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-found-word {\r
  color: var(--reader-matching-correct, #166534);\r
  font-weight: bold;\r
  text-decoration: line-through;\r
}\r
.sc-word-search-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-word-search-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer p { margin: 0; }\r
.sc-word-search-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-word-search-status { min-width: 0; text-align: left; }\r
.sc-word-search-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-word-search-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-word-search-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-word-search-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-word-search-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-word-search-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-sc-external-footer] .sc-word-search-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`;function jt(e,t,n){let r=e.querySelector(`[data-word-search-grid]`),i=[...e.querySelectorAll(`[data-word-search-grid] td`)];if(!r||i.length!==t.grid.length*t.grid[0].length)throw Error(`The word-search grid does not match its worksheet.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l,errorPanel:u}=Ot(e,At),d=r.parentElement;a.defaultView.getComputedStyle(d).position===`static`&&s(d,`data-sc-word-search-overlay-host`,``);let f=a.createElementNS(`http://www.w3.org/2000/svg`,`svg`);f.setAttribute(`class`,`study-cheetah-activity-ui sc-word-search-capsules`),f.setAttribute(`aria-hidden`,`true`),f.setAttribute(`focusable`,`false`),d.append(f),o.push(()=>f.remove());let p=ye.getInstance(),m=t.grid[0].length,h=t.grid.join(``),g=[],_=null,v=null,y=null,b=null,x=!1,S,C=!1,w=0,T=!1,E=null,D=0,O=``;function k(e){console.error(`[Reader] Word-search progress:`,e),E=`Could not load or save puzzle progress. ${e instanceof Error?e.message:String(e)}`,D++}try{g=p.getWordSearchProgress(n.publicationId,t)?.found??[]}catch(e){T=!0,k(e)}s(e,`data-study-cheetah-enhanced`,`word-search-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Find the Greek words in any of eight directions, including backward. Grid letters are lowercase without accents or breathing marks.`,`Find words in all eight directions. Lowercase grid letters omit accents.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-word-search-instructions`,``);s(r,`role`,`grid`),s(r,`aria-rowcount`,String(t.grid.length)),s(r,`aria-colcount`,String(m)),s(r,`aria-description`,`Drag from the first letter to the last, or tap both ends. Keyboard: use arrow keys, Enter or Space to select each end, and Escape to cancel.`),s(r,`data-sc-word-search-pointer-focus`,`false`);let A=i.map((e,t)=>{s(e,`role`,`gridcell`);let n=e.querySelector(`span`);n&&s(n,`aria-hidden`,`true`);let r=c(e,`button`,`sc-word-search-cell`);return r.type=`button`,r.dataset.cellIndex=String(t),r.setAttribute(`aria-label`,`Row ${Math.floor(t/m)+1}, column ${t%m+1}: ${h[t]}`),r}),j=c(e,`div`,`sc-word-search-touch-preview`);j.popover=`manual`,j.lang=`el`,j.setAttribute(`aria-hidden`,`true`),j.hidden=!0;let M=c(c(e,`div`,`sc-word-search-footer`),`div`,`sc-word-search-footer-row`),N=c(M,`p`,`sc-word-search-status`);N.setAttribute(`role`,`status`),N.setAttribute(`aria-live`,`polite`);let P=c(N,`span`,`sc-activity-status-full`),F=c(N,`span`,`sc-activity-status-compact`);F.setAttribute(`aria-hidden`,`true`);let I=c(N,`span`,`sc-word-search-announcement`),L=u(),R=c(M,`div`,`sc-word-search-controls`),z=l(R,`Reset puzzle`,()=>{ne();try{p.deleteWordSearchProgress(n.publicationId,t),g=[],_=null,T=!1,O=`Found words cleared.`,H()}catch(e){k(e)}fe()});z.classList.add(`sc-word-search-reset`);let B=l(R,`Print worksheet`,n.onprint);B.classList.add(`sc-word-search-print`),Dt(z,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`),Dt(B,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`);let V=[...e.querySelectorAll(`[data-word-search-words] > li`)];for(let e of V)s(e,`class`,e.className);function H(){try{p.saveWordSearchProgress(n.publicationId,t,{revision:t.revision,puzzle:he(t),found:g,updated:Date.now()}),E=null}catch(e){k(e)}}function U(e,n){let r=me(t,e,n);r?g.some(e=>e.wordId===r.id)?O=`${r.text} is already found.`:(g=[...g,{wordId:r.id,start:e,end:n}],O=`Found ${r.text}.`,H()):O=`No listed word selected. Choose a straight row, column, or diagonal.`,_=null}function ee(e){T||(w=e,_===null?(_=e,O=`First letter selected. Choose the last letter.`):U(_,e),fe())}function W(){return v!==null&&y!==null?J(t,C?v:_??v,y)??[]:_===null?[]:[_]}function te(){let e=r.getBoundingClientRect(),t=r.offsetWidth,n=r.offsetHeight;if(!t||!n||!e.width||!e.height){f.replaceChildren();return}f.style.width=`${t}px`,f.style.height=`${n}px`,f.setAttribute(`viewBox`,`0 0 ${t} ${n}`);let o=t/e.width,s=n/e.height,c=f.getBoundingClientRect();f.style.left=`${(Number.parseFloat(f.style.left)||0)+(e.left-c.left)*o}px`,f.style.top=`${(Number.parseFloat(f.style.top)||0)+(e.top-c.top)*s}px`;let l=a.createDocumentFragment();function u(t,n,r,c){let u=i[t].getBoundingClientRect(),d=i[n].getBoundingClientRect(),p=(u.left+u.width/2-e.left)*o,m=(u.top+u.height/2-e.top)*s,h=(d.left+d.width/2-u.left-u.width/2)*o,g=(d.top+d.height/2-u.top-u.height/2)*s,_=Math.min(u.width*o,u.height*s),v=_*.4,y=a.createElementNS(f.namespaceURI,`rect`);y.setAttribute(`class`,r),c&&y.setAttribute(`data-sc-word-id`,c),y.setAttribute(`x`,String(p-v)),y.setAttribute(`y`,String(m-v)),y.setAttribute(`width`,String(Math.hypot(h,g)+2*v)),y.setAttribute(`height`,String(2*v)),y.setAttribute(`rx`,String(v)),y.setAttribute(`stroke-width`,String(_*.08)),y.setAttribute(`transform`,`rotate(${Math.atan2(g,h)*180/Math.PI} ${p} ${m})`),l.append(y)}for(let e of g)u(e.start,e.end,`sc-word-search-found-capsule`,e.wordId);let d=W();d.length&&u(d[0],d[d.length-1],`sc-word-search-selected-capsule`),f.replaceChildren(l)}function ne(){clearTimeout(S),S=void 0,j.matches(`:popover-open`)&&j.hidePopover(),j.hidden=!0,j.textContent=``}function re(){if(j.hidden)return;let e=r.getBoundingClientRect(),t=j.getBoundingClientRect(),n=Math.max(8,Math.min(e.left+e.width/2-t.width/2,a.documentElement.clientWidth-t.width-8));j.style.left=`${n}px`,j.style.top=`${Math.max(8,e.top-t.height-8)}px`}function ie(){let e=W();if(!e.length){ne();return}j.textContent=e.map(e=>h[e]).join(``),j.hidden=!1,j.matches(`:popover-open`)||j.showPopover(),re()}function ae(e){let t=a.elementFromPoint(e.clientX,e.clientY)?.closest(`.sc-word-search-cell`);return t&&r.contains(t)?Number(t.dataset.cellIndex):null}let G=e=>{if(T||e.button!==0||b!==null)return;let t=ae(e);t!==null&&(e.preventDefault(),ne(),x=e.pointerType===`touch`,v=y=t,b=e.pointerId,C=!1,w=t,r.setAttribute(`data-sc-word-search-pointer-focus`,`true`),A[t].focus({preventScroll:!0}),r.setPointerCapture(e.pointerId),fe())},oe=e=>{if(e.pointerId!==b||v===null)return;let t=ae(e);t!==y&&(y=t,y!==null&&y!==v&&(C=!0),fe())},se=e=>{if(e.pointerId!==b||v===null)return;let t=ae(e);y=t;let n=x;n&&ie(),x=!1,t===null?(_=null,O=`Selection cancelled.`):C?U(v,t):ee(t),b=v=y=null,fe(),n&&!j.hidden&&(S=setTimeout(ne,1e3))},K=e=>{e&&e.pointerId!==b||(x=!1,ne(),b=v=y=_=null,fe())},ce=e=>{let t=e.target.closest(`.sc-word-search-cell`);e.detail===0&&t&&(ne(),ee(Number(t.dataset.cellIndex)))},le=e=>{r.setAttribute(`data-sc-word-search-pointer-focus`,`false`);let t=e.target.closest(`.sc-word-search-cell`);if(!t||e.altKey||e.ctrlKey||e.metaKey)return;let n=Number(t.dataset.cellIndex),a=n;if(e.key===`ArrowLeft`)a=n%m?n-1:n;else if(e.key===`ArrowRight`)a=n%m<m-1?n+1:n;else if(e.key===`ArrowUp`)a=Math.max(n-m,n%m);else if(e.key===`ArrowDown`)a=Math.min(n+m,i.length-m+n%m);else if(e.key===`Enter`||e.key===` `)ee(n);else if(e.key===`Escape`)K(),O=`Selection cancelled.`;else return;e.preventDefault(),w=a,fe(),A[a].focus()},ue=e=>{(!(e.relatedTarget instanceof a.defaultView.Node)||!r.contains(e.relatedTarget))&&r.setAttribute(`data-sc-word-search-pointer-focus`,`false`)};r.addEventListener(`pointerdown`,G),r.addEventListener(`pointermove`,oe),r.addEventListener(`pointerup`,se),r.addEventListener(`pointercancel`,K),r.addEventListener(`lostpointercapture`,K),r.addEventListener(`click`,ce),r.addEventListener(`keydown`,le),r.addEventListener(`focusout`,ue),a.addEventListener(`scroll`,re,!0),a.defaultView?.addEventListener(`resize`,re),o.push(()=>{ne(),r.removeEventListener(`pointerdown`,G),r.removeEventListener(`pointermove`,oe),r.removeEventListener(`pointerup`,se),r.removeEventListener(`pointercancel`,K),r.removeEventListener(`lostpointercapture`,K),r.removeEventListener(`click`,ce),r.removeEventListener(`keydown`,le),r.removeEventListener(`focusout`,ue),a.removeEventListener(`scroll`,re,!0),a.defaultView?.removeEventListener(`resize`,re)});let de=new ResizeObserver(te);de.observe(e),de.observe(d),de.observe(r),o.push(()=>de.disconnect());function fe(){let e=new Set(g.flatMap(e=>J(t,e.start,e.end)??[])),n=new Set(W());te(),x&&ie();for(let[t,r]of A.entries())r.tabIndex=t===w?0:-1,r.disabled=T,r.classList.toggle(`sc-word-search-found`,e.has(t)),r.classList.toggle(`sc-word-search-selected`,n.has(t)),r.setAttribute(`aria-pressed`,String(n.has(t))),r.setAttribute(`aria-description`,e.has(t)?`Part of a found word`:`Not found`);for(let e of V)e.classList.toggle(`sc-word-search-found-word`,g.some(t=>t.wordId===e.dataset.wordId));P.textContent=`${g.length} of ${t.words.length} words found.${g.length===t.words.length?` Puzzle complete.`:``}`,F.textContent=`${g.length}/${t.words.length} found`,I.textContent=O?` ${O}`:``,L(E,D)}fe();let pe=e.querySelector(`:scope > [data-word-search-layout]`),q=pe?.querySelector(`.word-search-vocabulary`);return pe&&q&&o.push(Mt(e,pe,r,q,m,t.grid.length)),()=>{for(let e of o.reverse())e()}}function Mt(e,t,n,r,i,a){let o=Array.from(e.children).filter(e=>e!==t),s=e=>Number.parseFloat(e)||0,c=r.querySelector(`[data-word-search-words]`),l=c.getAttribute(`tabindex`);t.dataset.wordSearchFit=`stack`;function u(){l===null?c.removeAttribute(`tabindex`):c.setAttribute(`tabindex`,l)}function d(){if(!e.clientHeight||!e.clientWidth)return;let l=getComputedStyle(e),d=o.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),f=e.clientHeight-s(l.paddingTop)-s(l.paddingBottom)-s(l.rowGap)*d.length;for(let e of d){let t=getComputedStyle(e);f-=e.getBoundingClientRect().height+s(t.marginTop)+s(t.marginBottom)}t.dataset.wordSearchMeasure=`stack`;let p=getComputedStyle(t),m=t.clientWidth,h=getComputedStyle(n.parentElement),g=s(h.paddingLeft)+s(h.paddingRight),_=s(h.paddingTop)+s(h.paddingBottom),v=f-_,y=Math.ceil(s(getComputedStyle(n).fontSize)*i),b=Math.max(y,Math.min(m-g,(v-r.offsetHeight-s(p.rowGap))*i/a));t.dataset.wordSearchMeasure=`side`;let x=s(getComputedStyle(t).columnGap),S=r.offsetWidth,C=Math.max(y,v*i/a)+g,w=m-x,T=Math.min(w-S,w*C/(C+S)),E=T-g,D=Math.max(y,Math.min(E,v*i/a));delete t.dataset.wordSearchMeasure;let O=t.dataset.wordSearchFit===`side`,k=e.clientWidth>=e.clientHeight+(O?-4:4),A=E>=y+(O?0:4)&&(D>b+4||D>=b-(O?4:0)&&k||O&&D>b),j=Math.floor(A?D:b);A!==O&&(t.dataset.wordSearchFit=A?`side`:`stack`),t.style.setProperty(`--sc-word-search-width`,`${j}px`),t.style.setProperty(`--sc-word-search-cell`,`${j/i}px`),t.style.setProperty(`--sc-word-search-letter`,`${j/i*.58}px`),t.style.setProperty(`--sc-word-search-height`,`${j*a/i}px`),t.style.setProperty(`--sc-word-search-board-space`,`${Math.max(0,T)}px`),A&&c.scrollHeight>c.clientHeight?c.tabIndex=0:u()}let f=new ResizeObserver(d);f.observe(e),f.observe(r);for(let e of o)f.observe(e);return d(),()=>{f.disconnect(),delete t.dataset.wordSearchFit,t.style.removeProperty(`--sc-word-search-width`),t.style.removeProperty(`--sc-word-search-cell`),t.style.removeProperty(`--sc-word-search-letter`),t.style.removeProperty(`--sc-word-search-height`),t.style.removeProperty(`--sc-word-search-board-space`),u()}}var Nt=`body:has(> [data-study-cheetah-enhanced="crossword-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="crossword-v1"] [data-study-cheetah-crossword-instructions] { display: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-layout {\r
  flex-grow: 1;\r
  grid-template-columns: max-content var(--sc-crossword-width, minmax(0, 1fr));\r
  justify-content: center;\r
  align-content: center;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-grid { width: var(--sc-crossword-width, 100%); max-width: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr) minmax(0, 1fr);\r
  max-height: max(var(--sc-crossword-height), 10em);\r
  min-height: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] [data-crossword-wide="true"] .crossword-clues {\r
  grid-template-columns: max-content max-content;\r
  grid-template-rows: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues h2 { margin: 0 0 0.4em; line-height: 1.2; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: auto; min-height: 0; margin: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues li { position: relative; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue {\r
  padding: 0.1em 0.2em;\r
  border: 1px solid transparent;\r
  color: inherit;\r
  background: transparent;\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); font-weight: bold; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="correct"]::after { content: " \\2713"; color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="incorrect"]::after { content: " \\2717"; color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-input {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  box-sizing: border-box;\r
  border: 2px solid transparent;\r
  padding: 0;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: inherit;\r
  font-size: 1.25em;\r
  text-align: center;\r
  cursor: pointer;\r
  caret-color: transparent;\r
  -webkit-touch-callout: none;\r
  -webkit-user-select: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-number { pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-number { z-index: 1; pointer-events: none; color: var(--ui-control-fg, inherit); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-selected { background: var(--ui-control-bg-active, color-mix(in srgb, currentColor 12%, transparent)); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-current { border-color: currentColor; }\r
[data-study-cheetah-enhanced="crossword-v1"] :is(.sc-crossword-input, .sc-crossword-clue):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-crossword-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer p { margin: 0; }\r
.sc-crossword-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-crossword-status { min-width: 0; text-align: left; }\r
.sc-crossword-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-crossword-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-keyboard {\r
  width: min(100%, 650px);\r
  align-self: center;\r
  margin-top: 0.25em;\r
}\r
.sc-crossword-keyboard-caption { font: 0.7em/1.2 sans-serif; text-align: center; }\r
.sc-crossword-keyboard-rows { overflow-x: auto; }\r
.sc-crossword-keyboard-row { display: flex; justify-content: center; gap: 3px; margin-top: 3px; min-width: 480px; }\r
.sc-crossword-keyboard-key {\r
  position: relative;\r
  box-sizing: border-box;\r
  display: grid;\r
  place-items: center;\r
  flex: 1 1 0;\r
  max-width: 62px;\r
  min-width: 44px;\r
  height: 44px;\r
  padding: 0;\r
  margin: 0;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: 1em/1 sans-serif;\r
}\r
.sc-crossword-keyboard-key:is(button) { cursor: pointer; touch-action: manipulation; }\r
.sc-crossword-keyboard-key:is(button):hover:not(:disabled) { background: var(--ui-control-bg-hover, transparent); }\r
.sc-crossword-keyboard-key:is(button):is(:active, .sc-crossword-keyboard-pressed):not(:disabled) {\r
  background: var(--ui-control-bg-active, transparent);\r
  box-shadow: inset 0 0 0 2px currentColor;\r
}\r
.sc-crossword-keyboard-key:is(button):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-keyboard-key:is(button):disabled { opacity: 0.5; cursor: default; }\r
.sc-crossword-keyboard-placeholder { opacity: 0.5; height: 20px; }\r
.sc-crossword-keyboard-placeholder .sc-crossword-keyboard-original { display: none; }\r
.sc-crossword-keyboard-key-wide { max-width: none; font-size: 0.6em; }\r
.sc-crossword-keyboard-original { position: absolute; top: 2px; left: 3px; font-size: 0.5em; }\r
.sc-crossword-keyboard-key.sc-crossword-keyboard-mode { font-size: 0.7em; }\r
.sc-crossword-keyboard-mode .sc-crossword-keyboard-original { font-size: 8px; }\r
.sc-crossword-keyboard-has-marks::after {\r
  content: "+";\r
  position: absolute;\r
  top: 2px;\r
  right: 3px;\r
  font: bold 0.6em/1 sans-serif;\r
}\r
.sc-crossword-keyboard-number[aria-pressed="true"] { box-shadow: inset 0 0 0 2px currentColor; }\r
.sc-crossword-keyboard-shift[aria-pressed="true"] { box-shadow: inset 0 0 0 2px currentColor; }\r
.sc-crossword-keyboard-shift[data-locked="true"] { border-style: double; border-width: 3px; }\r
\r
@media (max-height: 400px) {\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
    display: block;\r
    max-height: var(--sc-crossword-height);\r
    overflow-y: auto;\r
  }\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: block; }\r
  [data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: visible; }\r
  .sc-crossword-keyboard-placeholder { height: 13px; font-size: 12px; }\r
  .sc-crossword-keyboard-key-wide { font-size: 8px; }\r
  .sc-crossword-keyboard-original { top: 0; left: 2px; }\r
  .sc-crossword-keyboard-row { gap: 2px; margin-top: 2px; }\r
}\r
\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-crossword-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-crossword-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-crossword-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-crossword-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] { padding-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] > h1 { margin-inline-end: 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-sc-external-footer] .sc-crossword-footer {\r
  position: static;\r
  width: auto;\r
  max-height: none;\r
  margin: 0;\r
  overflow: visible;\r
}\r
`,Pt=[[[`1`,``],[`2`,``],[`3`,``],[`4`,``],[`5`,``],[`6`,``],[`7`,``],[`8`,``],[`9`,``],[`0`,``]],[[`Q`,`θ`],[`W`,`ω`],[`E`,`ε`],[`R`,`ρ`],[`T`,`τ`],[`Y`,`ψ`],[`U`,`υ`],[`I`,`ι`],[`O`,`ο`],[`P`,`π`]],[[`Diacritics`,``],[`A`,`α`],[`S`,`σ`],[`D`,`δ`],[`F`,`φ`],[`G`,`γ`],[`H`,`η`],[`J`,`ς`],[`K`,`κ`],[`L`,`λ`]],[[`Shift`,``],[`Z`,`ζ`],[`X`,`χ`],[`C`,`ξ`],[`V`,`ν`],[`B`,`β`],[`N`,`ν`],[`M`,`μ`],[`Backspace`,``]]],Ft=new Map(Pt.flat().filter(([,e])=>e)),It=500;function Lt(e,t,n){let r=e.querySelector(`.crossword-grid`),i=[...e.querySelectorAll(`[data-entry-id]`)];if(!r||i.length!==t.clues.length)throw Error(`Crossword worksheet does not match its clues.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l,errorPanel:u}=Ot(e,Nt),d=ye.getInstance(),f={},p=t.clues[0],m=Z(p)[0],h=p.direction,g=!1,_=0,v=!1,y=null,b=0,x=``,S=null,C=null,w,T=null,E=`off`,D=!1,O=!1,k=new Map,A=[...t.clues].sort((e,t)=>e.number-t.number||(e.direction===t.direction?0:e.direction===`across`?-1:1));function j(){w!==void 0&&window.clearTimeout(w),w=void 0,T=null}function M(){return t.letterCase===`mixed`&&(O||E===`locked`)!==(D||E===`once`)}function N(e){let n=xe(e);return t.letterCase===`lowercase`?n.toLowerCase().normalize(`NFC`):n}function P(e){let t=M()?e.toUpperCase():e;return E===`once`&&(E=`off`),t}function F(){E===`once`&&(E=`off`)}function I(e){e&&e.selectionStart!==e.selectionEnd&&e.setSelectionRange(e.value.length,e.value.length)}function L(e){console.error(`[Reader] Crossword progress:`,e),y=`Could not load or save crossword progress. ${e instanceof Error?e.message:String(e)}`,b++}try{let e=d.getCrosswordProgress(n.publicationId,t);e&&(f=Object.fromEntries(Object.entries(e.letters).map(([e,t])=>[e,N(t)])),g=e.submitted,_=e.attempts)}catch(e){v=!0,L(e)}s(e,`data-study-cheetah-enhanced`,`crossword-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Use the English clues to fill in the Greek words. Accents and breathing marks are not required.`,`Use the English clues to fill in the Greek words. Include accents and breathing marks.`,`Fill in the Greek words.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-crossword-instructions`,``);s(r,`role`,`grid`),s(r,`aria-description`,`${t.letterCase===`lowercase`?`This puzzle uses lowercase letters. `:``}Select a clue or square, then type US letters using the on-screen Greek mapping, type Greek directly, or use the on-screen keyboard. Tap a suitable filled square, hold a marked key, or tap and release Control for diacritics. Select number 1 to accept, or Escape to cancel. Click a selected crossing again or press Enter to change direction. Use arrow keys to move. Tab selects the next clue; Shift+Tab selects the previous clue, wrapping by number with Across before Down. Escape moves to the puzzle controls for normal tabbing.`);let R=t.clues.map(e=>{let t=i.find(t=>t.dataset.entryId===e.id);if(!t)throw Error(`Crossword worksheet is missing a clue.`);for(let e of t.children)s(e,`hidden`,``);let n=l(t,`${e.number}. ${e.text}`,()=>{z(e,Z(e)[0],!0)});return n.classList.add(`sc-crossword-clue`),n});function z(e,t,n){if(j(),t===m?e.id!==p.id&&S?.resumePosition&&(S={position:S.position,value:S.value}):S=null,(t!==m||e.id!==p.id)&&(C=null),p=e,h=e.direction,m=t,x=`${e.number} ${e.direction}: ${e.text}.`,$(),n){let e=k.get(t);e?.focus(),I(e)}}function B(e,n){let r=t.clues.filter(t=>Z(t).includes(e)),i=r.find(e=>e.direction===h),a=r.find(e=>e.direction!==h),o=(n&&e===m?a:i)??i??a;o&&z(o,e,!1)}function V(){try{d.saveCrosswordProgress(n.publicationId,t,{revision:t.revision,puzzle:fe(t),letters:f,submitted:g,attempts:_,updated:Date.now()}),y=null}catch(e){L(e)}}function H(e,t,n=!0){if(e!==m||v)return;let r=k.get(e);if(!t)delete f[e],C=null;else{try{f[e]=N(t)}catch{x=`Enter one Greek letter per square.`,$(),n&&I(r);return}C=e}g=!1;let[i,a]=e.split(`,`).map(Number);x=n?``:t?`${f[e]} entered in row ${i+1}, column ${a+1}.`:`Row ${i+1}, column ${a+1} cleared.`,V();let o=Z(p),s=o[o.indexOf(e)+1];t&&s&&(m=s),$(),n&&(t&&s?k.get(s)?.focus():I(r))}function U(){X.hidden&&(X.hidden=!1,q.setAttribute(`aria-pressed`,`true`),n.onkeyboardvisibilitychange?.(!0))}function ee(){let e=f[m];if(e)return _e(e)?m:null;let t=Z(p),n=t[t.indexOf(m)-1];return n&&n===C&&f[n]&&_e(f[n])?n:null}function W(e,t=m){let n=a.activeElement instanceof a.defaultView.HTMLInputElement&&a.activeElement.classList.contains(`sc-crossword-input`),r=t===m?void 0:m;m=t,S={position:m,value:xe(e),...r?{resumePosition:r}:{}},U(),x=`Diacritics for ${S.value}. Choose a mark, then 1 to accept or Escape to cancel.`,$(),n&&k.get(t)?.focus()}function te(){if(v||S)return;let e=ee();e?W(f[e],e):(x=`Select or enter a letter that supports diacritics.`,$())}function ne(){let e=S?.resumePosition,t=a.activeElement instanceof a.defaultView.HTMLInputElement&&a.activeElement.classList.contains(`sc-crossword-input`);S=null,e&&(m=e,t&&k.get(e)?.focus())}function re(){ne(),x=`Diacritics cancelled.`,$()}function ie(){S?re():te()}function ae(e,t,n=!1){let r;try{r=N(e)}catch{x=`Enter one Greek letter per square.`,$();return}let i=!!S;if(S){let e=S;S=null,H(e.position,e.value,t)}(i||n)&&_e(r)?W(r):H(m,r,t)}function G(e){if(!S)return;let t=S;S=null,H(t.position,t.value,e)}function oe(e){if(!S)return;let t=Y(S.value).find(t=>t.number===e);t?.enabled&&(S={...S,value:t.value},x=`${t.name} ${t.selected?`removed`:`selected`}: ${t.value}.`,$())}for(let[n,i]of t.cells.entries())for(let[a,l]of i.entries()){if(!l)continue;let i=r.rows[n].cells[a],u=ge(n,a);s(i,`role`,`gridcell`);let d=c(i,`input`,`sc-crossword-input`);d.type=`text`,d.inputMode=`none`,d.lang=t.language,d.autocomplete=`off`,d.spellcheck=!1,d.dataset.crosswordCell=u,k.set(u,d);let p=!1,g=()=>{p=u===m&&e.ownerDocument.activeElement===d},_=()=>{u!==m&&B(u,!1),I(d)},v=()=>{p&&B(u,!0),p=!1,I(d);let e=f[u];e&&_e(e)&&S?.position!==u&&W(e)},y=e=>e.preventDefault(),b=()=>I(d),x=e=>`inputType`in e&&typeof e.inputType==`string`&&[`insertFromPaste`,`insertFromPasteAsQuotation`,`insertFromDrop`,`deleteByCut`,`deleteByDrag`].includes(e.inputType),C=e=>{if(`isComposing`in e&&!e.isComposing&&`inputType`in e&&(e.inputType===`insertText`||e.inputType===`insertReplacementText`)&&`data`in e&&typeof e.data==`string`&&e.data)return e.data},w=e=>{if(x(e)){e.preventDefault();return}if(e.cancelable&&`inputType`in e&&(e.inputType===`deleteContentBackward`||e.inputType===`deleteContentForward`)){e.preventDefault(),S=null,H(u,``);return}let t=C(e);!e.cancelable||t===void 0||(e.preventDefault(),F(),ae(t,!0))},T=e=>{if(`isComposing`in e&&e.isComposing)return;if(u!==m||x(e)){d.value=f[u]??``;return}let t=C(e)??d.value;t?(F(),ae(t,!0)):(S=null,H(u,``))},E=e=>{e.data?(F(),ae(e.data,!0)):(d.value=f[u]??``,u===m&&I(d))},D=e=>{if((e.ctrlKey||e.metaKey)&&[`a`,`c`,`x`,`v`].includes(e.key.toLowerCase())){e.preventDefault();return}if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;if(e.key===`Backspace`||e.key===`Delete`){e.preventDefault(),S=null,H(u,``);return}if(e.key===`Enter`){e.preventDefault(),B(u,!0);return}let r={ArrowLeft:[0,-1,`across`],ArrowRight:[0,1,`across`],ArrowUp:[-1,0,`down`],ArrowDown:[1,0,`down`]}[e.key];if(!r)return;e.preventDefault();let[i,o,s]=r;for(let e=n+i,r=a+o;e>=0&&e<t.rows&&r>=0&&r<t.columns;e+=i,r+=o){let t=ge(e,r);if(k.has(t)){h=s,B(t,!1),k.get(t)?.focus();break}}};d.addEventListener(`pointerdown`,g),d.addEventListener(`focus`,_),d.addEventListener(`click`,v),d.addEventListener(`beforeinput`,w),d.addEventListener(`input`,T),d.addEventListener(`compositionend`,E),d.addEventListener(`keydown`,D),d.addEventListener(`select`,b);let O=[`copy`,`cut`,`paste`,`contextmenu`,`selectstart`,`dragstart`,`drop`];for(let e of O)d.addEventListener(e,y);o.push(()=>{d.removeEventListener(`pointerdown`,g),d.removeEventListener(`focus`,_),d.removeEventListener(`click`,v),d.removeEventListener(`beforeinput`,w),d.removeEventListener(`input`,T),d.removeEventListener(`compositionend`,E),d.removeEventListener(`keydown`,D),d.removeEventListener(`select`,b);for(let e of O)d.removeEventListener(e,y)})}let se=c(c(e,`div`,`sc-crossword-footer`),`div`,`sc-crossword-footer-row`),K=c(se,`p`,`sc-crossword-status`);K.setAttribute(`role`,`status`),K.setAttribute(`aria-live`,`polite`);let ce=c(K,`span`,`sc-activity-status-full`),le=c(K,`span`,`sc-activity-status-compact`);le.setAttribute(`aria-hidden`,`true`);let de=c(K,`span`,`sc-crossword-announcement`),pe=u(),me=c(se,`div`,`sc-crossword-controls`),q=l(me,`Greek keyboard`,()=>{X.hidden=!X.hidden,q.setAttribute(`aria-pressed`,String(!X.hidden)),n.onkeyboardvisibilitychange?.(!X.hidden),X.hidden&&(ne(),Q(),$())});q.setAttribute(`aria-pressed`,String(n.keyboardVisible!==!1));let he=l(me,`Check answers`,()=>{ne(),g=!0,_++,x=``,V(),$()});he.classList.add(`sc-crossword-check`);let J=l(me,`Reset puzzle`,()=>{try{d.deleteCrosswordProgress(n.publicationId,t),S=null,C=null,f={},g=!1,_=0,v=!1,x=`Answers cleared.`,V()}catch(e){L(e)}$()});J.classList.add(`sc-crossword-reset`);let ve=l(me,`Print worksheet`,n.onprint);ve.classList.add(`sc-crossword-print`);for(let[e,t,n]of[[q,`Keyboard`,`M3 5h18v14H3zM6 9h1M10 9h1M14 9h1M18 9h1M6 12h1M10 12h1M14 12h1M18 12h1M7 16h10`],[he,`Check`,`M5 12l4 4L19 6`],[J,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[ve,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])Dt(e,t,n);let X=c(e,`div`,`sc-crossword-keyboard`);X.hidden=n.keyboardVisible===!1,X.setAttribute(`role`,`group`),X.setAttribute(`aria-label`,`Greek on-screen keyboard`);let be=a.createElement(`div`);be.className=`sc-crossword-keyboard-caption`,be.textContent=`Greek keyboard · Hold marked keys for diacritics`,X.append(be);let Se=a.createElement(`div`);Se.className=`sc-crossword-keyboard-rows`,X.append(Se);let Ce=[],we=new Map,Te=new Map,Ee=null,De=null;for(let e of Pt){let t=a.createElement(`div`);t.className=`sc-crossword-keyboard-row`;for(let[n,r]of e){let e=/^[0-9]$/.test(n),i=a.createElement(r||e||n===`Backspace`||n===`Diacritics`||n===`Shift`?`button`:`span`);if(i.className=`sc-crossword-keyboard-key${n.length>1?` sc-crossword-keyboard-key-wide`:``}`,i instanceof a.defaultView.HTMLButtonElement){i.type=`button`,e&&(i.classList.add(`sc-crossword-keyboard-number`),Te.set(n,i)),i.setAttribute(`aria-label`,r?`${r} (${n})`:n===`Backspace`?`Clear current square`:n),n===`Diacritics`&&(i.classList.add(`sc-crossword-keyboard-mode`),Ee=i),n===`Shift`&&(i.classList.add(`sc-crossword-keyboard-shift`),De=i);let t,s=!1,c=null,l=0,u=0,d=()=>{t!==void 0&&window.clearTimeout(t),t=void 0,c=null};if(r&&_e(r)){i.classList.add(`sc-crossword-keyboard-has-marks`),i.setAttribute(`aria-description`,`Hold for diacritics.`),i.addEventListener(`pointerdown`,e=>{e.button!==0||v||(s=!1,c=e.pointerId,l=e.clientX,u=e.clientY,t=window.setTimeout(()=>{t=void 0,c!==null&&(s=!0,i.focus({preventScroll:!0}),ae(P(r),!1,!0))},It))});let e=e=>{e.pointerId===c&&Math.hypot(e.clientX-l,e.clientY-u)>10&&(s=!0,d())},n=e=>{e.pointerId===c&&d()};a.addEventListener(`pointermove`,e),a.addEventListener(`pointerup`,n),a.addEventListener(`pointercancel`,n),i.addEventListener(`keydown`,()=>{s=!1}),i.addEventListener(`contextmenu`,e=>e.preventDefault()),o.push(()=>{d(),a.removeEventListener(`pointermove`,e),a.removeEventListener(`pointerup`,n),a.removeEventListener(`pointercancel`,n)})}i.addEventListener(`click`,()=>{if(s){s=!1;return}i.focus({preventScroll:!0}),r?ae(P(r),!1):e?n===`1`?G(!1):oe(n):n===`Diacritics`?ie():n===`Shift`?(E=E===`off`?`once`:E===`once`?`locked`:`off`,$()):(f[m]||S)&&(S=null,H(m,``,!1))}),Ce.push(i),r&&we.set(n,i)}else i.setAttribute(`aria-hidden`,`true`),i.classList.add(`sc-crossword-keyboard-placeholder`);if(r||e||n===`Diacritics`){let e=a.createElement(`span`);e.className=`sc-crossword-keyboard-original`,e.textContent=n===`Diacritics`?`Ctrl`:n,i.append(e)}let s=a.createElement(`span`);s.textContent=r||(e?``:n===`Diacritics`?`Marks`:n),(r||e)&&(s.lang=`el`),i.append(s),t.append(i)}Se.append(t)}let Oe=new Map,ke=!1,Q=()=>{j();for(let e of Oe.values())e.classList.remove(`sc-crossword-keyboard-pressed`);Oe.clear(),Ee?.classList.remove(`sc-crossword-keyboard-pressed`),ke=!1;let e=D;D=!1,e&&$()},Ae=e=>{let t=e.shiftKey,n=e.getModifierState(`CapsLock`);(t!==D||n!==O)&&(D=t,O=n,$())},je=e=>{let t=e.code||e.key.toUpperCase();if(T!==t&&j(),e.key===`Control`&&!e.repeat&&!e.altKey&&!e.metaKey&&!e.shiftKey){let t=e.target;ke=!v&&t instanceof a.defaultView.Element&&!!t.closest(`.sc-crossword-input, .sc-crossword-keyboard`),ke&&Ee?.classList.add(`sc-crossword-keyboard-pressed`);return}if(e.key!==`Control`&&(ke=!1),e.defaultPrevented||e.ctrlKey||e.metaKey||e.altKey||e.isComposing||v)return;let r=e.target;if(!(r instanceof a.defaultView.Element)||!r.closest(`.sc-crossword-input, .sc-crossword-keyboard`))return;if(e.key===`Tab`){e.preventDefault(),S=null;let t=A[(A.indexOf(p)+(e.shiftKey?-1:1)+A.length)%A.length];z(t,Z(t)[0],!0);return}if(e.key===`Escape`){if(e.preventDefault(),Q(),S){re();return}n.onfocuscontrols?n.onfocuscontrols():(he.disabled?J:he).focus();return}let i=r.classList.contains(`sc-crossword-input`),o=/^Digit[0-9]$/.test(e.code)?e.code.slice(-1):e.key;if(S&&/^[0-9]$/.test(o)){e.preventDefault(),o===`1`?G(i):oe(o);return}if(e.key===`Backspace`||e.key===`Delete`){e.preventDefault(),S=null,H(m,``,i);return}let s=e.key.toUpperCase(),c=Ft.get(s),l=we.get(s);if(!c||!l||(e.preventDefault(),e.repeat||Oe.has(t)))return;Oe.set(t,l),l.classList.add(`sc-crossword-keyboard-pressed`);let u=m,d=p.id,h=!!S,g=P(c);if(ae(g,i),!h&&!S&&C===u&&_e(c)){let e=m;T=t,w=window.setTimeout(()=>{w=void 0;let n=T===t&&Oe.has(t)&&!v&&!S&&m===e&&p.id===d&&C===u&&f[u]===g;T=null,n&&W(g,u)},It)}},Me=e=>{if(e.key===`Control`){let t=ke&&!e.altKey&&!e.metaKey&&!e.shiftKey&&!!a.activeElement?.closest(`.sc-crossword-input, .sc-crossword-keyboard`);ke=!1,Ee?.classList.remove(`sc-crossword-keyboard-pressed`),t&&ie()}let t=e.code||e.key.toUpperCase();T===t&&j(),Oe.get(t)?.classList.remove(`sc-crossword-keyboard-pressed`),Oe.delete(t)},Ne=t=>{(!(t.relatedTarget instanceof a.defaultView.Node)||!e.contains(t.relatedTarget))&&Q()};e.addEventListener(`keydown`,je),e.addEventListener(`pointerdown`,j),e.addEventListener(`focusout`,Ne),a.addEventListener(`keydown`,Ae,!0),a.addEventListener(`keyup`,Ae,!0),a!==window.document&&(window.document.addEventListener(`keydown`,Ae,!0),window.document.addEventListener(`keyup`,Ae,!0)),a.addEventListener(`keyup`,Me),a.addEventListener(`visibilitychange`,Q),a.defaultView.addEventListener(`blur`,Q),o.push(()=>{e.removeEventListener(`keydown`,je),e.removeEventListener(`pointerdown`,j),e.removeEventListener(`focusout`,Ne),a.removeEventListener(`keydown`,Ae,!0),a.removeEventListener(`keyup`,Ae,!0),a!==window.document&&(window.document.removeEventListener(`keydown`,Ae,!0),window.document.removeEventListener(`keyup`,Ae,!0)),a.removeEventListener(`keyup`,Me),a.removeEventListener(`visibilitychange`,Q),a.defaultView.removeEventListener(`blur`,Q),Q()});function $(){let e=Z(p),n=t.clues.filter(e=>ue(e,f)).length;ce.textContent=g?`${n} of ${t.clues.length} correct.${n===t.clues.length?` Puzzle complete.`:``}`:`${Object.keys(f).length} of ${k.size} squares filled. Not checked.`,le.textContent=g?`${n}/${t.clues.length} OK`:`${Object.keys(f).length}/${k.size} set`,de.textContent=x?` ${x}`:``,pe(y,b),he.disabled=v||Object.keys(f).length===0;for(let e of Ce)e.disabled=v;for(let[e,t]of we){let n=Ft.get(e),r=M()?n.toUpperCase():n;t.setAttribute(`aria-label`,`${r} (${e})`),t.lastElementChild&&t.lastElementChild.textContent!==r&&(t.lastElementChild.textContent=r)}if(De){let e=t.letterCase===`lowercase`;De.disabled=v||e,De.dataset.shift=E,De.dataset.locked=String(!e&&(E===`locked`||O)),De.setAttribute(`aria-pressed`,String(!e&&(E!==`off`||D||O))),De.setAttribute(`aria-description`,e?`This puzzle uses lowercase letters only.`:E===`locked`?`Shift lock on. Activate to turn off.`:E===`once`?`Shift on for the next letter. Activate again to lock.`:`${O?`Physical Caps Lock on. `:D?`Physical Shift held. `:``}Activate for one letter, then again to lock.`);let n=!e&&(E===`locked`||O)?`Lock`:`Shift`;De.lastElementChild&&De.lastElementChild.textContent!==n&&(De.lastElementChild.textContent=n)}if(Ee){let e=!!S;Ee.disabled=v||!e&&!ee(),Ee.setAttribute(`aria-label`,e?`Cancel diacritics`:`Diacritics`);let t=Ee.lastElementChild;t&&(t.textContent=e?`Cancel`:`Marks`)}let r=S?Y(S.value):[];for(let[e,t]of Te){let n=r.find(t=>t.number===e),i=!!S&&(e===`1`||!!n?.enabled);t.disabled=v||!i,t.classList.toggle(`sc-crossword-keyboard-placeholder`,!S),t.setAttribute(`aria-hidden`,String(!S)),t.tabIndex=S&&i?0:-1,t.setAttribute(`aria-label`,e===`1`&&S?`Accept ${S.value} (1)`:n?`${n.name} (${e}): ${n.enabled?n.value:`unavailable`}`:e),n?t.setAttribute(`aria-pressed`,String(n.selected)):t.removeAttribute(`aria-pressed`);let a=t.lastElementChild;a&&(a.textContent=S?e===`1`?S.value:n?.enabled?n.value:`–`:e)}R.forEach((e,n)=>{e.disabled=v,e.setAttribute(`aria-pressed`,String(t.clues[n].id===p.id));let r=t.clues[n],i=Z(r),a=g&&i.some(e=>f[e])?ue(r,f)?`correct`:`incorrect`:``;e.dataset.result=a,e.setAttribute(`aria-description`,a===`correct`?`Correct`:a===`incorrect`?`Not correct`:`Not checked`)});for(let[n,r]of k){let[i,a]=n.split(`,`).map(Number),o=f[n]??``;r.value!==o&&(r.value=o),r.disabled=v,r.tabIndex=n===m?0:-1,r.classList.toggle(`sc-crossword-selected`,e.includes(n)),r.classList.toggle(`sc-crossword-current`,n===m);let s=t.clues.filter(e=>Z(e).includes(n)).map(e=>`${e.number} ${e.direction}: ${e.text}`).join(`; `);r.setAttribute(`aria-label`,`Row ${i+1}, column ${a+1}. ${s}`)}}$();let Pe=e.querySelector(`.crossword-layout`),Fe=Pe?.querySelector(`.crossword-clues`);if(Pe&&Fe){let n=[...e.children].filter(e=>e!==Pe),r=e=>Number.parseFloat(e)||0,i=()=>{if(!e.clientHeight||!e.clientWidth)return;let i=getComputedStyle(e),a=n.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),o=e.clientHeight-r(i.paddingTop)-r(i.paddingBottom)-r(i.rowGap)*a.length;for(let e of a){let t=getComputedStyle(e);o-=e.getBoundingClientRect().height+r(t.marginTop)+r(t.marginBottom)}o-=t.rows+2;let s=e.clientWidth-r(i.paddingLeft)-r(i.paddingRight);Pe.dataset.crosswordWide=String(s>=700);let c=r(getComputedStyle(Pe).columnGap),l=s-Fe.offsetWidth-c,u=t.columns*24,d=Math.floor(Math.max(u,Math.min(l,o*t.columns/t.rows)));Pe.style.setProperty(`--sc-crossword-width`,`${d}px`),Pe.style.setProperty(`--sc-crossword-height`,`${Math.ceil(d*t.rows/t.columns)}px`)},a=new ResizeObserver(i);a.observe(e);for(let e of n)a.observe(e);i(),o.push(()=>{a.disconnect(),Pe.style.removeProperty(`--sc-crossword-width`),Pe.style.removeProperty(`--sc-crossword-height`),delete Pe.dataset.crosswordWide})}return()=>{for(let e of o.reverse())e()}}function Rt(e,t,n,r){let i=e.contentDocument,a=i?.defaultView,o=e.parentElement;if(!i||!a||!o)throw Error(`Activity publication frame is unavailable.`);let s=n.kind===`matching-v1`,c=n.kind===`crossword-v1`,l=s?`data-reader-matching-source`:c?`data-reader-crossword-source`:`data-reader-word-search-source`,u=e.ownerDocument.createElement(`iframe`);u.className=s?`reader-matching-frame`:c?`reader-crossword-frame`:`reader-word-search-frame`,u.title=`Interactive exercise: ${n.title}`,u.style.cssText=`position:absolute;inset:0;width:100%;height:100%;border:0;`,o.append(u);let d=u.contentDocument;if(!d)throw u.remove(),Error(`Could not create the reader-owned activity frame.`);let f=d.createElement(`meta`);f.httpEquiv=`Content-Security-Policy`,f.content=`default-src 'none'; style-src 'unsafe-inline'`,d.head.append(f),d.title=n.title,d.documentElement.lang=i.documentElement.lang;let p=d.createElement(`style`);p.textContent=`
    html, body { box-sizing: border-box; margin: 0; width: 100%; height: 100%; overflow: hidden; }
    h1 { margin: 0 0 1em; font-size: 1.3em; }
    h2 { margin: 0 0 0.75em; font-size: 1.1em; }
    .word-search-board { overflow: auto; }
    [data-word-search-grid] {
      width: 100%; min-width: 0; table-layout: fixed; border-collapse: collapse; margin: 0 auto;
      color: var(--reader-matching-greek, #0070c0);
    }
    [data-word-search-grid] td { position: relative; border: 0; padding: 0; text-align: center; }
    [data-word-search-grid] td > span { display: grid; place-items: center; aspect-ratio: 1; width: 100%; line-height: 1; }
    [data-word-search-words] { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); margin: 0; padding: 0; list-style: none; gap: 0.3em 1em; }
    [data-word-search-words] > li { color: var(--reader-matching-greek, #0070c0); }
    .crossword-layout { display: grid; gap: 1em; align-items: center; }
    .crossword-clues { gap: 1em; }
    .crossword-clues ol { list-style: none; padding: 0; }
    .crossword-grid { table-layout: fixed; border-collapse: collapse; }
    .crossword-grid td { position: relative; padding: 0; }
    .crossword-grid td::before { content: ''; display: block; padding-top: 100%; }
    .crossword-cell { border: 1px solid currentColor; }
    .crossword-number { position: absolute; top: 0; left: 2px; font: 10px sans-serif; }
  `,d.head.append(p);let m=d.createElement(`main`);m.setAttribute(`data-study-cheetah-activity`,n.kind),m.setAttribute(`data-activity-id`,n.id),m.setAttribute(`data-activity-revision`,n.revision),n.chapterTitle&&m.setAttribute(`data-chapter-title`,n.chapterTitle),s||(m.className=c?`crossword`:`word-search`);let h=d.createElement(`h1`);h.textContent=n.title,m.append(h);for(let e of t.querySelectorAll(`:scope > p`)){if(a.getComputedStyle(e).display===`none`)continue;let t=d.createElement(`p`);t.textContent=e.textContent,m.append(t)}if(n.kind===`matching-v1`){let e=d.createElement(`div`);e.className=`matching-columns`;for(let[t,r,i]of[[`Greek words`,n.prompts,!0],[`English meanings`,n.choices,!1]]){let n=d.createElement(`section`),a=d.createElement(`h2`);a.textContent=t;let o=d.createElement(`ol`);o.setAttribute(i?`data-matching-prompts`:`data-matching-choices`,``);for(let e of r){let t=d.createElement(`li`);t.setAttribute(i?`data-match-id`:`data-choice-id`,e.id);let n=d.createElement(`span`);n.setAttribute(i?`data-prompt-text`:`data-choice-text`,``),n.textContent=e.text,e.language&&(n.lang=e.language,t.lang=e.language),t.append(n),o.append(t)}n.append(a,o),e.append(n)}m.append(e)}else if(n.kind===`crossword-v1`){let e=d.createElement(`div`);e.className=`crossword-layout`;let t=d.createElement(`div`);t.className=`crossword-clues`;for(let e of[`across`,`down`]){let r=d.createElement(`section`),i=d.createElement(`h2`);i.textContent=e===`across`?`Across`:`Down`;let a=d.createElement(`ol`);for(let t of n.clues.filter(t=>t.direction===e)){let e=d.createElement(`li`);e.dataset.entryId=t.id,a.append(e)}r.append(i,a),t.append(r)}let r=d.createElement(`table`);r.className=`crossword-grid`;let i=d.createElement(`tbody`);for(let[e,t]of n.cells.entries()){let r=d.createElement(`tr`);for(let[i,a]of t.entries()){let t=d.createElement(`td`);t.className=a?`crossword-cell`:`crossword-empty`;let o=n.clues.find(t=>t.row===e&&t.column===i);if(o){let e=d.createElement(`span`);e.className=`crossword-number`,e.textContent=String(o.number),t.append(e)}r.append(t)}i.append(r)}r.append(i),e.append(t,r),m.append(e)}else{let e=d.createElement(`div`);e.setAttribute(`data-word-search-layout`,``);let t=d.createElement(`div`);t.className=`word-search-board`;let r=d.createElement(`table`);r.setAttribute(`data-word-search-grid`,``),r.setAttribute(`aria-label`,`Greek word search, ${n.grid.length} rows by ${n.grid[0].length} columns`),r.lang=`el`;let i=d.createElement(`tbody`);for(let e of n.grid){let t=d.createElement(`tr`);for(let n of e){let e=d.createElement(`td`),r=d.createElement(`span`);r.textContent=n,e.append(r),t.append(e)}i.append(t)}r.append(i),t.append(r);let a=d.createElement(`section`);a.className=`word-search-vocabulary`;let o=d.createElement(`h2`);o.textContent=`Words to find`;let s=d.createElement(`ul`);s.setAttribute(`data-word-search-words`,``),s.lang=`el`;for(let e of n.words){let t=d.createElement(`li`);t.setAttribute(`data-word-id`,e.id),t.textContent=e.text,s.append(t)}a.append(o,s),e.append(t,a),m.append(e)}d.body.append(m);let g;try{g=n.kind===`matching-v1`?kt(m,n,r):n.kind===`crossword-v1`?Lt(m,n,r):jt(m,n,r)}catch(e){throw u.remove(),e}let _=e.getAttribute(`aria-hidden`),v=e.getAttribute(`tabindex`),y=e.style.opacity;e.setAttribute(`aria-hidden`,`true`),e.setAttribute(`tabindex`,`-1`),e.setAttribute(l,``),e.style.opacity=`0`;let b=()=>{let e=a.getComputedStyle(i.body),r=a.getComputedStyle(i.documentElement);d.documentElement.style.fontSize=r.fontSize,d.documentElement.style.backgroundColor=r.backgroundColor;for(let t of[`width`,`height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`transform`,`transform-origin`,`font-size`,`font-family`,`line-height`,`color`,`background-color`,`--reader-page-fg`,`--reader-page-bg`,`--reader-matching-correct`,`--reader-matching-incorrect`,`--reader-matching-reset`,`--reader-matching-greek`,...ie,`--reader-control-greek`,`--reader-control-check`,`--reader-control-reset`,`--reader-control-print`])d.body.style.setProperty(t,e.getPropertyValue(t));d.body.style.lineHeight=e.lineHeight===`normal`?`normal`:String(parseFloat(e.lineHeight)/parseFloat(e.fontSize));let o=a.getComputedStyle(t);if(m.style.rowGap=o.rowGap,m.style.columnGap=o.columnGap,n.kind===`word-search-v1`){let e=t.querySelector(`[data-word-search-words]`),n=m.querySelector(`[data-word-search-words]`),r=a.getComputedStyle(e);for(let e of[`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`row-gap`,`column-gap`])n.style.setProperty(e,r.getPropertyValue(e))}let s=[...t.querySelectorAll(`h1,h2`)];for(let[e,t]of[...m.querySelectorAll(`h1,h2`)].entries()){let n=s[e];if(!n)continue;let r=a.getComputedStyle(n);for(let e of[`font-size`,`font-family`,`font-weight`,`line-height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`])t.style.setProperty(e,r.getPropertyValue(e))}};b();let x=new MutationObserver(b);x.observe(i.head,{subtree:!0,childList:!0,characterData:!0,attributes:!0}),x.observe(i.body,{attributes:!0}),x.observe(i.documentElement,{attributes:!0});let S=new ResizeObserver(b);return S.observe(e),{root:m,cleanup:()=>{x.disconnect(),S.disconnect(),g(),u.remove(),e.removeAttribute(l),_===null?e.removeAttribute(`aria-hidden`):e.setAttribute(`aria-hidden`,_),v===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,v),e.style.opacity=y}}}function zt(e){let{pointerX:t,pointerY:n,screenWidth:r,screenHeight:i,hasPreviousChapter:a,hasNextChapter:o}=e,s=r*.33,c=r*.67,l=i*.33,u=i*.67;return t<s&&a?`previous`:t>c&&o?`next`:t>=s&&t<=c&&n>=l&&n<=u?`toggle-ui`:`none`}var Bt=5e3;function Vt(){let e=document.activeElement;e instanceof Element&&(e.closest(`.chapter-menu`)?document.querySelector(`.reading-header .menu-button`)?.focus():e.closest(`.adjustment-popup`)?e.closest(`.reader-adjustment-control`)?.querySelector(`button[aria-expanded]`)?.focus():e.closest(`.theme-settings-panel`)&&e.closest(`.theme-settings`)?.querySelector(`.settings-trigger`)?.focus())}function Ht(e,t,n,r,i=()=>!1){let a;function o(){clearTimeout(a),a=void 0}function s(){o(),e()&&(a=setTimeout(()=>{t()?n():i()?s():r()},Bt))}return{pause:o,reset:s}}var Ut=d(`<div class="loading-overlay svelte-1jg2usx"><div class="spinner svelte-1jg2usx" aria-hidden="true"></div> <p>Opening book...</p></div>`),Wt=d(`<button class="svelte-1jg2usx">Retry</button>`);d(`<button class="svelte-1jg2usx">Back to library</button>`);var Gt=d(`<div class="error-overlay svelte-1jg2usx" role="alert"><p class="error-title svelte-1jg2usx">Could not open book</p> <p class="error-body svelte-1jg2usx"> </p> <!></div>`),Kt=d(`<img alt="" class="cover-image"/>`),qt=d(`<p> </p>`),Jt=d(`<div class="cover-fallback" aria-hidden="true"><p> </p> <!></div>`),Yt=d(`<button class="cover-overlay" type="button" aria-label="Start reading"><div class="cover-page svelte-1jg2usx" role="img"><!></div></button>`),Xt=d(`<p class="save-error svelte-1jg2usx" role="alert"> </p>`),Zt=d(`<div aria-hidden="true"></div> <div aria-hidden="true"></div>`,1),Qt=d(`<div role="main"><dialog class="safari-warning svelte-1jg2usx" aria-labelledby="safari-warning-title" aria-describedby="safari-warning-description"><h2 id="safari-warning-title" class="svelte-1jg2usx">Safari reader limitations</h2> <p id="safari-warning-description" class="svelte-1jg2usx">Tap the left or right edge to turn pages. Other book interactions and
      some keyboard shortcuts may not work in Safari. Use the
      header or footer to show the chapter menu in the header and position slider in the footer.</p> <form method="dialog"><button type="submit" class="svelte-1jg2usx">Continue reading</button></form></dialog> <!> <!> <div class="epub-viewport svelte-1jg2usx"><!> <!> <!> <!></div> <!> <!></div> <!>`,1);function $t(r,l){A(l,!0);let d=`study-cheetah.reader.display-mode`,f=ye.getInstance(),m=be.getInstance(),_=ee(),b=ae(),x=h(null),S=h(P([])),C=h(0),T=h(`best-fit`),D=h(null),k=h(1),M=h(!0),I=h(!1),L=h(!1),z=h(null),B=h(!1),V=h(null),H,W=h(!1),ie=h(!0),G=h(!0),oe=h(null),K=h(null),le=h(null),ue=h(null),de=h(null),fe=h(void 0),me=h([]),q=h(new Map),he=h(new Map),ge=h(new Map),_e=h(null),J,Y=null,Z=!1,xe=!1,Ce,Te,Ee=0,De=0,Oe=0,ke=!1,Q=new Set,Ae=Promise.resolve(),je=!1,Me=new AbortController,Ne=new Map,$=new Map,Pe=new Map,Fe=g(()=>c(S)[c(C)]),Ie=g(()=>{let e=c(me).filter(e=>c(D)&&e.spineIndex>=c(D).start.index&&e.spineIndex<=c(D).end.index);return[...e].reverse().find(t=>t.spineIndex===e[0].spineIndex)}),Re=g(()=>c(Ie)?.activity),ze=g(()=>c(Ie)&&!c(W)?c(q).get(Xe(c(Ie).viewId,c(Ie).activity)):void 0),Be=g(()=>{let e=c(D);if(!e||c(W)||c(G)||c(oe))return null;let t=t=>t>=e.start.index&&t<=e.end.index;return[...c(he).values()].some(t)?[...c(ge).values()].some(t)?`activity`:`ordinary`:null}),Ve=g(()=>c(_e)??c(Re)),He=g(()=>c(D)?.atEnd?100:Math.round((c(D)?.start.percentage??0)*100)),Ue=g(()=>b.resolved.endsWith(`-dark`)?`dark`:`light`),We=g(()=>te(c(x)?.accessibility.theme,b.readerTheme)),Ge=g(()=>re(c(We),b.palette,c(Ue))),Ke=h(P(ne(!1))),qe=g(()=>`Section page ${c(D)?.start.displayed.page??1} of ${c(D)?.start.displayed.total??1}`),Je=g(()=>c(W)?`Tap to start reading`:`${c(He)}% complete`),Ye;function Xe(e,t){return JSON.stringify([e,t.kind,t.id])}function Ze(){o(M,!1),i().then(()=>{document.querySelector(`.reading-footer .activity-footer-actions button:not([aria-pressed]):not(:disabled)`)?.focus()})}let Qe=Ht(()=>c(M),()=>(c(I)||c(L)||c(z)!==null)&&!document.querySelector(`.reading-header .install-help[open]`),()=>{Vt(),o(I,!1),o(L,!1),o(z,null)},()=>{o(M,!1)},()=>!!document.querySelector(`dialog[open], .reading-header .install-help[open]`));t(()=>{c(M)||(o(I,!1),o(L,!1),o(z,null)),c(I),c(L),c(z),Q.size?Qe.pause():Qe.reset()}),t(()=>{c(We),b.palette,c(Ue),_t()});function et(e,t){Z||(console.error(`[Reader] ${e}:`,t),o(oe,`${t instanceof Error?t.message:String(t)}\n\nStage: ${e}`))}function tt(){let e=new URLSearchParams(window.location.search),t=e.get(`mode`)??(e.has(`horizontalPaging`)||e.has(`twoPage`)?null:localStorage.getItem(d));if(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)return t;t!==null&&console.warn(`[Reader] Unrecognized reading view:`,t);let n=e.get(`horizontalPaging`)??localStorage.getItem(`study-cheetah.reader.horizontal-paging`),r=e.get(`twoPage`)??localStorage.getItem(`study-cheetah.reader.two-page`);return n===`1`||n===`true`?`single`:r===`1`||r===`true`?`spread`:n===`0`||n===`false`?`scroll`:`best-fit`}function nt(){if(!c(x)||!je)return Ae;je=!1;let e=c(x);return Ae=Ae.then(()=>f.updateBook(e)).then(()=>{o(K,null)}).catch(e=>{console.error(`[Reader] Saving reading preferences and position failed:`,e),je=!0,o(K,`Could not save your reading position and preferences.`)}),Ae}function rt(){if(je=!0,c(x))try{f.checkpointReadingState(c(x))}catch(e){console.error(`[Reader] Checkpointing reading preferences and position failed:`,e),o(K,`Could not save your reading position and preferences.`)}clearTimeout(Te),Te=setTimeout(()=>{nt()},500)}function it(e){if(o(D,e),c(S)[c(C)]?.spineIndex!==e.start.index){let t=c(S).findIndex(t=>t.spineIndex===e.start.index);t>=0&&o(C,t,!0)}!c(x)||xe||Z||(o(x,{...c(x),currentLocation:{chapterId:c(Fe)?.id??String(e.start.index),chapterIndex:c(C),elementOffset:0,percentageComplete:Math.round((e.start.percentage??0)*100),cfiFragment:e.start.cfi}},!0),rt())}function at(e){if(e!==Y||Z)return;let t=e.currentLocation();t&&it(t)}function ot(){for(let e of Ne.values())e();Ne.clear(),o(me,[]),o(q,new Map),o(he,new Map),o(ge,new Map)}function st(e){let t=!1,n=()=>{t=!0};return e.addEventListener(`study-cheetah-event-probe`,n),e.dispatchEvent(new Event(`study-cheetah-event-probe`)),e.removeEventListener(`study-cheetah-event-probe`,n),t}function ct(e){return!!e&&`closest`in e&&typeof e.closest==`function`&&!!e.closest(`a, button, input, select, textarea, summary, [contenteditable="true"], [role="button"], [role="link"], [data-study-cheetah-enhanced]`)}function lt(e){if(c(L)&&e.key===`Escape`){e.preventDefault(),o(L,!1),document.querySelector(`.settings-trigger`)?.focus();return}if(!Q.size&&(c(I)||c(L)||c(z))&&e.target instanceof Element&&e.target.closest(`.reading-header, .reading-footer`)&&Qe.reset(),document.querySelector(`dialog[open]`)||e.defaultPrevented||e.ctrlKey||e.metaKey||ct(e.target))return;if(e.altKey){!e.shiftKey&&(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),Dt(e.key===`ArrowDown`?1:-1));return}if(e.key===`Escape`){if(H.ownsFullscreen())return;e.preventDefault(),ut();return}let t=e.key===`ArrowRight`||e.key===`PageDown`,n=e.key===`ArrowLeft`||e.key===`PageUp`;!t&&!n||(e.preventDefault(),wt(t?1:-1))}function ut(){Qe.pause(),o(M,!c(M)),c(M)&&ft()}function dt(){c(B)?(o(V,null),H.leave(),o(B,!1)):(o(V,null),H.enter(),o(B,!0),Qe.pause(),o(M,!1))}function ft(){Qe.reset()}function pt(e,t){if(c(W)||c(G)||document.querySelector(`dialog[open]`))return;if(!c(M)&&(t<=60||t>=window.innerHeight-60)){ut();return}let n=zt({pointerX:e,pointerY:t,screenWidth:window.innerWidth,screenHeight:window.innerHeight,hasPreviousChapter:!0,hasNextChapter:!c(D)?.atEnd});n===`toggle-ui`?ut():(n===`next`||n===`previous`)&&wt(n===`next`?1:-1)}function mt(e){e.on(`relocated`,t=>{e===Y&&!Z&&it(t)}),e.on(`layout`,t=>{e===Y&&o(k,t.divisor,!0)}),e.on(`rendered`,(t,n)=>{if(e!==Y||Z)return;Ne.get(n.id)?.();let r=n.document,i=n.iframe;if(!r||!i)return;i.title=`Book content`;let a=st(r),s=n.section.index;if(typeof s==`number`){let e=new Map(c(he)),t=new Map(c(ge));a?e.delete(n.id):e.set(n.id,s),r.querySelector(`[data-study-cheetah-activity]`)?t.set(n.id,s):t.delete(n.id),o(he,e),o(ge,t)}let l=[],u=new Set,d=c(ue);if(d){let e=[];for(let t of d.features){let s=[];try{let u=n.section.index;if(typeof u!=`number`)throw Error(`Exercise reading-order position is unavailable.`);let f=[...r.querySelectorAll(`[data-study-cheetah-activity="${t}"]`)].map(e=>{let l=t===`word-search-v1`?X(e):t===`crossword-v1`?pe(e):Se(e),f=e.parentElement===r.body&&r.querySelectorAll(`[data-study-cheetah-activity]`).length===1,p={publicationId:d.publicationId,onprint:()=>{ht(l)},...f?{onfocuscontrols:Ze}:{}};f&&(e.setAttribute(`data-sc-external-footer`,``),s.push(()=>e.removeAttribute(`data-sc-external-footer`)));let m=e;if(l.kind===`word-search-v1`){if(s.push(jt(e,l,p)),!a&&e.parentElement===r.body){let t=Rt(i,e,l,p);m=t.root,s.push(t.cleanup)}}else if(l.kind===`crossword-v1`){let t=JSON.stringify([d.publicationId,l.id]),n={...p,keyboardVisible:Pe.get(t)??!0,onkeyboardvisibilitychange:e=>{Pe.set(t,e)}};if(s.push(Lt(e,l,n)),!a&&e.parentElement===r.body){let t=Rt(i,e,l,n);m=t.root,s.push(t.cleanup)}}else{let t=JSON.stringify([d.publicationId,l.id,l.revision]);if(s.push(kt(e,l,{...p,order:$.get(t),onorder:e=>{$.set(t,e)}})),!a&&e.parentElement===r.body){let n=Rt(i,e,l,{...p,order:$.get(t),onorder:e=>{$.set(t,e)}});m=n.root,s.push(n.cleanup)}}if(f){let e=Xe(n.id,l);s.push(Et(m,t=>{o(q,new Map(c(q)).set(e,t))})),s.push(()=>{let t=new Map(c(q));t.delete(e),o(q,t)})}return{viewId:n.id,spineIndex:u,activity:l}});e.push(...f),l.push(...s)}catch(e){u.add(t);for(let e of s)e();console.error(`[Reader] Invalid ${t} exercise:`,e),o(le,`Interactive exercise unavailable: ${e instanceof Error?e.message:String(e)}`)}}o(me,[...c(me).filter(e=>e.viewId!==n.id),...e])}if(c(de)){let e=c(de).active.filter(e=>!u.has(e));l.push(ve(r,c(de),e))}let f=0,p=0,m=e=>{o(L,!1),f=e.clientX,p=e.clientY},h=e=>{if(ct(e.target)||r.getSelection()?.isCollapsed===!1||Math.hypot(e.clientX-f,e.clientY-p)>10)return;let t=i.getBoundingClientRect();pt(t.left+e.clientX,t.top+e.clientY)};r.addEventListener(`pointerdown`,m),r.addEventListener(`pointerup`,h),r.addEventListener(`keydown`,lt),Ne.set(n.id,()=>{for(let e of l)e();r.removeEventListener(`pointerdown`,m),r.removeEventListener(`pointerup`,h),r.removeEventListener(`keydown`,lt)})}),e.on(`removed`,(e,t)=>{Ne.get(t.id)?.(),Ne.delete(t.id),o(me,c(me).filter(e=>e.viewId!==t.id));let n=new Map(c(he)),r=new Map(c(ge));n.delete(t.id),r.delete(t.id),o(he,n),o(ge,r)}),e.on(`displayerror`,t=>{e===Y&&!Z&&et(`chapter-display`,t)})}async function ht(e){o(_e,e,!0);try{await i(),window.print()}catch(e){console.error(`[Reader] Printing worksheet failed:`,e),o(le,`Could not print worksheet: ${e instanceof Error?e.message:String(e)}`)}finally{o(_e,null)}}async function gt(e,t){let n,r=()=>{},i=new Promise((t,i)=>{r=i,n=setTimeout(()=>i(Error(`Chapter rendering timed out (15s).`)),15e3),e.on(`displayerror`,r)}),a=()=>r(Error(`Reader closed before chapter rendering completed.`));Me.signal.addEventListener(`abort`,a,{once:!0});try{await Promise.race([e.display(t),i])}finally{clearTimeout(n),e.off(`displayerror`,r),Me.signal.removeEventListener(`abort`,a)}}function _t(){o(Ke,ne(!!document.documentElement.getAttribute(`data-ui-theme`)?.endsWith(`dark`)),!0),c(x)&&m.applyTheme(c(x).id,{...c(x).accessibility,theme:c(We),appPalette:b.palette,appTone:c(Ue)})}async function yt(e){if(!c(x)||Z)return;let t=c(T)===`best-fit`&&!await m.supportsBestFit(c(x).id)?`spread`:c(T);if(Z)return;ot();let n=m.attachRenderer(c(x).id,J,t);Y=n,mt(n),await n.started,!(Z||n!==Y)&&(n.spread(t===`spread`?`auto`:`none`,1e3),_t(),await gt(n,e),at(n))}async function bt(){try{o(T,tt(),!0);let e;if(e=await we(),!e)throw Error(`The selected book was not found in your library.`);if(Z)return;o(x,e,!0),_.applyBookRecord({...e,epubVersion:``});let t=await m.loadBook(e.id,e.opfsPath),n=await m.getMetadata(e.id);if(Z)return;if(o(x,{...e,epubVersion:n.version??``},!0),_.applyBookRecord(c(x)),n.version&&n.version!==e.epubVersion)try{await f.updateBookEpubVersion(e.id,e.hash,n.version)}catch(e){console.warn(`[Reader] Could not save corrected EPUB version:`,e)}try{o(ue,await m.getActivityCapability(e.id),!0),o(de,await m.getExtensionCapability(e.id),!0)}catch(e){console.error(`[Reader] Invalid publication extension declaration:`,e),o(le,`Book enhancements unavailable: ${e instanceof Error?e.message:String(e)}`)}if(o(S,await m.getChapters(e.id),!0),Z||(t.locations.length()===0&&await t.locations.generate(1e3),Z)||(o(C,Math.max(0,Math.min(e.currentLocation?.chapterIndex??0,c(S).length-1)),!0),o(W,!0),await yt(e.currentLocation?.cfiFragment??(e.currentLocation?c(S)[c(C)]?.href:void 0)??0),Z))return;e.currentLocation&&(Ce=setTimeout(St,2e3)),ft()}catch(e){Z||et(`reader-init`,e)}finally{Z||(o(G,!1),o(ie,!1))}}async function xt(e){if(c(G)||!Y||e===c(T))return;let t=Y.currentLocation()?.start.cfi??c(x)?.currentLocation?.cfiFragment??0;o(G,!0),xe=!0,o(T,e,!0);try{localStorage.setItem(d,e),await yt(t)}catch(e){et(`reading-view`,e)}finally{xe=!1,o(G,!1),Y&&at(Y)}}function St(){clearTimeout(Ce),o(W,!1)}async function wt(e){let t=Y;if(!t||c(G)||c(oe))return;if(c(W)){e===1&&St();return}let n=t.currentLocation();if(e===-1&&n?.atStart){o(W,!0);return}if(!(e===1&&n?.atEnd)){o(G,!0);try{e===1?await t.next():await t.prev(),at(t)}catch(e){et(`page-navigation`,e)}finally{o(G,!1)}}}async function Tt(e){let t=c(S)[e],n=Y;if(!(!t||!n||c(G))){o(G,!0),St();try{await gt(n,t.href??t.spineIndex),o(C,e,!0),at(n)}catch(e){et(`chapter-navigation`,e)}finally{o(G,!1)}}}async function Dt(e){let t=Y;if(!(!c(x)||!t||c(G)||c(oe)||!c(S).length))try{let n=t.currentLocation();if(!n)throw Error(`Reading position is not ready for chapter navigation.`);let r=m.getChapterPosition(c(x).id,c(S),n,c(C)),i=e===1?r.chapterIndex+1:r.atBeginning?r.chapterIndex-1:r.chapterIndex;for(;i>=0&&i<c(S).length&&c(S)[i].spineIndex<0;)i+=e;i>=0&&i<c(S).length&&await Tt(i)}catch(e){et(`chapter-navigation`,e)}}async function Ot(e){let t=Y;if(!(!c(x)||!t||c(G)||c(oe))){o(G,!0);try{let n=m.getCfiFromPercentage(c(x).id,e/100);St(),await gt(t,n),at(t)}catch(e){et(`position-navigation`,e)}finally{o(G,!1)}}}async function At(e,t){let n=Y;if(!c(x)||!n||c(G))return;let r=n.currentLocation()?.start.cfi??0;o(x,{...c(x),accessibility:{...c(x).accessibility,[e]:Math.min(2,Math.max(e===`fontSize`?.75:1,Math.round(t*100)/100))}},!0),o(G,!0),xe=!0;try{n.clear(),_t(),await gt(n,r)}catch(e){et(`typography`,e)}finally{xe=!1,o(G,!1),at(n),rt()}}function Mt(e){!c(x)||c(G)||(o(x,{...c(x),accessibility:{...c(x).accessibility,theme:e}},!0),_t(),rt())}function Nt(e){ke=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`),(ke||ct(e.target))&&(Q.add(e.pointerId),Qe.pause()),De=e.clientX,Oe=e.clientY}function Pt(e){if(ct(e.target)||Math.hypot(e.clientX-De,e.clientY-Oe)>10)return;let t=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`);if(ke||t){ke&&t&&!c(M)&&ut();return}pt(e.clientX,e.clientY)}function Ft(){ke=!1}function It(e){!Q.size&&(c(I)||c(L)||c(z))&&e.target instanceof Element&&e.target.closest(`.chapter-menu, .adjustment-popup, .theme-settings-panel`)&&Qe.reset()}function Bt(e){Q.delete(e.pointerId)&&!Q.size&&Qe.reset()}function $t(){Q.clear(),Qe.reset()}function en(e){!Q.size&&(c(I)||c(L)||c(z))&&Qe.reset(),c(W)&&e.deltaY>0&&(e.preventDefault(),St())}F(()=>{H=ce(()=>{o(B,!1),o(M,!0),ft()},e=>{o(V,e,!0)});let e=navigator.userAgent;/\bVersion\/[\d.]+.*\bSafari\//.test(e)&&!/\b(?:Chrome|Chromium|CriOS|FxiOS|Edg|EdgiOS|EdgA|OPR|OPiOS|DuckDuckGo)\//i.test(e)&&Ye.showModal(),window.addEventListener(`keydown`,lt),window.addEventListener(`pointerup`,Bt),window.addEventListener(`pointercancel`,Bt),window.addEventListener(`blur`,$t);let t=new ResizeObserver(()=>{cancelAnimationFrame(Ee),Ee=requestAnimationFrame(()=>{if(!Y||c(G)||Z||!J.clientWidth||!J.clientHeight)return;let e=Y.currentLocation()?.start.cfi;Y.resize(J.clientWidth,J.clientHeight,e)})});t.observe(J);let n=new MutationObserver(()=>_t());return n.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-ui-theme`]}),bt(),()=>{Z=!0,H.destroy(),Me.abort(),t.disconnect(),n.disconnect(),cancelAnimationFrame(Ee),window.removeEventListener(`keydown`,lt),window.removeEventListener(`pointerup`,Bt),window.removeEventListener(`pointercancel`,Bt),window.removeEventListener(`blur`,$t),Qe.pause(),clearTimeout(Ce),clearTimeout(Te),nt(),ot(),c(x)&&m.detachRenderer(c(x).id),Y=null}});var tn=Qt(),nn=a(tn);let rn;var an=p(nn);j(an,e=>Ye=e,()=>Ye);var on=s(an,2),sn=e=>{Ct(e,{get capability(){return c(de)},onready:e=>{o(fe,e,!0)}})};y(on,e=>{c(de)&&!c(ie)&&!c(W)&&e(sn)});var cn=s(on,2),ln=e=>{{let t=g(()=>_.appName||c(x).title||c(x).filename),n=g(()=>c(Re)?.chapterTitle??c(Fe)?.label),r=g(()=>c(x).accessibility.theme??`inherit`),i=g(()=>void 0);Le(e,{get bookTitle(){return c(t)},get chapterTitle(){return c(n)},get controlsVisible(){return c(M)},get readerTheme(){return c(r)},get displayMode(){return c(T)},get busy(){return c(G)},onDisplayModeChange:xt,onReaderThemeChange:Mt,get settingsOpen(){return c(L)},onSettingsOpenChange:e=>{o(L,e,!0),e&&(o(I,!1),o(z,null))},get onClose(){return c(i)},get embedded(){return!0},get onFeatures(){return c(fe)},get chapters(){return c(S)},get currentChapterIndex(){return c(C)},get chapterMenuOpen(){return c(I)},onChapterMenuChange:e=>{o(I,e,!0),e&&o(L,!1)},onChapterSelect:Tt,get immersive(){return c(B)},onImmersiveChange:dt})}};y(cn,e=>{c(x)&&e(ln)});var un=s(cn,2),dn=p(un),fn=e=>{n(e,Ut())},pn=t=>{var r=Gt(),i=s(p(r),2),a=p(i,!0);v(i);var o=s(i,2),l=t=>{var r=Wt();e(`click`,r,()=>window.location.reload()),n(t,r)};y(o,e=>{e(l)}),v(r),U(()=>u(a,c(oe))),n(t,r)},mn=t=>{var r=Yt(),i=p(r),a=p(i),o=e=>{var t=Kt();U(()=>E(t,`src`,c(x).coverImage)),n(e,t)},l=e=>{var t=Jt(),r=p(t),i=p(r,!0);v(r);var a=s(r,2),o=e=>{var t=qt(),r=p(t,!0);v(t),U(()=>u(r,c(x).author)),n(e,t)};y(a,e=>{c(x).author&&e(o)}),v(t),U(()=>u(i,c(x).title??c(x).filename)),n(e,t)};y(a,e=>{c(x).coverImage?e(o):e(l,-1)}),v(i),v(r),U(()=>E(i,`aria-label`,`Cover for ${c(x).title??c(x).filename}`)),e(`click`,r,St),n(t,r)};y(dn,e=>{c(ie)?e(fn):c(oe)?e(pn,1):c(W)&&c(x)&&e(mn,2)});var hn=s(dn,2),gn=e=>{var t=Xt(),r=p(t,!0);v(t),U(()=>u(r,c(K))),n(e,t)};y(hn,e=>{c(K)&&e(gn)});var _n=s(hn,2),vn=e=>{var t=Xt(),r=p(t,!0);v(t),U(()=>u(r,c(le))),n(e,t)};y(_n,e=>{c(le)&&e(vn)});var yn=s(_n,2),bn=e=>{var t=Zt(),r=a(t);let i;var o=s(r,2);let l;U(()=>{i=O(r,1,`page-turn-zone previous svelte-1jg2usx`,null,i,{activity:c(Be)===`activity`}),l=O(o,1,`page-turn-zone next svelte-1jg2usx`,null,l,{activity:c(Be)===`activity`})}),n(e,t)};y(yn,e=>{c(Be)&&e(bn)}),v(un),j(un,e=>J=e,()=>J);var xn=s(un,2),Sn=e=>{{let t=g(()=>c(Fe)?.label??`Front matter`),n=g(()=>!c(W)&&!!c(D)?.atEnd);$e(e,{get controlsVisible(){return c(M)},get fontSize(){return c(x).accessibility.fontSize},get lineHeight(){return c(x).accessibility.lineHeight},get progressPercent(){return c(He)},get currentChapterIndex(){return c(C)},get totalChapters(){return c(S).length},get chapterPositionLabel(){return c(t)},get pageLabel(){return c(qe)},get progressLabel(){return c(Je)},get activityFooter(){return c(ze)},get busy(){return c(G)},onFontSizeChange:e=>At(`fontSize`,e),onLineHeightChange:e=>At(`lineHeight`,e),onProgressChange:Ot,onPreviousPage:()=>wt(-1),onNextPage:()=>wt(1),get previousPageDisabled(){return c(W)},get nextPageDisabled(){return c(n)},get chapterMenuOpen(){return c(I)},onAdjustmentOpen:()=>{o(I,!1),o(L,!1)},get openControl(){return c(z)},set openControl(e){o(z,e,!0)}})}};y(xn,e=>{c(x)&&e(Sn)}),se(s(xn,2),{get message(){return c(V)},onDismiss:()=>{o(V,null)}}),v(nn);var Cn=s(nn,2),wn=e=>{vt(e,{get activity(){return c(Ve)}})};y(Cn,e=>{c(Ve)&&e(wn)}),U(()=>{rn=O(nn,1,`reader-shell svelte-1jg2usx`,null,rn,{"show-ui":c(M),immersive:c(B)}),N(nn,`--reader-page-bg: ${c(Ge).background}; --reader-page-fg: ${c(Ge).foreground}; --reader-page-muted: ${c(Ge).muted}; --reader-page-accent: ${c(Ge).accent}; --reader-page-border: ${c(Ge).border}; --reader-control-check: ${c(Ke).check}; --reader-control-reset: ${c(Ke).reset}; --reader-control-print: ${c(Ke).print};`),E(un,`aria-busy`,c(G)),E(un,`data-display-mode`,c(T)),E(un,`data-start-cfi`,c(D)?.start.cfi),E(un,`data-end-cfi`,c(D)?.end.cfi),E(un,`data-spine-index`,c(D)?.start.index),E(un,`data-page`,c(D)?.start.displayed.page),E(un,`data-total-pages`,c(D)?.start.displayed.total),E(un,`data-visible-pages`,c(k))}),e(`pointerdown`,nn,Nt),e(`pointerup`,nn,Pt),w(`pointercancel`,nn,Ft),e(`pointermove`,nn,It),w(`wheel`,nn,en),e(`pointerdown`,an,e=>e.stopPropagation()),e(`pointerup`,an,e=>e.stopPropagation()),n(r,tn),R()}T([`pointerdown`,`pointerup`,`pointermove`,`click`]);export{$t as component,Te as universal};