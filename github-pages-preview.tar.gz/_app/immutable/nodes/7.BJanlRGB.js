import{A as e,C as t,F as n,G as r,J as i,K as a,N as o,O as s,S as c,T as l,W as u,X as d,Y as f,Z as p,a as m,at as h,b as g,c as _,d as v,f as y,it as b,j as x,k as S,l as C,lt as w,m as T,nt as E,o as D,ot as O,p as k,q as A,r as j,s as M,st as N,tt as P,u as F,v as I,w as L,y as R,z}from"../chunks/BiXsnc5P.js";import{t as B,u as V}from"../chunks/DprkR4e5.js";import"../chunks/xihTtKlq.js";import"../chunks/LzmQVg0K.js";import{n as ee}from"../chunks/8skaqA67.js";import{n as H,t as U}from"../chunks/C6z9N2Dh.js";import{t as W}from"../chunks/BWQs34pI.js";import{_ as G,a as te,c as ne,d as re,f as ie,g as ae,h as oe,i as K,l as q,m as J,n as se,o as Y,p as ce,r as le,s as X,t as ue,u as Z,v as Q}from"../chunks/Z1DvNj0D.js";import{i as de,n as fe,r as pe}from"../chunks/C8dKXhcC.js";var me=w({load:()=>he}),he=async()=>({readyToRender:!0}),ge=l(`<p class="chapter-title svelte-1e78rkn"> </p>`),_e=l(`<button class="features-button svelte-1e78rkn" type="button" aria-label="Book enhancements">Features</button>`),ve=l(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">View</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reading view"><option>Vertical scroll</option><option>Single page</option><option>Facing pages</option><option>Best fit</option></select></label>`),ye=l(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">Theme</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reader theme"><option>Adaptive</option><option>Light</option><option>Dark</option><option>Sepia</option></select></label>`),be=l(`<div class="header-content controls-mode svelte-1e78rkn"><button class="close-button svelte-1e78rkn" aria-label="Close reader">✕</button> <div class="header-text svelte-1e78rkn"><h1 class="book-title svelte-1e78rkn"> </h1> <!></div> <div class="header-settings svelte-1e78rkn"><!> <!> <!></div> <!></div>`),xe=l(`<div class="header-content passive-mode svelte-1e78rkn"><div class="passive-header-text svelte-1e78rkn"><p class="book-title svelte-1e78rkn"> </p> <!></div></div>`),Se=l(`<header><!></header>`);function Ce(n,r){E(r,!0);let i=m(r,`readerTheme`,3,`adaptive`),o=m(r,`busy`,3,!1),s=m(r,`immersive`,3,!1);var l=Se();let d;var f=u(l),p=n=>{var l=be(),d=u(l),f=a(d,2),p=u(f),m=u(p,!0);h(p);var _=a(p,2),b=e=>{var n=ge(),i=u(n,!0);h(n),z(()=>c(i,r.chapterTitle)),t(e,n)};g(_,e=>{r.chapterTitle&&e(b)}),h(f);var x=a(f,2),S=u(x),C=n=>{var i=_e();e(`click`,i,function(...e){r.onFeatures?.apply(this,e)}),t(n,i)};g(S,e=>{r.onFeatures&&e(C)});var w=a(S,2),T=n=>{var i=ve(),s=a(u(i),2),c=u(s);c.value=c.__value=`scroll`;var l=a(c);l.value=l.__value=`single`;var d=a(l);d.value=d.__value=`spread`;var f=a(d);f.value=f.__value=`best-fit`,h(s);var p;v(s),h(i),z(()=>{s.disabled=o(),p!==(p=r.displayMode)&&(s.value=(s.__value=r.displayMode)??``,y(s,r.displayMode))}),e(`change`,s,e=>{let t=e.currentTarget.value;(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)&&r.onDisplayModeChange?.(t)}),t(n,i)};g(w,e=>{r.displayMode&&r.onDisplayModeChange&&e(T)});var E=a(w,2),D=n=>{var s=ye(),c=a(u(s),2),l=u(c);l.value=l.__value=`adaptive`;var d=a(l);d.value=d.__value=`light`;var f=a(d);f.value=f.__value=`dark`;var p=a(f);p.value=p.__value=`sepia`,h(c);var m;v(c),h(s),z(()=>{c.disabled=o(),m!==(m=i())&&(c.value=(c.__value=i())??``,y(c,i()))}),e(`change`,c,e=>{let t=e.currentTarget.value;(t===`adaptive`||t===`light`||t===`dark`||t===`sepia`)&&r.onReaderThemeChange?.(t)}),t(n,s)};g(E,e=>{r.onReaderThemeChange&&e(D)}),h(x);var O=a(x,2),k=e=>{W(e,{get immersive(){return s()},get disabled(){return o()},get onclick(){return r.onImmersiveChange}})};g(O,e=>{r.onImmersiveChange&&e(k)}),h(l),z(()=>c(m,r.bookTitle)),e(`click`,d,function(...e){r.onClose?.apply(this,e)}),t(n,l)},_=e=>{var n=xe(),i=u(n),o=u(i),s=u(o,!0);h(o);var l=a(o,2),d=e=>{var n=ge(),i=u(n,!0);h(n),z(()=>c(i,r.chapterTitle)),t(e,n)};g(l,e=>{r.chapterTitle&&e(d)}),h(i),h(n),z(()=>c(s,r.bookTitle)),t(e,n)};g(f,e=>{r.controlsVisible?e(p):e(_,-1)}),h(l),z(()=>d=T(l,1,`reading-header svelte-1e78rkn`,null,d,{"controls-visible":r.controlsVisible})),t(n,l),P()}S([`click`,`change`]);var we=l(`<button class="chapter-toggle svelte-1tz9bb9" type="button"><svg aria-hidden="true" viewBox="0 0 20 20"><path d="m7 4 6 6-6 6"></path></svg></button>`),Te=l(`<div><!></div>`),Ee=l(`<li><div class="chapter-row svelte-1tz9bb9"><button><span class="chapter-number svelte-1tz9bb9"> </span> <span class="chapter-label svelte-1tz9bb9"> </span></button> <!></div> <!></li>`),De=l(`<ol class="chapter-entries svelte-1tz9bb9"></ol>`),Oe=l(`<div class="control-group line-height-controls svelte-1tz9bb9"><button class="control-button svelte-1tz9bb9" aria-label="Decrease line height" title="Decrease line height">L−</button> <div class="font-display svelte-1tz9bb9"> </div> <button class="control-button svelte-1tz9bb9" aria-label="Increase line height" title="Increase line height">L+</button></div>`),ke=l(`<div class="footer-content controls-mode svelte-1tz9bb9"><div class="control-group font-controls svelte-1tz9bb9"><button class="control-button svelte-1tz9bb9" aria-label="Decrease font size" title="Decrease font size">A−</button> <div class="font-display svelte-1tz9bb9"> </div> <button class="control-button svelte-1tz9bb9" aria-label="Increase font size" title="Increase font size">A+</button></div> <div class="control-group progress-controls svelte-1tz9bb9"><div class="progress-slider svelte-1tz9bb9"><div class="progress-track svelte-1tz9bb9" aria-hidden="true"><div class="progress-fill svelte-1tz9bb9"></div></div> <div class="progress-thumb svelte-1tz9bb9" aria-hidden="true"><span> </span></div> <input class="progress-range svelte-1tz9bb9" type="range" min="0" max="100" step="1" aria-label="Reading position"/></div></div> <div class="control-group action-controls svelte-1tz9bb9"><button class="control-button menu-button svelte-1tz9bb9" aria-label="Chapter menu" aria-controls="chapter-menu" title="Chapter menu">☰</button></div> <!></div>`),Ae=l(`<div class="footer-content passive-mode svelte-1tz9bb9"><div class="passive-footer-shell svelte-1tz9bb9"><p class="passive-footer-metric svelte-1tz9bb9"> </p></div></div>`),je=l(`<div class="chapter-menu svelte-1tz9bb9" id="chapter-menu"><div class="chapter-menu-header svelte-1tz9bb9"><h2 class="svelte-1tz9bb9">Chapters</h2> <button class="close-menu svelte-1tz9bb9" aria-label="Close menu">✕</button></div> <nav class="chapter-list svelte-1tz9bb9" aria-label="Table of contents"><!></nav></div>`),Me=l(`<footer><!> <!></footer>`);function Ne(n,r){E(r,!0);let s=(n,l=N,f)=>{let m=d(()=>O(f?.(),``));var _=De();I(_,23,l,e=>e.id,(n,l,d)=>{let f=p(()=>r.chapters.findIndex(e=>e.id===o(l).id)),_=p(()=>`${o(m)}${o(d)+1}`);var v=Ee(),x=u(v),w=u(x);let E;var D=u(w),O=u(D,!0);h(D);var k=a(D,2),A=u(k,!0);h(k),h(w);var j=a(w,2),M=n=>{var r=we(),a=u(r);let s;h(r),z((e,t,n)=>{C(r,`aria-label`,e),C(r,`aria-expanded`,t),C(r,`aria-controls`,`chapter-children-${o(f)}`),r.disabled=y(),s=T(a,0,`svelte-1tz9bb9`,null,s,n)},[()=>`${o(S).includes(o(l).id)?`Collapse`:`Expand`} ${o(l).label}`,()=>o(S).includes(o(l).id),()=>({expanded:o(S).includes(o(l).id)})]),e(`click`,r,()=>{i(S,o(S).includes(o(l).id)?o(S).filter(e=>e!==o(l).id):[...o(S),o(l).id],!0)}),t(n,r)};g(j,e=>{o(l).subitems?.length&&e(M)}),h(x);var N=a(x,2),P=e=>{var n=Te();s(u(n),()=>o(l).subitems,()=>`${o(_)}.`),h(n),z(e=>{C(n,`id`,`chapter-children-${o(f)}`),C(n,`hidden`,e)},[()=>!o(S).includes(o(l).id)]),t(e,n)};g(N,e=>{o(l).subitems?.length&&e(P)}),h(v),z(()=>{E=T(w,1,`chapter-item svelte-1tz9bb9`,null,E,{active:o(f)===r.currentChapterIndex}),C(w,`aria-current`,o(f)===r.currentChapterIndex?`location`:void 0),w.disabled=y(),c(O,o(_)),c(A,o(l).label)}),e(`click`,w,()=>{r.onChapterSelect(o(f)),i(b,!1)}),t(n,v)}),h(_),t(n,_)},l=m(r,`lineHeight`,3,1),v=m(r,`chapterPositionLabel`,3,void 0),y=m(r,`busy`,3,!1),b=f(!1),S=f(A([])),w=f(null),D=null,j=p(()=>o(w)??r.progressPercent),M=p(()=>{let e=new Set(r.chapters.flatMap(e=>e.subitems?.map(e=>e.id)??[]));return r.chapters.filter(t=>!e.has(t.id))});function L(e){return e.subitems?.some(e=>e.id===r.chapters[r.currentChapterIndex]?.id||L(e))??!1}function R(){i(b,!o(b)),o(b)&&i(S,[...new Set([...o(S),...r.chapters.filter(L).map(e=>e.id)])],!0)}var B=Me();let V;var ee=u(B),H=n=>{var s=ke(),d=u(s),f=u(d),p=a(f,2),m=u(p);h(p);var S=a(p,2);h(d);var T=a(d,2),E=u(T),O=u(E),A=u(O);h(O);var M=a(O,2),N=u(M),P=u(N);h(N),h(M);var I=a(M,2);_(I),h(E),h(T);var L=a(T,2),B=u(L);h(L);var V=a(L,2),ee=n=>{var i=Oe(),o=u(i),s=a(o,2),d=u(s);h(s);var f=a(s,2);h(i),z(e=>{o.disabled=y()||l()<=1,c(d,`${e??``}x`),f.disabled=y()||l()>=2},[()=>l().toFixed(2)]),e(`click`,o,function(...e){r.onLineHeightDecrease?.apply(this,e)}),e(`click`,f,function(...e){r.onLineHeightIncrease?.apply(this,e)}),t(n,i)};g(V,e=>{r.onLineHeightIncrease&&r.onLineHeightDecrease&&e(ee)}),h(s),z((e,t,n)=>{f.disabled=y()||r.fontSize<=.75,c(m,`${e??``}x`),S.disabled=y()||r.fontSize>=2,C(E,`title`,`${v()??`${r.currentChapterIndex+1} / ${r.totalChapters}`}: ${r.pageLabel}`),k(A,`width: ${o(j)}%`),k(M,`left: calc(${o(j)}% - ${o(j)*.48}px)`),c(P,`${t??``}%`),F(I,o(j)),C(I,`aria-valuetext`,n),I.disabled=y()||!r.onProgressChange,C(B,`aria-expanded`,o(b)),B.disabled=y()},[()=>r.fontSize.toFixed(2),()=>Math.round(o(j)),()=>`${Math.round(o(j))}% of book`]),e(`click`,f,function(...e){r.onFontSizeDecrease?.apply(this,e)}),e(`click`,S,function(...e){r.onFontSizeIncrease?.apply(this,e)}),e(`pointerdown`,I,e=>{D=e.currentTarget.valueAsNumber}),e(`input`,I,e=>{i(w,e.currentTarget.valueAsNumber,!0)}),e(`pointerup`,I,e=>{e.currentTarget.valueAsNumber===D&&i(w,null),D=null}),x(`pointercancel`,I,()=>{i(w,null),D=null}),e(`change`,I,async e=>{let t=e.currentTarget.valueAsNumber;try{await r.onProgressChange?.(t)}finally{i(w,null)}}),e(`click`,B,R),t(n,s)},U=e=>{var n=Ae(),i=u(n),a=u(i),o=u(a,!0);h(a),h(i),h(n),z(()=>c(o,r.progressLabel)),t(e,n)};g(ee,e=>{r.controlsVisible?e(H):e(U,-1)});var W=a(ee,2),G=n=>{var r=je(),c=u(r),l=a(u(c),2);h(c);var d=a(c,2);s(u(d),()=>o(M)),h(d),h(r),e(`click`,l,()=>i(b,!1)),t(n,r)};g(W,e=>{o(b)&&e(G)}),h(B),z(()=>V=T(B,1,`reading-footer svelte-1tz9bb9`,null,V,{"controls-visible":r.controlsVisible,"has-line-height-controls":!!r.onLineHeightIncrease&&!!r.onLineHeightDecrease})),t(n,B),P()}S([`click`,`pointerdown`,`input`,`pointerup`,`change`]);var Pe=l(`<p class="chapter-title svelte-v52sy3"> </p>`),Fe=l(`<p>Find the Greek words in any of eight directions, including backward. Grid letters omit accents and breathing marks.</p>`),Ie=l(`<p>Use the English clues to fill in the Greek words. Accents and breathing marks are not required.</p>`),Le=l(`<p>Write the English meaning and its letter beside each Greek word.</p>`),Re=l(`<td class="svelte-v52sy3"><span class="svelte-v52sy3"> </span></td>`),ze=l(`<tr></tr>`),Be=l(`<li class="svelte-v52sy3"> </li>`),Ve=l(`<div class="word-search-layout svelte-v52sy3"><table class="word-search-grid svelte-v52sy3" lang="el" aria-label="Greek word search"><tbody></tbody></table> <section class="word-search-vocabulary svelte-v52sy3"><h2 class="svelte-v52sy3">Words to find</h2> <ul class="word-search-words svelte-v52sy3" lang="el"></ul></section></div>`),He=l(`<li class="svelte-v52sy3"><strong> </strong> </li>`),Ue=l(`<section><h2 class="svelte-v52sy3"> </h2> <ul class="svelte-v52sy3"></ul></section>`),We=l(`<span class="svelte-v52sy3"> </span>`),Ge=l(`<td class="crossword-cell svelte-v52sy3"></td>`),Ke=l(`<td class="crossword-empty svelte-v52sy3"></td>`),qe=l(`<div class="crossword-layout svelte-v52sy3"><div class="crossword-clues svelte-v52sy3"></div> <table class="crossword-grid svelte-v52sy3" aria-label="Blank Greek crossword"><tbody></tbody></table></div>`),Je=l(`<li class="prompt-row svelte-v52sy3"><span class="greek-word svelte-v52sy3"> </span><span class="meaning-blank svelte-v52sy3"></span><span class="letter-box svelte-v52sy3"></span><span class="result-space"></span></li>`),Ye=l(`<li class="choice-row svelte-v52sy3"><span class="choice-letter svelte-v52sy3"> </span><span> </span></li>`),Xe=l(`<div class="matching-columns svelte-v52sy3"><section><h2 class="svelte-v52sy3">Greek words</h2><ul class="svelte-v52sy3"></ul></section> <section><h2 class="svelte-v52sy3">English meanings</h2><ul class="svelte-v52sy3"></ul></section></div>`),Ze=l(`<section class="worksheet-print svelte-v52sy3" aria-label="Printable worksheet"><!> <h1 class="svelte-v52sy3"> </h1> <!> <p>Name: ________________________ Date: ______________</p> <!></section>`);function Qe(e,n){E(n,!0);var i=Ze(),s=u(i),l=e=>{var r=Pe(),i=u(r,!0);h(r),z(()=>c(i,n.activity.chapterTitle)),t(e,r)};g(s,e=>{n.activity.chapterTitle&&e(l)});var d=a(s,2),f=u(d,!0);h(d);var p=a(d,2),m=e=>{t(e,Fe())},_=e=>{t(e,Ie())},v=e=>{t(e,Le())};g(p,e=>{n.activity.kind===`word-search-v1`?e(m):n.activity.kind===`crossword-v1`?e(_,1):e(v,-1)});var y=a(p,4),x=e=>{var r=Ve(),i=u(r),s=u(i);I(s,21,()=>n.activity.grid,R,(e,n)=>{var r=ze();I(r,21,()=>[...o(n)],R,(e,n)=>{var r=Re(),i=u(r),a=u(i,!0);h(i),h(r),z(()=>c(a,o(n))),t(e,r)}),h(r),t(e,r)}),h(s),h(i);var l=a(i,2),d=a(u(l),2);I(d,21,()=>n.activity.words,e=>e.id,(e,n)=>{var r=Be(),i=u(r,!0);h(r),z(()=>c(i,o(n).text)),t(e,r)}),h(d),h(l),h(r),t(e,r)},S=e=>{var i=qe(),s=u(i);I(s,20,()=>[`across`,`down`],R,(e,r)=>{var i=Ue(),s=u(i),l=u(s,!0);h(s);var d=a(s,2);I(d,21,()=>n.activity.clues.filter(e=>e.direction===r),e=>e.id,(e,n)=>{var r=He(),i=u(r),s=u(i);h(i);var l=a(i);h(r),z(()=>{c(s,`${o(n).number??``}.`),c(l,` ${o(n).text??``}`)}),t(e,r)}),h(d),h(i),z(()=>c(l,r===`across`?`Across`:`Down`)),t(e,i)}),h(s);var l=a(s,2),d=u(l);I(d,21,()=>n.activity.cells,R,(e,i,a)=>{var s=ze();I(s,21,()=>o(i),R,(e,i,s)=>{var l=L(),d=r(l),f=e=>{var r=Ge();I(r,21,()=>n.activity.clues.filter(e=>e.row===a&&e.column===s).slice(0,1),R,(e,n)=>{var r=We(),i=u(r,!0);h(r),z(()=>c(i,o(n).number)),t(e,r)}),h(r),t(e,r)},p=e=>{t(e,Ke())};g(d,e=>{o(i)?e(f):e(p,-1)}),t(e,l)}),h(s),t(e,s)}),h(d),h(l),h(i),z(()=>C(l,`lang`,n.activity.language)),t(e,i)},w=e=>{var r=Xe(),i=u(r),s=a(u(i));I(s,21,()=>n.activity.prompts,e=>e.id,(e,n)=>{var r=Je(),i=u(r),a=u(i,!0);h(i),b(3),h(r),z(()=>{C(i,`lang`,o(n).language),c(a,o(n).text)}),t(e,r)}),h(s),h(i);var l=a(i,2),d=a(u(l));I(d,23,()=>n.activity.choices,e=>e.id,(e,n,r)=>{var i=Ye(),s=u(i),l=u(s,!0);h(s);var d=a(s),f=u(d,!0);h(d),h(i),z(e=>{c(l,e),C(d,`lang`,o(n).language),c(f,o(n).text)},[()=>oe(o(r))]),t(e,i)}),h(d),h(l),h(r),t(e,r)};g(y,e=>{n.activity.kind===`word-search-v1`?e(x):n.activity.kind===`crossword-v1`?e(S,1):e(w,-1)}),h(i),z(()=>c(f,n.activity.title)),t(e,i),P()}var $e=l(`<li class="svelte-5ift61"><strong> </strong>: <!></li>`),et=l(`<p role="alert" class="svelte-5ift61"> </p>`),tt=l(`<button type="button" class="svelte-5ift61">Close without saving</button>`),nt=l(`<dialog class="reader-feature-notice svelte-5ift61" aria-labelledby="reader-feature-title" aria-describedby="reader-feature-message"><h2 id="reader-feature-title" class="svelte-5ift61"> </h2> <p id="reader-feature-message" class="svelte-5ift61"> </p> <a target="_blank" rel="noopener noreferrer" class="svelte-5ift61">Visit Study Cheetah (opens in a new tab)</a> <h3 class="svelte-5ift61">Features requested by this book</h3> <ul class="svelte-5ift61"></ul> <p class="svelte-5ift61">Active means the reader's enhancement is enabled. Each activity is validated when opened.</p> <p class="svelte-5ift61">Unavailable enhancements keep their ordinary book content. This link opens the reader website; it does not upload your book.</p> <label class="svelte-5ift61"><input type="checkbox" class="svelte-5ift61"/> Don't show this again for this book's current features</label> <!> <div class="actions svelte-5ift61"><!> <button type="button" class="svelte-5ift61">Continue reading</button></div></dialog>`);function rt(n,r){E(r,!0);let l,d=f(!1),m=f(null),v=le.getInstance();function y(e){console.error(`[Reader] Saving or loading enhancement notice preference failed:`,e),i(m,`Could not remember your notice preference: ${e instanceof Error?e.message:String(e)}`)}function x(){try{v.setReaderNoticeDismissed(r.capability,o(d)),i(m,null),l.close()}catch(e){y(e)}}j(()=>{try{i(d,v.isReaderNoticeDismissed(r.capability),!0)}catch(e){y(e)}r.onready(()=>{l.open||l.showModal()}),(o(m)||!o(d)&&r.capability.requested.some(e=>!r.capability.active.includes(e)))&&l.showModal()});var S=nt(),w=u(S),T=u(w,!0);h(w);var O=a(w,2),k=u(O,!0);h(O);var A=a(O,2),N=a(A,4);I(N,20,()=>r.capability.requested,e=>e,(e,n)=>{var i=$e(),l=u(i),d=u(l,!0);h(l);var f=a(l,2),m=e=>{t(e,s(`Active`))},_=p(()=>r.capability.active.includes(n)),v=e=>{t(e,s(`Supported, not active`))},y=p(()=>r.capability.supported.includes(n)),b=e=>{t(e,s(`Not supported by this reader yet`))};g(f,e=>{o(_)?e(m):o(y)?e(v,1):e(b,-1)}),h(i),z(()=>c(d,n)),t(e,i)}),h(N);var F=a(N,6),L=u(F);_(L),b(),h(F);var R=a(F,2),B=e=>{var n=et(),r=u(n,!0);h(n),z(()=>c(r,o(m))),t(e,n)};g(R,e=>{o(m)&&e(B)});var V=a(R,2),ee=u(V),H=n=>{var r=tt();e(`click`,r,()=>l.close()),t(n,r)};g(ee,e=>{o(m)&&e(H)});var U=a(ee,2);h(V),h(S),D(S,e=>l=e,()=>l),z(()=>{c(T,r.capability.notice.title),c(k,r.capability.notice.message),C(A,`href`,r.capability.notice.url)}),M(L,()=>o(d),e=>i(d,e)),e(`click`,U,x),t(n,S),P()}S([`click`]);var it=`body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
  padding-block: 0.5rem;\r
}\r
[data-study-cheetah-enhanced="matching-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-height: 0;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced] > h1 { text-align: center; }\r
body > [data-study-cheetah-enhanced="matching-v1"] > h1 { margin-block-start: 0; }\r
[data-study-cheetah-enhanced="matching-v1"] [data-study-cheetah-matching-instructions] { display: none; }\r
[data-study-cheetah-enhanced] .matching-columns {\r
  display: grid;\r
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);\r
  gap: clamp(0.75em, 3vw, 2em);\r
  flex: 1 1 auto;\r
  min-height: 6em;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section {\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section > h2 { text-decoration: underline; }\r
[data-study-cheetah-enhanced] [data-matching-prompts],\r
[data-study-cheetah-enhanced] [data-matching-choices] {\r
  display: grid;\r
  reading-flow: grid-order;\r
  align-content: start;\r
  gap: 0.4em;\r
  min-height: 0;\r
  padding: 4px;\r
  margin: 0;\r
  list-style: none;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced] li {\r
  box-sizing: border-box;\r
  position: relative;\r
  min-height: 44px;\r
  padding: 0.35em;\r
  overflow-wrap: anywhere;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 1.8em 1em;\r
  align-items: center;\r
  gap: 0.4em;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li::before {\r
  content: none;\r
}\r
[data-study-cheetah-enhanced] .answer-blank {\r
  box-sizing: border-box;\r
  min-width: 1.6em;\r
  max-width: 3em;\r
  min-height: 1.6em;\r
  padding: 0 0.15em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  text-align: center;\r
  font-weight: bold;\r
  line-height: 1.5;\r
  background: var(--ui-control-bg, transparent);\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li {\r
  display: grid;\r
  grid-template-columns: 2em minmax(0, 1fr);\r
  align-items: center;\r
  column-gap: 2ch;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li::before {\r
  content: attr(data-choice-label);\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
  font-weight: bold;\r
  text-align: center;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] .answer-blank { display: none; }\r
[data-study-cheetah-enhanced] .answer-blank {\r
  white-space: normal;\r
  color: var(--reader-control-greek, var(--reader-matching-greek, var(--coloroldgreek, #0070c0)));\r
}\r
[data-study-cheetah-enhanced] .sc-match-answer { grid-column: 2; grid-row: 1; margin-inline-end: calc(2ch - 0.4em); }\r
[data-study-cheetah-enhanced] [data-matching-prompts] .answer-blank { grid-column: 3; grid-row: 1; }\r
[data-study-cheetah-enhanced] .sc-match-result { grid-column: 4; grid-row: 1; width: 1em; height: 1em; }\r
[data-study-cheetah-enhanced] .sc-match-result svg {\r
  width: 100%;\r
  height: 100%;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 3.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] [data-result="correct"] { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] [data-result="incorrect"] { color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced] .sc-match-answer { text-align: right; min-width: 0; border-bottom: 0; color: var(--reader-page-fg, inherit); }\r
[data-study-cheetah-enhanced] .sc-match-select {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  min-height: 0;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  color: var(--reader-page-fg, inherit);\r
  background: transparent;\r
}\r
[data-study-cheetah-enhanced] .sc-match-select[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); }\r
[data-study-cheetah-enhanced] ol:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] .sc-match-footer { flex: 0 0 auto; margin-top: 0.75em; font-size: 0.8em; }\r
[data-study-cheetah-enhanced] .sc-match-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer p { margin: 0; }\r
[data-study-cheetah-enhanced] .sc-match-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(6em, 1fr) minmax(0, max-content);\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced] .sc-match-status { min-width: 0; }\r
[data-study-cheetah-enhanced] .sc-match-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-match-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
[data-study-cheetah-enhanced] .sc-match-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
@media (orientation: landscape) {\r
  body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
    padding-inline-end: 48px;\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] {\r
    --sc-match-sidebar-width: clamp(7rem, 15vw, 10rem);\r
    position: relative;\r
    padding-inline-end: calc(var(--sc-match-sidebar-width) + 1rem);\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] > h1 {\r
    margin-inline-end: calc(-1 * (var(--sc-match-sidebar-width) + 1rem));\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer {\r
    position: absolute;\r
    inset-block-end: 0;\r
    inset-inline-end: 0;\r
    width: var(--sc-match-sidebar-width);\r
    max-height: 100%;\r
    margin-top: 0;\r
    overflow-y: auto;\r
    overflow-wrap: anywhere;\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer-row {\r
    grid-template-columns: minmax(0, 1fr);\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-controls {\r
    flex-direction: column;\r
    flex-wrap: nowrap;\r
  }\r
}\r
`,at=`[data-study-cheetah-enhanced] .worksheet-name { display: none; }\r
[data-study-cheetah-enhanced] .sc-activity-button {\r
  box-sizing: border-box;\r
  min-height: 44px;\r
  padding: 0.3em 0.6em;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  font: inherit;\r
  font-weight: bold;\r
  color: inherit;\r
  background: var(--ui-control-bg, transparent);\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-check, .sc-crossword-check) {\r
  color: var(--reader-control-check, var(--reader-matching-correct, #166534));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-reset, .sc-word-search-reset, .sc-crossword-reset) {\r
  color: var(--reader-control-reset, var(--reader-matching-reset, #a84300));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-print, .sc-word-search-print, .sc-crossword-print) {\r
  color: var(--reader-control-print, #000);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:hover:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-hover, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:active:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-active, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:disabled { cursor: default; }\r
[data-study-cheetah-enhanced] .sc-activity-button:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 0.5em;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) svg {\r
  flex: 0 0 auto;\r
  width: 1.2em;\r
  height: 1.2em;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
@media print {\r
  .study-cheetah-activity-ui { display: none !important; }\r
}\r
`;function ot(e,t,n){let r=e.ownerDocument;e.setAttribute(`aria-label`,e.textContent),e.textContent=``;let i=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);i.setAttribute(`viewBox`,`0 0 24 24`),i.setAttribute(`aria-hidden`,`true`),i.setAttribute(`focusable`,`false`);let a=r.createElementNS(i.namespaceURI,`path`);a.setAttribute(`d`,n),i.append(a);let o=r.createElement(`span`);o.textContent=t,e.append(i,o)}function st(e,t){let n=e.ownerDocument,r=[];function i(e,t,n){let i=e.getAttribute(t);e.setAttribute(t,n),r.push(()=>{i===null?e.removeAttribute(t):e.setAttribute(t,i)})}function a(e,t,i){let a=n.createElement(t);return a.className=`study-cheetah-activity-ui ${i}`,e.append(a),r.push(()=>a.remove()),a}function o(e,t,n){let i=a(e,`button`,`sc-activity-button`);return i.type=`button`,i.textContent=t,i.addEventListener(`click`,n),r.push(()=>i.removeEventListener(`click`,n)),i}let s=n.createElement(`style`);return s.textContent=`${at}\n${t}`,n.head.append(s),r.push(()=>s.remove()),{doc:n,cleanups:r,attribute:i,append:a,button:o}}function ct(e,t,n){let{doc:r,cleanups:i,attribute:a,append:o,button:s}=st(e,it),c=le.getInstance(),l=[...e.querySelectorAll(`[data-matching-prompts] > li`)],u=[...e.querySelectorAll(`[data-matching-choices] > li`)],d=[...e.querySelectorAll(`[data-matching-prompts], [data-matching-choices]`)],f={},p=null,m=!1,h=0,g=!1,_=null,v=``,y={promptIds:t.prompts.map(e=>e.id),choiceIds:t.choices.map(e=>e.id)};function b(e,t,n){let r=e.querySelector(t)??o(e,`span`,n);a(r,`class`,`${r.className} ${n}`),a(r,`aria-hidden`,`true`);let s=r.textContent;return i.push(()=>{r.textContent=s}),r}try{let e=c.getMatchingProgress(n.publicationId,t);e&&(f=e.answers,m=e.submitted,h=e.attempts),y=Object.keys(f).length>0?e?.order??y:n.order??Q(t)}catch(e){g=!0,P(e)}n.onorder?.(y);function x(e){return oe(y.choiceIds.indexOf(e))}a(e,`data-study-cheetah-enhanced`,`matching-v1`);for(let t of e.querySelectorAll(`:scope > p`))t.textContent?.trim()===`Match the Greek word with the correct English translation. Write the English meaning and its letter beside each Greek word.`&&a(t,`data-study-cheetah-matching-instructions`,``);for(let[e,t]of d.entries())a(t,`tabindex`,`0`),a(t,`aria-label`,e===0?`Greek words list`:`English meanings list`);let S=l.map((e,n)=>{let r=t.prompts[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.promptIds.indexOf(r.id)};`);let i=b(e,`.matching-answer`,`sc-match-answer`),o=b(e,`.answer-blank`,`answer-blank`),c=b(e,`.matching-result`,`sc-match-result`),l=s(e,``,()=>{p=r.id,v=`Choose an English meaning for ${r.id}.`,I()});return l.classList.add(`sc-match-select`),l.setAttribute(`aria-label`,`Greek ${r.id}: ${r.text}`),{answer:i,blank:o,result:c,control:l}}),C=u.map((e,n)=>{let r=t.choices[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.choiceIds.indexOf(r.id)};`),a(e,`data-choice-label`,x(r.id));let i=s(e,``,()=>{!p||g||(f=J(t,f,p,r.id),v=`Matched ${p} with ${r.text}.`,p=null,m=!1,F(),I())});return i.classList.add(`sc-match-select`),i.setAttribute(`aria-label`,`English: ${r.text}`),{control:i}}),w=o(e,`div`,`sc-match-footer`),T=o(w,`p`,`sc-match-error`);T.setAttribute(`role`,`alert`);let E=o(w,`div`,`sc-match-footer-row`),D=o(E,`p`,`sc-match-status`);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=o(D,`span`,``),k=o(D,`span`,`sc-match-announcement`),A=o(E,`div`,`sc-match-controls`),j=s(A,`Check answers`,()=>{m=!0,h+=1,v=``,F(),I()});j.classList.add(`sc-match-check`);let M=s(A,`Reset answers`,()=>{try{c.deleteMatchingProgress(n.publicationId,t),f={},p=null,m=!1,g=!1,v=`Answers cleared.`,F()}catch(e){P(e)}I()});M.classList.add(`sc-match-reset`);let N=s(A,`Print worksheet`,n.onprint);N.classList.add(`sc-match-print`);for(let[e,t,n]of[[j,`Check`,`M5 12l4 4L19 6`],[M,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[N,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])ot(e,t,n);function P(e){console.error(`[Reader] Matching exercise progress:`,e),_=`Could not load or save exercise progress. ${e instanceof Error?e.message:String(e)}`}function F(){try{c.saveMatchingProgress(n.publicationId,t,{revision:t.revision,answers:f,submitted:m,attempts:h,updated:Date.now(),order:y}),_=null}catch(e){P(e)}}function I(){let e=Object.keys(f).length,n=G(t,f);O.textContent=`${m?`${n} of ${t.prompts.length} correct.${n===t.prompts.length?` Exercise complete.`:``}`:`${e} of ${t.prompts.length} matched.`} Checks: ${h}.`,k.textContent=` ${v}`,T.hidden=_===null,T.textContent=_,j.disabled=g||e===0;for(let[e,{control:n,answer:i,blank:a,result:o}]of S.entries()){let s=t.prompts[e],c=t.choices.findIndex(e=>e.id===f[s.id]),l=t.choices[c],u=m&&!!l,d=l?.answerId===s.id;if(i.textContent=l?.text??``,a.textContent=l?x(l.id):``,l?.language?i.lang=l.language:i.removeAttribute(`lang`),n.disabled=g,n.setAttribute(`aria-pressed`,String(p===s.id)),n.setAttribute(`aria-description`,`${l?`Matches ${l.text}`:`Not matched`}${u?d?` Correct`:` Incorrect`:``}`),o.replaceChildren(),u){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.setAttribute(`viewBox`,`0 0 20 20`),e.setAttribute(`data-result`,d?`correct`:`incorrect`);let t=r.createElementNS(e.namespaceURI,`path`);t.setAttribute(`d`,d?`M3 10l4 4L17 4`:`M4 4l12 12M16 4L4 16`),e.append(t),o.append(e)}}for(let[e,{control:n}]of C.entries()){let r=t.choices[e],i=Object.entries(f).find(([,e])=>e===r.id)?.[0];n.disabled=g||!p,n.setAttribute(`aria-description`,`Choice ${x(r.id)}. ${i?`Used by ${i}`:`Not used`}`)}}return I(),()=>{for(let e of i.reverse())e()}}var lt=`body:has(> [data-study-cheetah-enhanced="word-search-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
  color: inherit;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-study-cheetah-word-search-instructions] { display: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="word-search-v1"] > [data-word-search-layout] { flex-grow: 1; align-content: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr);\r
  gap: 0.6em 1em;\r
  align-items: start;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) {\r
  grid-template-columns: minmax(0, var(--sc-word-search-board-space, 1fr)) minmax(0, 1fr);\r
  column-gap: 10em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit][data-word-search-measure="side"] {\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] > .word-search-board {\r
  box-sizing: border-box;\r
  min-width: 0;\r
  padding: 1em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] .word-search-vocabulary {\r
  justify-self: start;\r
  width: max-content;\r
  max-width: 100%;\r
  min-width: 0;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-words], [data-word-search-words] > li) {\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-words] {\r
  font-size: 1.25em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  grid-template-columns: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) .word-search-vocabulary {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr);\r
  max-height: var(--sc-word-search-height);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  min-height: 0;\r
  padding-block: 0.15em;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .word-search-vocabulary h2 {\r
  display: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] [data-word-search-grid] {\r
  width: var(--sc-word-search-width, 100%);\r
  min-width: 0;\r
  max-width: none;\r
  margin-inline: auto;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] td > span {\r
  block-size: var(--sc-word-search-cell, auto);\r
  font-size: max(1em, var(--sc-word-search-letter, 1em));\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-cell {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  background: transparent;\r
  color: var(--reader-page-fg, inherit);\r
  cursor: pointer;\r
  touch-action: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-grid] { user-select: none; touch-action: none; }\r
.sc-word-search-cell.sc-word-search-selected { border-color: currentColor; }\r
.sc-word-search-cell.sc-word-search-found { background: color-mix(in srgb, var(--reader-matching-correct, #166534) 20%, transparent); }\r
.sc-word-search-cell:focus-visible { outline: 2px solid currentColor; outline-offset: -3px; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-touch-preview {\r
  position: fixed;\r
  inset: auto;\r
  box-sizing: border-box;\r
  width: max-content;\r
  max-width: calc(100vw - 1rem);\r
  margin: 0;\r
  padding: 0.3em 0.75em;\r
  border: 2px solid currentColor;\r
  border-radius: 9999px;\r
  background: var(--reader-page-bg, Canvas);\r
  color: var(--reader-page-fg, CanvasText);\r
  font-size: max(1.25em, var(--sc-word-search-letter, 1em));\r
  line-height: 1.4;\r
  letter-spacing: 0.1em;\r
  text-align: center;\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-found-word {\r
  color: var(--reader-matching-correct, #166534);\r
  font-weight: bold;\r
  text-decoration: line-through;\r
}\r
.sc-word-search-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-word-search-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer p { margin: 0; }\r
.sc-word-search-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-word-search-status { min-width: 0; text-align: left; }\r
.sc-word-search-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-word-search-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
.sc-word-search-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
@media (orientation: landscape) {\r
  body > [data-study-cheetah-enhanced="word-search-v1"] {\r
    --sc-word-search-sidebar-width: clamp(7rem, 15vw, 10rem);\r
    position: relative;\r
    padding-inline-end: calc(var(--sc-word-search-sidebar-width) + 1rem);\r
  }\r
  body > [data-study-cheetah-enhanced="word-search-v1"] > h1 {\r
    margin-inline-end: calc(-1 * (var(--sc-word-search-sidebar-width) + 1rem));\r
  }\r
  body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer {\r
    position: absolute;\r
    inset-block-end: 0;\r
    inset-inline-end: 0;\r
    width: var(--sc-word-search-sidebar-width);\r
    max-height: 100%;\r
    margin-top: 0;\r
    overflow-y: auto;\r
    overflow-wrap: anywhere;\r
  }\r
  body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer-row {\r
    grid-template-columns: minmax(0, 1fr);\r
  }\r
  body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-controls {\r
    flex-direction: column;\r
    flex-wrap: nowrap;\r
  }\r
}\r
`;function ut(e,t,n){let r=e.querySelector(`[data-word-search-grid]`),i=[...e.querySelectorAll(`[data-word-search-grid] td`)];if(!r||i.length!==t.grid.length*t.grid[0].length)throw Error(`The word-search grid does not match its worksheet.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l}=st(e,lt),u=le.getInstance(),d=t.grid[0].length,f=t.grid.join(``),p=[],m=null,h=null,g=null,_=null,v=!1,y,b=!1,x=0,S=!1,C=null,w=``;function T(e){console.error(`[Reader] Word-search progress:`,e),C=`Could not load or save puzzle progress. ${e instanceof Error?e.message:String(e)}`}try{p=u.getWordSearchProgress(n.publicationId,t)?.found??[]}catch(e){S=!0,T(e)}s(e,`data-study-cheetah-enhanced`,`word-search-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Find the Greek words in any of eight directions, including backward. Grid letters are lowercase without accents or breathing marks.`,`Find words in all eight directions. Lowercase grid letters omit accents.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-word-search-instructions`,``);s(r,`role`,`grid`),s(r,`aria-rowcount`,String(t.grid.length)),s(r,`aria-colcount`,String(d)),s(r,`aria-description`,`Drag from the first letter to the last, or tap both ends. Keyboard: use arrow keys, Enter or Space to select each end, and Escape to cancel.`);let E=i.map((e,t)=>{s(e,`role`,`gridcell`);let n=e.querySelector(`span`);n&&s(n,`aria-hidden`,`true`);let r=c(e,`button`,`sc-word-search-cell`);return r.type=`button`,r.dataset.cellIndex=String(t),r.setAttribute(`aria-label`,`Row ${Math.floor(t/d)+1}, column ${t%d+1}: ${f[t]}`),r}),D=c(e,`div`,`sc-word-search-touch-preview`);D.popover=`manual`,D.lang=`el`,D.setAttribute(`aria-hidden`,`true`),D.hidden=!0;let O=c(e,`div`,`sc-word-search-footer`),k=c(O,`div`,`sc-word-search-footer-row`),A=c(k,`p`,`sc-word-search-status`);A.setAttribute(`role`,`status`),A.setAttribute(`aria-live`,`polite`);let j=c(A,`span`,``),M=c(A,`span`,`sc-word-search-announcement`),N=c(O,`p`,`sc-word-search-error`);N.setAttribute(`role`,`alert`);let P=c(k,`div`,`sc-word-search-controls`),F=l(P,`Reset puzzle`,()=>{H();try{u.deleteWordSearchProgress(n.publicationId,t),p=[],m=null,S=!1,w=`Found words cleared.`,z()}catch(e){T(e)}q()});F.classList.add(`sc-word-search-reset`);let I=l(P,`Print worksheet`,n.onprint);I.classList.add(`sc-word-search-print`),ot(F,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`),ot(I,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`);let L=c(O,`p`,``),R=[...e.querySelectorAll(`[data-word-search-words] > li`)];for(let e of R)s(e,`class`,e.className);function z(){try{u.saveWordSearchProgress(n.publicationId,t,{revision:t.revision,puzzle:ce(t),found:p,updated:Date.now()}),C=null}catch(e){T(e)}}function B(e,n){let r=Z(t,e,n);r?p.some(e=>e.wordId===r.id)?w=`${r.text} is already found.`:(p=[...p,{wordId:r.id,start:e,end:n}],w=`Found ${r.text}.`,z()):w=`No listed word selected. Choose a straight row, column, or diagonal.`,m=null}function V(e){S||(x=e,m===null?(m=e,w=`First letter selected. Choose the last letter.`):B(m,e),q())}function ee(){return h!==null&&g!==null?ie(t,b?h:m??h,g)??[]:m===null?[]:[m]}function H(){clearTimeout(y),y=void 0,D.matches(`:popover-open`)&&D.hidePopover(),D.hidden=!0,D.textContent=``}function U(){if(D.hidden)return;let e=r.getBoundingClientRect(),t=D.getBoundingClientRect(),n=Math.max(8,Math.min(e.left+e.width/2-t.width/2,a.documentElement.clientWidth-t.width-8));D.style.left=`${n}px`,D.style.top=`${Math.max(8,e.top-t.height-8)}px`}function W(){let e=ee();if(!e.length){H();return}D.textContent=e.map(e=>f[e]).join(``),D.hidden=!1,D.matches(`:popover-open`)||D.showPopover(),U()}function G(e){let t=a.elementFromPoint(e.clientX,e.clientY)?.closest(`.sc-word-search-cell`);return t&&r.contains(t)?Number(t.dataset.cellIndex):null}let te=e=>{if(S||e.button!==0||_!==null)return;let t=G(e);t!==null&&(e.preventDefault(),H(),v=e.pointerType===`touch`,h=g=t,_=e.pointerId,b=!1,x=t,E[t].focus({preventScroll:!0}),r.setPointerCapture(e.pointerId),q())},ne=e=>{if(e.pointerId!==_||h===null)return;let t=G(e);t!==g&&(g=t,g!==null&&g!==h&&(b=!0),q())},re=e=>{if(e.pointerId!==_||h===null)return;let t=G(e);g=t;let n=v;n&&W(),v=!1,t===null?(m=null,w=`Selection cancelled.`):b?B(h,t):V(t),_=h=g=null,q(),n&&!D.hidden&&(y=setTimeout(H,1e3))},ae=e=>{e&&e.pointerId!==_||(v=!1,H(),_=h=g=m=null,q())},oe=e=>{let t=e.target.closest(`.sc-word-search-cell`);e.detail===0&&t&&(H(),V(Number(t.dataset.cellIndex)))},K=e=>{let t=e.target.closest(`.sc-word-search-cell`);if(!t||e.altKey||e.ctrlKey||e.metaKey)return;let n=Number(t.dataset.cellIndex),r=n;if(e.key===`ArrowLeft`)r=n%d?n-1:n;else if(e.key===`ArrowRight`)r=n%d<d-1?n+1:n;else if(e.key===`ArrowUp`)r=Math.max(n-d,n%d);else if(e.key===`ArrowDown`)r=Math.min(n+d,i.length-d+n%d);else if(e.key===`Enter`||e.key===` `)V(n);else if(e.key===`Escape`)ae(),w=`Selection cancelled.`;else return;e.preventDefault(),x=r,q(),E[r].focus()};r.addEventListener(`pointerdown`,te),r.addEventListener(`pointermove`,ne),r.addEventListener(`pointerup`,re),r.addEventListener(`pointercancel`,ae),r.addEventListener(`lostpointercapture`,ae),r.addEventListener(`click`,oe),r.addEventListener(`keydown`,K),a.addEventListener(`scroll`,U,!0),a.defaultView?.addEventListener(`resize`,U),o.push(()=>{H(),r.removeEventListener(`pointerdown`,te),r.removeEventListener(`pointermove`,ne),r.removeEventListener(`pointerup`,re),r.removeEventListener(`pointercancel`,ae),r.removeEventListener(`lostpointercapture`,ae),r.removeEventListener(`click`,oe),r.removeEventListener(`keydown`,K),a.removeEventListener(`scroll`,U,!0),a.defaultView?.removeEventListener(`resize`,U)});function q(){let e=new Set(p.flatMap(e=>ie(t,e.start,e.end)??[])),n=new Set(ee());v&&W();for(let[t,r]of E.entries())r.tabIndex=t===x?0:-1,r.disabled=S,r.classList.toggle(`sc-word-search-found`,e.has(t)),r.classList.toggle(`sc-word-search-selected`,n.has(t)),r.setAttribute(`aria-pressed`,String(n.has(t))),r.setAttribute(`aria-description`,e.has(t)?`Part of a found word`:`Not found`);for(let e of R)e.classList.toggle(`sc-word-search-found-word`,p.some(t=>t.wordId===e.dataset.wordId));j.textContent=`${p.length} of ${t.words.length} words found.${p.length===t.words.length?` Puzzle complete.`:``}`,M.textContent=w?` ${w}`:``,N.hidden=C===null,N.textContent=C,L.hidden=C===null,L.textContent=C?`Progress is not saved.`:``}q();let J=e.querySelector(`:scope > [data-word-search-layout]`),se=J?.querySelector(`.word-search-vocabulary`);return J&&se&&o.push(dt(e,J,r,se,d,t.grid.length)),()=>{for(let e of o.reverse())e()}}function dt(e,t,n,r,i,a){let o=Array.from(e.children).filter(e=>e!==t),s=e=>Number.parseFloat(e)||0,c=r.querySelector(`[data-word-search-words]`),l=c.getAttribute(`tabindex`);t.dataset.wordSearchFit=`stack`;function u(){l===null?c.removeAttribute(`tabindex`):c.setAttribute(`tabindex`,l)}function d(){if(!e.clientHeight||!e.clientWidth)return;let l=getComputedStyle(e),d=o.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),f=e.clientHeight-s(l.paddingTop)-s(l.paddingBottom)-s(l.rowGap)*d.length;for(let e of d){let t=getComputedStyle(e);f-=e.getBoundingClientRect().height+s(t.marginTop)+s(t.marginBottom)}t.dataset.wordSearchMeasure=`stack`;let p=getComputedStyle(t),m=t.clientWidth,h=getComputedStyle(n.parentElement),g=s(h.paddingLeft)+s(h.paddingRight),_=s(h.paddingTop)+s(h.paddingBottom),v=f-_,y=Math.ceil(s(getComputedStyle(n).fontSize)*i),b=Math.max(y,Math.min(m-g,(v-r.offsetHeight-s(p.rowGap))*i/a));t.dataset.wordSearchMeasure=`side`;let x=s(getComputedStyle(t).columnGap),S=r.offsetWidth,C=Math.max(y,v*i/a)+g,w=m-x,T=Math.min(w-S,w*C/(C+S)),E=T-g,D=Math.max(y,Math.min(E,v*i/a));delete t.dataset.wordSearchMeasure;let O=t.dataset.wordSearchFit===`side`,k=e.clientWidth>=e.clientHeight+(O?-4:4),A=E>=y+(O?0:4)&&(D>b+4||D>=b-(O?4:0)&&k||O&&D>b),j=Math.floor(A?D:b);A!==O&&(t.dataset.wordSearchFit=A?`side`:`stack`),t.style.setProperty(`--sc-word-search-width`,`${j}px`),t.style.setProperty(`--sc-word-search-cell`,`${j/i}px`),t.style.setProperty(`--sc-word-search-letter`,`${j/i*.58}px`),t.style.setProperty(`--sc-word-search-height`,`${j*a/i}px`),t.style.setProperty(`--sc-word-search-board-space`,`${Math.max(0,T)}px`),A&&c.scrollHeight>c.clientHeight?c.tabIndex=0:u()}let f=new ResizeObserver(d);f.observe(e),f.observe(r);for(let e of o)f.observe(e);return d(),()=>{f.disconnect(),delete t.dataset.wordSearchFit,t.style.removeProperty(`--sc-word-search-width`),t.style.removeProperty(`--sc-word-search-cell`),t.style.removeProperty(`--sc-word-search-letter`),t.style.removeProperty(`--sc-word-search-height`),t.style.removeProperty(`--sc-word-search-board-space`),u()}}function ft(e,t,n,r){let i=e.contentDocument,a=i?.defaultView,o=e.parentElement;if(!i||!a||!o)throw Error(`Activity publication frame is unavailable.`);let s=n.kind===`matching-v1`,c=s?`data-reader-matching-source`:`data-reader-word-search-source`,l=e.ownerDocument.createElement(`iframe`);l.className=s?`reader-matching-frame`:`reader-word-search-frame`,l.title=`Interactive exercise: ${n.title}`,l.style.cssText=`position:absolute;inset:0;width:100%;height:100%;border:0;`,o.append(l);let u=l.contentDocument;if(!u)throw l.remove(),Error(`Could not create the reader-owned activity frame.`);let d=u.createElement(`meta`);d.httpEquiv=`Content-Security-Policy`,d.content=`default-src 'none'; style-src 'unsafe-inline'`,u.head.append(d),u.title=n.title,u.documentElement.lang=i.documentElement.lang;let f=u.createElement(`style`);f.textContent=`
    html, body { box-sizing: border-box; margin: 0; width: 100%; height: 100%; overflow: hidden; }
    h1 { margin: 0 0 1em; font-size: 1.3em; }
    h2 { margin: 0 0 0.75em; font-size: 1.1em; }
    .word-search-board { overflow: auto; }
    [data-word-search-grid] {
      width: 100%; min-width: 0; table-layout: fixed; border-collapse: collapse; margin: 0 auto;
      color: var(--reader-matching-greek, #0070c0);
    }
    [data-word-search-grid] td { position: relative; border: 0; padding: 0; text-align: center; }
    [data-word-search-grid] td > span { display: grid; place-items: center; aspect-ratio: 1; width: 100%; line-height: 1; }
    [data-word-search-words] { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); margin: 0; padding: 0; list-style: none; gap: 0.3em 1em; }
    [data-word-search-words] > li { color: var(--reader-matching-greek, #0070c0); }
  `,u.head.append(f);let p=u.createElement(`main`);p.setAttribute(`data-study-cheetah-activity`,n.kind),p.setAttribute(`data-activity-id`,n.id),p.setAttribute(`data-activity-revision`,n.revision),n.chapterTitle&&p.setAttribute(`data-chapter-title`,n.chapterTitle),s||(p.className=`word-search`);let m=u.createElement(`h1`);m.textContent=n.title,p.append(m);for(let e of t.querySelectorAll(`:scope > p`)){if(a.getComputedStyle(e).display===`none`)continue;let t=u.createElement(`p`);t.textContent=e.textContent,p.append(t)}if(n.kind===`matching-v1`){let e=u.createElement(`div`);e.className=`matching-columns`;for(let[t,r,i]of[[`Greek words`,n.prompts,!0],[`English meanings`,n.choices,!1]]){let n=u.createElement(`section`),a=u.createElement(`h2`);a.textContent=t;let o=u.createElement(`ol`);o.setAttribute(i?`data-matching-prompts`:`data-matching-choices`,``);for(let e of r){let t=u.createElement(`li`);t.setAttribute(i?`data-match-id`:`data-choice-id`,e.id);let n=u.createElement(`span`);n.setAttribute(i?`data-prompt-text`:`data-choice-text`,``),n.textContent=e.text,e.language&&(n.lang=e.language,t.lang=e.language),t.append(n),o.append(t)}n.append(a,o),e.append(n)}p.append(e)}else{let e=u.createElement(`div`);e.setAttribute(`data-word-search-layout`,``);let t=u.createElement(`div`);t.className=`word-search-board`;let r=u.createElement(`table`);r.setAttribute(`data-word-search-grid`,``),r.setAttribute(`aria-label`,`Greek word search, ${n.grid.length} rows by ${n.grid[0].length} columns`),r.lang=`el`;let i=u.createElement(`tbody`);for(let e of n.grid){let t=u.createElement(`tr`);for(let n of e){let e=u.createElement(`td`),r=u.createElement(`span`);r.textContent=n,e.append(r),t.append(e)}i.append(t)}r.append(i),t.append(r);let a=u.createElement(`section`);a.className=`word-search-vocabulary`;let o=u.createElement(`h2`);o.textContent=`Words to find`;let s=u.createElement(`ul`);s.setAttribute(`data-word-search-words`,``),s.lang=`el`;for(let e of n.words){let t=u.createElement(`li`);t.setAttribute(`data-word-id`,e.id),t.textContent=e.text,s.append(t)}a.append(o,s),e.append(t,a),p.append(e)}u.body.append(p);let h;try{h=n.kind===`matching-v1`?ct(p,n,r):ut(p,n,r)}catch(e){throw l.remove(),e}let g=e.getAttribute(`aria-hidden`),_=e.getAttribute(`tabindex`),v=e.style.opacity;e.setAttribute(`aria-hidden`,`true`),e.setAttribute(`tabindex`,`-1`),e.setAttribute(c,``),e.style.opacity=`0`;let y=()=>{let e=a.getComputedStyle(i.body),n=a.getComputedStyle(i.documentElement);u.documentElement.style.fontSize=n.fontSize,u.documentElement.style.backgroundColor=n.backgroundColor;for(let t of[`width`,`height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`transform`,`transform-origin`,`font-size`,`font-family`,`line-height`,`color`,`background-color`,`--reader-page-fg`,`--reader-page-bg`,`--reader-matching-correct`,`--reader-matching-incorrect`,`--reader-matching-reset`,`--reader-matching-greek`,...U,`--reader-control-greek`,`--reader-control-check`,`--reader-control-reset`,`--reader-control-print`])u.body.style.setProperty(t,e.getPropertyValue(t));u.body.style.lineHeight=e.lineHeight===`normal`?`normal`:String(parseFloat(e.lineHeight)/parseFloat(e.fontSize));let r=a.getComputedStyle(t);if(p.style.rowGap=r.rowGap,p.style.columnGap=r.columnGap,!s){let e=t.querySelector(`[data-word-search-words]`),n=p.querySelector(`[data-word-search-words]`),r=a.getComputedStyle(e);for(let e of[`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`row-gap`,`column-gap`])n.style.setProperty(e,r.getPropertyValue(e))}let o=[...t.querySelectorAll(`h1,h2`)];for(let[e,t]of[...p.querySelectorAll(`h1,h2`)].entries()){let n=o[e];if(!n)continue;let r=a.getComputedStyle(n);for(let e of[`font-size`,`font-family`,`font-weight`,`line-height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`])t.style.setProperty(e,r.getPropertyValue(e))}};y();let b=new MutationObserver(y);b.observe(i.head,{subtree:!0,childList:!0,characterData:!0,attributes:!0}),b.observe(i.body,{attributes:!0}),b.observe(i.documentElement,{attributes:!0});let x=new ResizeObserver(y);return x.observe(e),()=>{b.disconnect(),x.disconnect(),h(),l.remove(),e.removeAttribute(c),g===null?e.removeAttribute(`aria-hidden`):e.setAttribute(`aria-hidden`,g),_===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,_),e.style.opacity=v}}var pt=`body:has(> [data-study-cheetah-enhanced="crossword-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="crossword-v1"] [data-study-cheetah-crossword-instructions] { display: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-layout {\r
  flex-grow: 1;\r
  grid-template-columns: max-content var(--sc-crossword-width, minmax(0, 1fr));\r
  justify-content: center;\r
  align-content: center;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-grid { width: var(--sc-crossword-width, 100%); max-width: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr) minmax(0, 1fr);\r
  max-height: max(var(--sc-crossword-height), 10em);\r
  min-height: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] [data-crossword-wide="true"] .crossword-clues {\r
  grid-template-columns: max-content max-content;\r
  grid-template-rows: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues h2 { margin: 0 0 0.4em; line-height: 1.2; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: auto; min-height: 0; margin: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues li { position: relative; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue {\r
  padding: 0.1em 0.2em;\r
  border: 1px solid transparent;\r
  color: inherit;\r
  background: transparent;\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); font-weight: bold; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="correct"]::after { content: " \\2713"; color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="incorrect"]::after { content: " \\2717"; color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-input {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  box-sizing: border-box;\r
  border: 2px solid transparent;\r
  padding: 0;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: inherit;\r
  font-size: 1.25em;\r
  text-align: center;\r
  cursor: text;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-number { pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-number { z-index: 1; pointer-events: none; color: var(--ui-control-fg, inherit); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-selected { background: var(--ui-control-bg-active, color-mix(in srgb, currentColor 12%, transparent)); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-current { border-color: currentColor; }\r
[data-study-cheetah-enhanced="crossword-v1"] :is(.sc-crossword-input, .sc-crossword-clue):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-crossword-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer p { margin: 0; }\r
.sc-crossword-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-crossword-status { min-width: 0; text-align: left; }\r
.sc-crossword-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-crossword-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
.sc-crossword-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
@media (orientation: landscape) {\r
  body > [data-study-cheetah-enhanced="crossword-v1"] {\r
    --sc-crossword-sidebar-width: clamp(7rem, 15vw, 10rem);\r
    position: relative;\r
    padding-inline-end: calc(var(--sc-crossword-sidebar-width) + 1rem);\r
  }\r
  body > [data-study-cheetah-enhanced="crossword-v1"] > h1 {\r
    margin-inline-end: calc(-1 * (var(--sc-crossword-sidebar-width) + 1rem));\r
  }\r
  body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer {\r
    position: absolute;\r
    inset-block-end: 0;\r
    inset-inline-end: 0;\r
    width: var(--sc-crossword-sidebar-width);\r
    max-height: 100%;\r
    margin-top: 0;\r
    overflow-y: auto;\r
    overflow-wrap: anywhere;\r
  }\r
  body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer-row {\r
    grid-template-columns: minmax(0, 1fr);\r
  }\r
  body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-controls {\r
    flex-direction: column;\r
    flex-wrap: nowrap;\r
  }\r
}\r
`;function mt(e,t,n){let r=e.querySelector(`.crossword-grid`),i=[...e.querySelectorAll(`[data-entry-id]`)];if(!r||i.length!==t.clues.length)throw Error(`Crossword worksheet does not match its clues.`);let{cleanups:a,attribute:o,append:s,button:c}=st(e,pt),l=le.getInstance(),u={},d=t.clues[0],f=Y(d)[0],p=d.direction,m=!1,h=0,g=!1,_=null,v=``,y=new Map;function b(e){console.error(`[Reader] Crossword progress:`,e),_=`Could not load or save crossword progress. ${e instanceof Error?e.message:String(e)}`}try{let e=l.getCrosswordProgress(n.publicationId,t);e&&(u=e.letters,m=e.submitted,h=e.attempts)}catch(e){g=!0,b(e)}o(e,`data-study-cheetah-enhanced`,`crossword-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Use the English clues to fill in the Greek words. Accents and breathing marks are not required.`,`Use the English clues to fill in the Greek words. Include accents and breathing marks.`,`Fill in the Greek words.`].includes(t.textContent?.trim()??``)&&o(t,`data-study-cheetah-crossword-instructions`,``);o(r,`role`,`grid`),o(r,`aria-description`,`Select a clue or square, then type Greek letters. Click a selected crossing again or press Enter to change direction. Use arrow keys to move.`);let x=i.map((e,n)=>{let r=t.clues[n];for(let t of e.children)o(t,`hidden`,``);let i=c(e,`${r.number}. ${r.text}`,()=>{S(r,Y(r)[0],!0)});return i.classList.add(`sc-crossword-clue`),i});function S(e,t,n){if(d=e,p=e.direction,f=t,v=`${e.number} ${e.direction}: ${e.text}.`,I(),n){let e=y.get(t);e?.focus(),e?.select()}}function C(e,n){let r=t.clues.filter(t=>Y(t).includes(e)),i=r.find(e=>e.direction===p),a=r.find(e=>e.direction!==p),o=(n&&e===f?a:i)??i??a;o&&S(o,e,!1)}function w(){try{l.saveCrosswordProgress(n.publicationId,t,{revision:t.revision,puzzle:X(t),letters:u,submitted:m,attempts:h,updated:Date.now()}),_=null}catch(e){b(e)}}for(let[n,i]of t.cells.entries())for(let[c,l]of i.entries()){if(!l)continue;let i=r.rows[n].cells[c],h=K(n,c);o(i,`role`,`gridcell`);let _=s(i,`input`,`sc-crossword-input`);_.type=`text`,_.lang=t.language,_.autocomplete=`off`,_.spellcheck=!1,_.dataset.crosswordCell=h,y.set(h,_);let b=!1,x=()=>{b=h===f&&e.ownerDocument.activeElement===_},S=()=>{h!==f&&C(h,!1),_.select()},T=()=>{b&&C(h,!0),b=!1,_.select()},E=e=>{if(h!==f||g)return;if(!e)delete u[h];else try{u[h]=ne(e)}catch{v=`Enter one Greek letter per square.`,I(),_.select();return}m=!1,v=``,w();let t=Y(d),n=t[t.indexOf(h)+1];e&&n&&(f=n),I(),e&&n?y.get(n)?.focus():_.select()},D=e=>{if(`isComposing`in e&&!e.isComposing&&`inputType`in e&&(e.inputType===`insertText`||e.inputType===`insertReplacementText`)&&`data`in e&&typeof e.data==`string`&&e.data)return e.data},O=e=>{let t=D(e);!e.cancelable||t===void 0||(e.preventDefault(),E(t))},k=e=>{if(!(`isComposing`in e&&e.isComposing)){if(h!==f){_.value=u[h]??``;return}E(D(e)??_.value)}},A=e=>{e.data?E(e.data):(_.value=u[h]??``,h===f&&_.select())},j=e=>{if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;if(e.key===`Enter`){e.preventDefault(),C(h,!0);return}let r={ArrowLeft:[0,-1,`across`],ArrowRight:[0,1,`across`],ArrowUp:[-1,0,`down`],ArrowDown:[1,0,`down`]}[e.key];if(!r)return;e.preventDefault();let[i,a,o]=r;for(let e=n+i,r=c+a;e>=0&&e<t.rows&&r>=0&&r<t.columns;e+=i,r+=a){let t=K(e,r);if(y.has(t)){p=o,C(t,!1),y.get(t)?.focus();break}}};_.addEventListener(`pointerdown`,x),_.addEventListener(`focus`,S),_.addEventListener(`click`,T),_.addEventListener(`beforeinput`,O),_.addEventListener(`input`,k),_.addEventListener(`compositionend`,A),_.addEventListener(`keydown`,j),a.push(()=>{_.removeEventListener(`pointerdown`,x),_.removeEventListener(`focus`,S),_.removeEventListener(`click`,T),_.removeEventListener(`beforeinput`,O),_.removeEventListener(`input`,k),_.removeEventListener(`compositionend`,A),_.removeEventListener(`keydown`,j)})}let T=s(e,`div`,`sc-crossword-footer`),E=s(T,`div`,`sc-crossword-footer-row`),D=s(E,`p`,`sc-crossword-status`);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=s(D,`span`,``),k=s(D,`span`,`sc-crossword-announcement`),A=s(T,`p`,`sc-crossword-error`);A.setAttribute(`role`,`alert`);let j=s(E,`div`,`sc-crossword-controls`),M=c(j,`Check answers`,()=>{m=!0,h++,v=``,w(),I()});M.classList.add(`sc-crossword-check`);let N=c(j,`Reset puzzle`,()=>{try{l.deleteCrosswordProgress(n.publicationId,t),u={},m=!1,h=0,g=!1,v=`Answers cleared.`,w()}catch(e){b(e)}I()});N.classList.add(`sc-crossword-reset`);let P=c(j,`Print worksheet`,n.onprint);P.classList.add(`sc-crossword-print`);for(let[e,t,n]of[[M,`Check`,`M5 12l4 4L19 6`],[N,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[P,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])ot(e,t,n);let F=s(T,`p`,`sc-crossword-save-status`);function I(){let e=Y(d),n=t.clues.filter(e=>te(e,u)).length;O.textContent=m?`${n} of ${t.clues.length} correct.${n===t.clues.length?` Puzzle complete.`:``}`:`${Object.keys(u).length} of ${y.size} squares filled. Not checked.`,k.textContent=v?` ${v}`:``,A.hidden=_===null,A.textContent=_,F.hidden=_===null,F.textContent=_?`Progress is not saved.`:``,M.disabled=g||Object.keys(u).length===0,x.forEach((e,n)=>{e.disabled=g,e.setAttribute(`aria-pressed`,String(t.clues[n].id===d.id));let r=t.clues[n],i=Y(r),a=m&&i.some(e=>u[e])?te(r,u)?`correct`:`incorrect`:``;e.dataset.result=a,e.setAttribute(`aria-description`,a===`correct`?`Correct`:a===`incorrect`?`Not correct`:`Not checked`)});for(let[n,r]of y){let[i,a]=n.split(`,`).map(Number),o=u[n]??``;r.value!==o&&(r.value=o),r.disabled=g,r.tabIndex=n===f?0:-1,r.classList.toggle(`sc-crossword-selected`,e.includes(n)),r.classList.toggle(`sc-crossword-current`,n===f);let s=t.clues.filter(e=>Y(e).includes(n)).map(e=>`${e.number} ${e.direction}: ${e.text}`).join(`; `);r.setAttribute(`aria-label`,`Row ${i+1}, column ${a+1}. ${s}`)}}I();let L=e.querySelector(`.crossword-layout`),R=L?.querySelector(`.crossword-clues`);if(L&&R){let n=[...e.children].filter(e=>e!==L),r=e=>Number.parseFloat(e)||0,i=()=>{if(!e.clientHeight||!e.clientWidth)return;let i=getComputedStyle(e),a=n.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),o=e.clientHeight-r(i.paddingTop)-r(i.paddingBottom)-r(i.rowGap)*a.length;for(let e of a){let t=getComputedStyle(e);o-=e.getBoundingClientRect().height+r(t.marginTop)+r(t.marginBottom)}o-=t.rows+2;let s=e.clientWidth-r(i.paddingLeft)-r(i.paddingRight);L.dataset.crosswordWide=String(s>=700);let c=r(getComputedStyle(L).columnGap),l=s-R.offsetWidth-c,u=t.columns*24,d=Math.floor(Math.max(u,Math.min(l,o*t.columns/t.rows)));L.style.setProperty(`--sc-crossword-width`,`${d}px`),L.style.setProperty(`--sc-crossword-height`,`${Math.ceil(d*t.rows/t.columns)}px`)},o=new ResizeObserver(i);o.observe(e);for(let e of n)o.observe(e);i(),a.push(()=>{o.disconnect(),L.style.removeProperty(`--sc-crossword-width`),L.style.removeProperty(`--sc-crossword-height`),delete L.dataset.crosswordWide})}return()=>{for(let e of a.reverse())e()}}function ht(e){let{pointerX:t,pointerY:n,screenWidth:r,screenHeight:i,hasPreviousChapter:a,hasNextChapter:o}=e,s=r*.33,c=r*.67,l=i*.33,u=i*.67;return t<s&&a?`previous`:t>c&&o?`next`:t>=s&&t<=c&&n>=l&&n<=u?`toggle-ui`:`none`}var gt=l(`<div class="loading-overlay svelte-1jg2usx"><div class="spinner svelte-1jg2usx" aria-hidden="true"></div> <p>Opening book...</p></div>`),_t=l(`<div class="error-overlay svelte-1jg2usx" role="alert"><p class="error-title svelte-1jg2usx">Could not open book</p> <p class="error-body svelte-1jg2usx"> </p> <button class="svelte-1jg2usx">Back to library</button></div>`),vt=l(`<img alt="" class="cover-image"/>`),yt=l(`<p> </p>`),bt=l(`<div class="cover-fallback" aria-hidden="true"><p> </p> <!></div>`),xt=l(`<button class="cover-overlay" type="button" aria-label="Start reading"><div class="cover-page svelte-1jg2usx" role="img"><!></div></button>`),St=l(`<p class="save-error svelte-1jg2usx" role="alert"> </p>`),Ct=l(`<div aria-hidden="true"></div> <div aria-hidden="true"></div>`,1),wt=l(`<div class="immersive-reveal-edge top svelte-1jg2usx" aria-hidden="true"></div> <div class="immersive-reveal-edge bottom svelte-1jg2usx" aria-hidden="true"></div>`,1),Tt=l(`<div role="main"><dialog class="safari-warning svelte-1jg2usx" aria-labelledby="safari-warning-title" aria-describedby="safari-warning-description"><h2 id="safari-warning-title" class="svelte-1jg2usx">Safari reader limitations</h2> <p id="safari-warning-description" class="svelte-1jg2usx">Tap the left or right edge to turn pages. Other book interactions and
      some keyboard shortcuts may not work in Safari. Use the
      header or footer to show the chapter menu and position slider.</p> <form method="dialog"><button type="submit" class="svelte-1jg2usx">Continue reading</button></form></dialog> <!> <!> <div class="epub-viewport svelte-1jg2usx"><!> <!> <!> <!></div> <!> <!></div> <!>`,1);function Et(s,l){E(l,!0);let d=`study-cheetah.reader.display-mode`,m=le.getInstance(),_=ue.getInstance(),v=ee(),y=f(null),S=f(A([])),w=f(0),O=f(`best-fit`),M=f(null),N=f(1),F=f(!0),I=f(!1),L=f(!1),R=f(!0),U=f(!0),W=f(null),G=f(null),te=f(null),ne=f(null),ie=f(null),oe=f(void 0),K=f([]),J=f(new Map),Y=f(new Map),ce=f(null),X,Z=null,Q=!1,me=!1,he,ge,_e,ve=0,ye=0,be=0,xe=!1,Se=Promise.resolve(),we=!1,Te=new AbortController,Ee=new Map,De=new Map,Oe=p(()=>o(S)[o(w)]),ke=p(()=>o(K).find(e=>o(M)&&e.spineIndex>=o(M).start.index&&e.spineIndex<=o(M).end.index)?.activity),Ae=p(()=>{let e=o(M);if(!e||o(L)||o(U)||o(W))return null;let t=t=>t>=e.start.index&&t<=e.end.index;return[...o(J).values()].some(t)?[...o(Y).values()].some(t)?`activity`:`ordinary`:null}),je=p(()=>o(ce)??o(ke)),Me=p(()=>o(M)?.atEnd?100:Math.round((o(M)?.start.percentage??0)*100)),Pe=p(()=>H(o(y)?.accessibility.theme??`adaptive`)),Fe=p(()=>`Section page ${o(M)?.start.displayed.page??1} of ${o(M)?.start.displayed.total??1}`),Ie=p(()=>o(L)?`Tap to start reading`:`${o(Me)}% complete`),Le;function Re(e,t){Q||(console.error(`[Reader] ${e}:`,t),i(W,`${t instanceof Error?t.message:String(t)}\n\nStage: ${e}`))}function ze(){let e=new URLSearchParams(window.location.search),t=e.get(`mode`)??(e.has(`horizontalPaging`)||e.has(`twoPage`)?null:localStorage.getItem(d));if(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)return t;t!==null&&console.warn(`[Reader] Unrecognized reading view:`,t);let n=e.get(`horizontalPaging`)??localStorage.getItem(`study-cheetah.reader.horizontal-paging`),r=e.get(`twoPage`)??localStorage.getItem(`study-cheetah.reader.two-page`);return n===`1`||n===`true`?`single`:r===`1`||r===`true`?`spread`:n===`0`||n===`false`?`scroll`:`best-fit`}function Be(){if(!o(y)||!we)return Se;we=!1;let e=o(y);return Se=Se.then(()=>m.updateBook(e)).then(()=>{i(G,null)}).catch(e=>{console.error(`[Reader] Saving reading preferences and position failed:`,e),we=!0,i(G,`Could not save your reading position and preferences.`)}),Se}function Ve(){if(we=!0,o(y))try{m.checkpointReadingState(o(y))}catch(e){console.error(`[Reader] Checkpointing reading preferences and position failed:`,e),i(G,`Could not save your reading position and preferences.`)}clearTimeout(_e),_e=setTimeout(()=>{Be()},500)}function He(e){if(i(M,e),o(S)[o(w)]?.spineIndex!==e.start.index){let t=o(S).findIndex(t=>t.spineIndex===e.start.index);t>=0&&i(w,t,!0)}!o(y)||me||Q||(i(y,{...o(y),currentLocation:{chapterId:o(Oe)?.id??String(e.start.index),chapterIndex:o(w),elementOffset:0,percentageComplete:Math.round((e.start.percentage??0)*100),cfiFragment:e.start.cfi}},!0),Ve())}function Ue(e){if(e!==Z||Q)return;let t=e.currentLocation();t&&He(t)}function We(){for(let e of Ee.values())e();Ee.clear(),i(K,[]),i(J,new Map),i(Y,new Map)}function Ge(e){let t=!1,n=()=>{t=!0};return e.addEventListener(`study-cheetah-event-probe`,n),e.dispatchEvent(new Event(`study-cheetah-event-probe`)),e.removeEventListener(`study-cheetah-event-probe`,n),t}function Ke(e){return!!e&&`closest`in e&&typeof e.closest==`function`&&!!e.closest(`a, button, input, select, textarea, summary, [contenteditable="true"], [role="button"], [role="link"], [data-study-cheetah-enhanced]`)}function qe(e){if(document.querySelector(`dialog[open]`)||e.defaultPrevented||e.ctrlKey||e.metaKey||Ke(e.target))return;if(e.altKey){!e.shiftKey&&(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),pt(e.key===`ArrowDown`?1:-1));return}if(e.key===`Escape`){e.preventDefault(),Je();return}let t=e.key===`ArrowRight`||e.key===`PageDown`,n=e.key===`ArrowLeft`||e.key===`PageUp`;!t&&!n||(e.preventDefault(),lt(t?1:-1))}function Je(){clearTimeout(he),i(F,!o(F)),o(F)&&Xe()}function Ye(){i(I,!o(I)),o(I)&&(clearTimeout(he),i(F,!1))}function Xe(){clearTimeout(he),he=setTimeout(()=>{document.querySelector(`.reading-footer .chapter-menu, dialog[open]`)?Xe():i(F,!1)},5e3)}function Ze(e,t){if(o(L)||o(U)||document.querySelector(`dialog[open]`))return;if(!o(F)&&(t<=60||t>=window.innerHeight-60)){Je();return}let n=ht({pointerX:e,pointerY:t,screenWidth:window.innerWidth,screenHeight:window.innerHeight,hasPreviousChapter:!0,hasNextChapter:!o(M)?.atEnd});n===`toggle-ui`?Je():(n===`next`||n===`previous`)&&lt(n===`next`?1:-1)}function $e(e){e.on(`relocated`,t=>{e===Z&&!Q&&He(t)}),e.on(`layout`,t=>{e===Z&&i(N,t.divisor,!0)}),e.on(`rendered`,(t,n)=>{if(e!==Z||Q)return;Ee.get(n.id)?.();let r=n.document,a=n.iframe;if(!r||!a)return;a.title=`Book content`;let s=Ge(r),c=n.section.index;if(typeof c==`number`){let e=new Map(o(J)),t=new Map(o(Y));s?e.delete(n.id):e.set(n.id,c),r.querySelector(`[data-study-cheetah-activity]`)?t.set(n.id,c):t.delete(n.id),i(J,e),i(Y,t)}let l=[],u=new Set,d=o(ne);if(d){let e=[];for(let t of d.features){let o=[];try{let i=n.section.index;if(typeof i!=`number`)throw Error(`Exercise reading-order position is unavailable.`);let c=[...r.querySelectorAll(`[data-study-cheetah-activity="${t}"]`)].map(e=>{let c=t===`word-search-v1`?re(e):t===`crossword-v1`?q(e):ae(e),l={publicationId:d.publicationId,onprint:()=>{et(c)}};if(c.kind===`word-search-v1`)o.push(ut(e,c,l)),!s&&e.parentElement===r.body&&o.push(ft(a,e,c,l));else if(c.kind===`crossword-v1`)o.push(mt(e,c,l));else{let t=JSON.stringify([d.publicationId,c.id,c.revision]);o.push(ct(e,c,{...l,order:De.get(t),onorder:e=>{De.set(t,e)}})),!s&&e.parentElement===r.body&&o.push(ft(a,e,c,{...l,order:De.get(t),onorder:e=>{De.set(t,e)}}))}return{viewId:n.id,spineIndex:i,activity:c}});e.push(...c),l.push(...o)}catch(e){u.add(t);for(let e of o)e();console.error(`[Reader] Invalid ${t} exercise:`,e),i(te,`Interactive exercise unavailable: ${e instanceof Error?e.message:String(e)}`)}}i(K,[...o(K).filter(e=>e.viewId!==n.id),...e])}if(o(ie)){let e=o(ie).active.filter(e=>!u.has(e));l.push(se(r,o(ie),e))}let f=0,p=0,m=e=>{f=e.clientX,p=e.clientY},h=e=>{if(Ke(e.target)||r.getSelection()?.isCollapsed===!1||Math.hypot(e.clientX-f,e.clientY-p)>10)return;let t=a.getBoundingClientRect();Ze(t.left+e.clientX,t.top+e.clientY)};r.addEventListener(`pointerdown`,m),r.addEventListener(`pointerup`,h),r.addEventListener(`keydown`,qe),Ee.set(n.id,()=>{for(let e of l)e();r.removeEventListener(`pointerdown`,m),r.removeEventListener(`pointerup`,h),r.removeEventListener(`keydown`,qe)})}),e.on(`removed`,(e,t)=>{Ee.get(t.id)?.(),Ee.delete(t.id),i(K,o(K).filter(e=>e.viewId!==t.id));let n=new Map(o(J)),r=new Map(o(Y));n.delete(t.id),r.delete(t.id),i(J,n),i(Y,r)}),e.on(`displayerror`,t=>{e===Z&&!Q&&Re(`chapter-display`,t)})}async function et(e){i(ce,e,!0);try{await n(),window.print()}catch(e){console.error(`[Reader] Printing worksheet failed:`,e),i(te,`Could not print worksheet: ${e instanceof Error?e.message:String(e)}`)}finally{i(ce,null)}}async function tt(e,t){let n,r=()=>{},i=new Promise((t,i)=>{r=i,n=setTimeout(()=>i(Error(`Chapter rendering timed out (15s).`)),15e3),e.on(`displayerror`,r)}),a=()=>r(Error(`Reader closed before chapter rendering completed.`));Te.signal.addEventListener(`abort`,a,{once:!0});try{await Promise.race([e.display(t),i])}finally{clearTimeout(n),e.off(`displayerror`,r),Te.signal.removeEventListener(`abort`,a)}}function nt(){o(y)&&_.applyTheme(o(y).id,{...o(y).accessibility,theme:o(y).accessibility.theme??`adaptive`})}async function it(e){if(!o(y)||Q)return;let t=o(O)===`best-fit`&&!await _.supportsBestFit(o(y).id)?`spread`:o(O);if(Q)return;We();let n=_.attachRenderer(o(y).id,X,t);Z=n,$e(n),await n.started,!(Q||n!==Z)&&(n.spread(t===`spread`?`auto`:`none`,1e3),nt(),await tt(n,e),Ue(n))}async function at(){try{i(O,ze(),!0);let e=new URLSearchParams(window.location.search).get(`id`),t=e?null:de(),n;if(n=e?await m.getBook(e):t?await fe(t):await pe(),!n)throw Error(`The selected book was not found in your library.`);if(Q)return;i(y,n,!0),v.applyBookRecord(n);let r=await _.loadBook(n.id,n.opfsPath);try{i(ne,await _.getActivityCapability(n.id),!0),i(ie,await _.getExtensionCapability(n.id),!0)}catch(e){console.error(`[Reader] Invalid publication extension declaration:`,e),i(te,`Book enhancements unavailable: ${e instanceof Error?e.message:String(e)}`)}if(i(S,await _.getChapters(n.id),!0),Q||(r.locations.length()===0&&await r.locations.generate(1e3),Q)||(i(w,Math.max(0,Math.min(n.currentLocation?.chapterIndex??0,o(S).length-1)),!0),i(L,!0),await it(n.currentLocation?.cfiFragment??(n.currentLocation?o(S)[o(w)]?.href:void 0)??0),Q))return;n.currentLocation&&(ge=setTimeout(st,2e3)),Xe()}catch(e){Q||Re(`reader-init`,e)}finally{Q||(i(U,!1),i(R,!1))}}async function ot(e){if(o(U)||!Z||e===o(O))return;let t=Z.currentLocation()?.start.cfi??o(y)?.currentLocation?.cfiFragment??0;i(U,!0),me=!0,i(O,e,!0);try{localStorage.setItem(d,e),await it(t)}catch(e){Re(`reading-view`,e)}finally{me=!1,i(U,!1),Z&&Ue(Z)}}function st(){clearTimeout(ge),i(L,!1)}async function lt(e){let t=Z;if(!t||o(U)||o(W))return;if(o(L)){e===1&&st();return}let n=t.currentLocation();if(e===-1&&n?.atStart){i(L,!0);return}if(!(e===1&&n?.atEnd)){i(U,!0);try{e===1?await t.next():await t.prev(),Ue(t)}catch(e){Re(`page-navigation`,e)}finally{i(U,!1)}}}async function dt(e){let t=o(S)[e],n=Z;if(!(!t||!n||o(U))){i(U,!0),st();try{await tt(n,t.href??t.spineIndex),i(w,e,!0),Ue(n)}catch(e){Re(`chapter-navigation`,e)}finally{i(U,!1)}}}async function pt(e){let t=Z;if(!(!o(y)||!t||o(U)||o(W)||!o(S).length))try{let n=t.currentLocation();if(!n)throw Error(`Reading position is not ready for chapter navigation.`);let r=_.getChapterPosition(o(y).id,o(S),n,o(w)),i=e===1?r.chapterIndex+1:r.atBeginning?r.chapterIndex-1:r.chapterIndex;for(;i>=0&&i<o(S).length&&o(S)[i].spineIndex<0;)i+=e;i>=0&&i<o(S).length&&await dt(i)}catch(e){Re(`chapter-navigation`,e)}}async function Et(e){let t=Z;if(!(!o(y)||!t||o(U)||o(W))){i(U,!0);try{let n=_.getCfiFromPercentage(o(y).id,e/100);st(),await tt(t,n),Ue(t)}catch(e){Re(`position-navigation`,e)}finally{i(U,!1)}}}async function Dt(e,t){let n=Z;if(!o(y)||!n||o(U))return;let r=n.currentLocation()?.start.cfi??0;i(y,{...o(y),accessibility:{...o(y).accessibility,[e]:Math.min(2,Math.max(e===`fontSize`?.75:1,Math.round((o(y).accessibility[e]+t)*100)/100))}},!0),i(U,!0),me=!0;try{n.clear(),nt(),await tt(n,r)}catch(e){Re(`typography`,e)}finally{me=!1,i(U,!1),Ue(n),Ve()}}function Ot(e){!o(y)||o(U)||(i(y,{...o(y),accessibility:{...o(y).accessibility,theme:e}},!0),nt(),Ve())}async function kt(){clearTimeout(_e),await Be(),o(G)||await B(`${V}/start/library`)}function At(e){xe=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`),(xe||Ke(e.target))&&clearTimeout(he),ye=e.clientX,be=e.clientY}function jt(e){if(o(F)&&(xe||Ke(e.target))&&Xe(),Ke(e.target)||Math.hypot(e.clientX-ye,e.clientY-be)>10)return;let t=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`);if(xe||t){xe&&t&&!o(F)&&Je();return}Ze(e.clientX,e.clientY)}function Mt(){o(F)&&Xe(),xe=!1}function Nt(e){o(L)&&e.deltaY>0&&(e.preventDefault(),st())}j(()=>{let e=navigator.userAgent;/\bVersion\/[\d.]+.*\bSafari\//.test(e)&&!/\b(?:Chrome|Chromium|CriOS|FxiOS|Edg|EdgiOS|EdgA|OPR|OPiOS|DuckDuckGo)\//i.test(e)&&Le.showModal(),window.addEventListener(`keydown`,qe);let t=new ResizeObserver(()=>{cancelAnimationFrame(ve),ve=requestAnimationFrame(()=>{if(!Z||o(U)||Q||!X.clientWidth||!X.clientHeight)return;let e=Z.currentLocation()?.start.cfi;Z.resize(X.clientWidth,X.clientHeight,e)})});t.observe(X);let n=new MutationObserver(()=>nt());return n.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-ui-theme`]}),at(),()=>{Q=!0,Te.abort(),t.disconnect(),n.disconnect(),cancelAnimationFrame(ve),window.removeEventListener(`keydown`,qe),clearTimeout(he),clearTimeout(ge),clearTimeout(_e),Be(),We(),o(y)&&_.detachRenderer(o(y).id),Z=null}});var Pt=Tt(),Ft=r(Pt);let It;var Lt=u(Ft);D(Lt,e=>Le=e,()=>Le);var Rt=a(Lt,2),zt=e=>{rt(e,{get capability(){return o(ie)},onready:e=>{i(oe,e,!0)}})};g(Rt,e=>{o(ie)&&!o(R)&&!o(L)&&e(zt)});var Bt=a(Rt,2),Vt=e=>{{let t=p(()=>v.appName||o(y).title||o(y).filename),n=p(()=>o(ke)?.chapterTitle??o(Oe)?.label),r=p(()=>o(y).accessibility.theme??`adaptive`);Ce(e,{get bookTitle(){return o(t)},get chapterTitle(){return o(n)},get controlsVisible(){return o(F)},get readerTheme(){return o(r)},get displayMode(){return o(O)},get busy(){return o(U)},onDisplayModeChange:ot,onReaderThemeChange:Ot,onClose:kt,get onFeatures(){return o(oe)},get immersive(){return o(I)},onImmersiveChange:Ye})}};g(Bt,e=>{o(y)&&e(Vt)});var $=a(Bt,2),Ht=u($),Ut=e=>{t(e,gt())},Wt=n=>{var r=_t(),i=a(u(r),2),s=u(i,!0);h(i);var l=a(i,2);h(r),z(()=>c(s,o(W))),e(`click`,l,()=>B(`${V}/start/library`)),t(n,r)},Gt=n=>{var r=xt(),i=u(r),s=u(i),l=e=>{var n=vt();z(()=>C(n,`src`,o(y).coverImage)),t(e,n)},d=e=>{var n=bt(),r=u(n),i=u(r,!0);h(r);var s=a(r,2),l=e=>{var n=yt(),r=u(n,!0);h(n),z(()=>c(r,o(y).author)),t(e,n)};g(s,e=>{o(y).author&&e(l)}),h(n),z(()=>c(i,o(y).title??o(y).filename)),t(e,n)};g(s,e=>{o(y).coverImage?e(l):e(d,-1)}),h(i),h(r),z(()=>C(i,`aria-label`,`Cover for ${o(y).title??o(y).filename}`)),e(`click`,r,st),t(n,r)};g(Ht,e=>{o(R)?e(Ut):o(W)?e(Wt,1):o(L)&&o(y)&&e(Gt,2)});var Kt=a(Ht,2),qt=e=>{var n=St(),r=u(n,!0);h(n),z(()=>c(r,o(G))),t(e,n)};g(Kt,e=>{o(G)&&e(qt)});var Jt=a(Kt,2),Yt=e=>{var n=St(),r=u(n,!0);h(n),z(()=>c(r,o(te))),t(e,n)};g(Jt,e=>{o(te)&&e(Yt)});var Xt=a(Jt,2),Zt=e=>{var n=Ct(),i=r(n);let s;var c=a(i,2);let l;z(()=>{s=T(i,1,`page-turn-zone previous svelte-1jg2usx`,null,s,{activity:o(Ae)===`activity`}),l=T(c,1,`page-turn-zone next svelte-1jg2usx`,null,l,{activity:o(Ae)===`activity`})}),t(e,n)};g(Xt,e=>{o(Ae)&&e(Zt)}),h($),D($,e=>X=e,()=>X);var Qt=a($,2),$t=e=>{{let t=p(()=>o(Oe)?.label??`Front matter`);Ne(e,{get controlsVisible(){return o(F)},get fontSize(){return o(y).accessibility.fontSize},get lineHeight(){return o(y).accessibility.lineHeight},get progressPercent(){return o(Me)},get currentChapterIndex(){return o(w)},get totalChapters(){return o(S).length},get chapterPositionLabel(){return o(t)},get pageLabel(){return o(Fe)},get progressLabel(){return o(Ie)},get chapters(){return o(S)},get busy(){return o(U)},onFontSizeIncrease:()=>Dt(`fontSize`,.1),onFontSizeDecrease:()=>Dt(`fontSize`,-.1),onLineHeightIncrease:()=>Dt(`lineHeight`,.1),onLineHeightDecrease:()=>Dt(`lineHeight`,-.1),onProgressChange:Et,onChapterSelect:dt})}};g(Qt,e=>{o(y)&&e($t)});var en=a(Qt,2),tn=e=>{var n=wt();b(2),t(e,n)};g(en,e=>{o(I)&&!o(F)&&!o(L)&&e(tn)}),h(Ft);var nn=a(Ft,2),rn=e=>{Qe(e,{get activity(){return o(je)}})};g(nn,e=>{o(je)&&e(rn)}),z(()=>{It=T(Ft,1,`reader-shell svelte-1jg2usx`,null,It,{"show-ui":o(F),immersive:o(I)}),k(Ft,`--reader-page-bg: ${o(Pe).background}; --reader-page-fg: ${o(Pe).foreground}; --reader-page-muted: ${o(Pe).muted}; --reader-page-accent: ${o(Pe).accent}; --reader-page-border: ${o(Pe).border};`),C($,`aria-busy`,o(U)),C($,`data-display-mode`,o(O)),C($,`data-start-cfi`,o(M)?.start.cfi),C($,`data-end-cfi`,o(M)?.end.cfi),C($,`data-spine-index`,o(M)?.start.index),C($,`data-page`,o(M)?.start.displayed.page),C($,`data-total-pages`,o(M)?.start.displayed.total),C($,`data-visible-pages`,o(N))}),e(`pointerdown`,Ft,At),e(`pointerup`,Ft,jt),x(`pointercancel`,Ft,Mt),x(`wheel`,Ft,Nt),e(`pointerdown`,Lt,e=>e.stopPropagation()),e(`pointerup`,Lt,e=>e.stopPropagation()),t(s,Pt),P()}S([`pointerdown`,`pointerup`,`click`]);export{Et as component,me as universal};