import{A as e,B as t,C as n,E as r,F as i,G as a,J as o,K as s,N as c,O as l,S as u,T as d,U as f,W as p,X as m,Y as h,Z as g,a as _,at as v,b as y,c as b,d as x,f as S,it as C,j as w,k as T,l as E,lt as D,m as O,n as k,nt as A,o as j,ot as M,p as N,q as P,r as F,s as I,st as L,tt as R,u as z,v as B,w as V,y as H,z as U}from"../chunks/BiXsnc5P.js";import{d as ee,t as te}from"../chunks/Bu3NSlbJ.js";import"../chunks/xihTtKlq.js";import"../chunks/riDYlCXu.js";import{n as ne}from"../chunks/8skaqA67.js";import{n as re,r as ie,t as ae}from"../chunks/xfNK4v2R.js";import{t as oe}from"../chunks/EOpud84c.js";import{i as W,n as se,r as ce,t as le}from"../chunks/S0BpUVz8.js";import{_ as G,a as K,c as ue,d as de,f as fe,g as pe,h as me,i as q,l as he,m as ge,n as _e,o as J,p as ve,r as ye,s as be,t as xe,u as Se,v as Ce}from"../chunks/40mwSNPL.js";import{i as we,n as Te,r as Ee}from"../chunks/Brwpvl71.js";var Y=D({load:()=>X}),X=async()=>({readyToRender:!0}),De=d(`<button class="chapter-toggle svelte-1e78rkn" type="button"><svg aria-hidden="true" viewBox="0 0 20 20"><path d="m7 4 6 6-6 6"></path></svg></button>`),Oe=d(`<div><!></div>`),ke=d(`<li><div class="chapter-row svelte-1e78rkn"><button><span class="chapter-number svelte-1e78rkn"> </span> <span class="chapter-label svelte-1e78rkn"> </span></button> <!></div> <!></li>`),Ae=d(`<ol class="chapter-entries svelte-1e78rkn"></ol>`),je=d(`<p class="chapter-title svelte-1e78rkn"> </p>`),Me=d(`<button class="features-button svelte-1e78rkn" type="button" aria-label="Book enhancements">Features</button>`),Ne=d(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">View</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reading view"><option>Vertical scroll</option><option>Single page</option><option>Facing pages</option><option>Best fit</option></select></label>`),Pe=d(`<div class="header-content controls-mode svelte-1e78rkn"><button class="close-button svelte-1e78rkn" aria-label="Close reader">✕</button> <button class="menu-button svelte-1e78rkn" type="button" aria-label="Chapter menu" aria-controls="chapter-menu" title="Chapter menu">☰</button> <div class="header-text svelte-1e78rkn"><h1 class="book-title svelte-1e78rkn"> </h1> <!></div> <div class="header-settings svelte-1e78rkn"><!> <!> <!></div> <!></div>`),Fe=d(`<div class="header-content passive-mode svelte-1e78rkn"><div class="passive-header-text svelte-1e78rkn"><p class="book-title svelte-1e78rkn"> </p> <!></div></div>`),Ie=d(`<div class="chapter-menu svelte-1e78rkn" id="chapter-menu"><div class="chapter-menu-header svelte-1e78rkn"><h2 class="svelte-1e78rkn">Chapters</h2> <button class="close-menu svelte-1e78rkn" type="button" aria-label="Close menu">✕</button></div> <nav class="chapter-list svelte-1e78rkn" aria-label="Table of contents"><!></nav></div>`),Le=d(`<header><!> <!></header>`);function Re(t,r){A(r,!0);let i=(t,a=L,d)=>{let f=m(()=>M(d?.(),``));var h=Ae();B(h,23,a,e=>e.id,(t,a,d)=>{let m=g(()=>r.chapters.findIndex(e=>e.id===c(a).id)),h=g(()=>`${c(f)}${c(d)+1}`);var _=ke(),x=p(_),S=p(x);let C;var w=p(S),T=p(w,!0);v(w);var D=s(w,2),k=p(D,!0);v(D),v(S);var A=s(S,2),j=t=>{var r=De(),i=p(r);let s;v(r),U((e,t,n)=>{E(r,`aria-label`,e),E(r,`aria-expanded`,t),E(r,`aria-controls`,`chapter-children-${c(m)}`),r.disabled=l(),s=O(i,0,`svelte-1e78rkn`,null,s,n)},[()=>`${c(b).includes(c(a).id)?`Collapse`:`Expand`} ${c(a).label}`,()=>c(b).includes(c(a).id),()=>({expanded:c(b).includes(c(a).id)})]),e(`click`,r,()=>{o(b,c(b).includes(c(a).id)?c(b).filter(e=>e!==c(a).id):[...c(b),c(a).id],!0)}),n(t,r)};y(A,e=>{c(a).subitems?.length&&e(j)}),v(x);var M=s(x,2),N=e=>{var t=Oe();i(p(t),()=>c(a).subitems,()=>`${c(h)}.`),v(t),U(e=>{E(t,`id`,`chapter-children-${c(m)}`),E(t,`hidden`,e)},[()=>!c(b).includes(c(a).id)]),n(e,t)};y(M,e=>{c(a).subitems?.length&&e(N)}),v(_),U(()=>{C=O(S,1,`chapter-item svelte-1e78rkn`,null,C,{active:c(m)===r.currentChapterIndex}),E(S,`aria-current`,c(m)===r.currentChapterIndex?`location`:void 0),S.disabled=l(),u(T,c(h)),u(k,c(a).label)}),e(`click`,S,()=>{r.onChapterSelect(c(m)),r.onChapterMenuChange(!1)}),n(t,_)}),v(h),n(t,h)},a=_(r,`readerTheme`,3,`inherit`),l=_(r,`busy`,3,!1),d=_(r,`settingsOpen`,3,!1),f=_(r,`immersive`,3,!1),b=h(P([])),C=g(()=>{let e=new Set(r.chapters.flatMap(e=>e.subitems?.map(e=>e.id)??[]));return r.chapters.filter(t=>!e.has(t.id))});function w(e){return e.subitems?.some(e=>e.id===r.chapters[r.currentChapterIndex]?.id||w(e))??!1}function T(){r.chapterMenuOpen||o(b,[...new Set([...c(b),...r.chapters.filter(w).map(e=>e.id)])],!0),r.onChapterMenuChange(!r.chapterMenuOpen)}var D=Le();let k;var j=p(D),N=t=>{var i=Pe(),o=p(i),c=s(o,2),m=s(c,2),h=p(m),g=p(h,!0);v(h);var _=s(h,2),b=e=>{var t=je(),i=p(t,!0);v(t),U(()=>u(i,r.chapterTitle)),n(e,t)};y(_,e=>{r.chapterTitle&&e(b)}),v(m);var C=s(m,2),w=p(C),D=t=>{var i=Me();e(`click`,i,function(...e){r.onFeatures?.apply(this,e)}),n(t,i)};y(w,e=>{r.onFeatures&&e(D)});var O=s(w,2),k=t=>{var i=Ne(),a=s(p(i),2),o=p(a);o.value=o.__value=`scroll`;var c=s(o);c.value=c.__value=`single`;var u=s(c);u.value=u.__value=`spread`;var d=s(u);d.value=d.__value=`best-fit`,v(a);var f;x(a),v(i),U(()=>{a.disabled=l(),f!==(f=r.displayMode)&&(a.value=(a.__value=r.displayMode)??``,S(a,r.displayMode))}),e(`change`,a,e=>{let t=e.currentTarget.value;(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)&&r.onDisplayModeChange?.(t)}),n(t,i)};y(O,e=>{r.displayMode&&r.onDisplayModeChange&&e(k)});var A=s(O,2),j=e=>{ce(e,{get open(){return d()},get onOpenChange(){return r.onSettingsOpenChange},get bookTheme(){return a()},get onBookThemeChange(){return r.onReaderThemeChange},get disabled(){return l()}})};y(A,e=>{r.onReaderThemeChange&&r.onSettingsOpenChange&&e(j)}),v(C);var M=s(C,2),N=e=>{W(e,{get immersive(){return f()},get disabled(){return l()},get onclick(){return r.onImmersiveChange}})};y(M,e=>{r.onImmersiveChange&&e(N)}),v(i),U(()=>{E(c,`aria-expanded`,r.chapterMenuOpen),c.disabled=l(),u(g,r.bookTitle)}),e(`click`,o,function(...e){r.onClose?.apply(this,e)}),e(`click`,c,T),n(t,i)},F=e=>{var t=Fe(),i=p(t),a=p(i),o=p(a,!0);v(a);var c=s(a,2),l=e=>{var t=je(),i=p(t,!0);v(t),U(()=>u(i,r.chapterTitle)),n(e,t)};y(c,e=>{r.chapterTitle&&e(l)}),v(i),v(t),U(()=>u(o,r.bookTitle)),n(e,t)};y(j,e=>{r.controlsVisible?e(N):e(F,-1)});var I=s(j,2),z=t=>{var a=Ie(),o=p(a),l=s(p(o),2);v(o);var u=s(o,2);i(p(u),()=>c(C)),v(u),v(a),e(`click`,l,()=>r.onChapterMenuChange(!1)),n(t,a)};y(I,e=>{r.controlsVisible&&r.chapterMenuOpen&&e(z)}),v(D),U(()=>k=O(D,1,`reading-header svelte-1e78rkn`,null,k,{"controls-visible":r.controlsVisible})),n(t,D),R()}T([`click`,`change`]);var ze=d(`<div role="group"><div class="popup-heading svelte-4847e9"><span> </span> <output> </output></div> <div class="adjustment-row svelte-4847e9"><button class="adjust-button svelte-4847e9" type="button">-</button> <input type="range" class="svelte-4847e9"/> <button class="adjust-button svelte-4847e9" type="button">+</button></div></div>`);function Be(t,r){A(r,!0);let i=_(r,`align`,3,`left`),a=h(null),l=null,d=g(()=>c(a)??r.value);function f(e){o(a,e,!0),r.onPreview?.(e)}function m(e){e.key===`Escape`&&(e.preventDefault(),e.stopPropagation(),r.onEscape())}k(()=>r.onPreview?.(null));var y=ze();let x;var S=p(y),C=p(S),T=p(C,!0);v(C);var D=s(C,2),j=p(D,!0);v(D),v(S);var M=s(S,2),N=p(M),P=s(N,2);b(P);var F=s(P,2);v(M),v(y),U((e,t)=>{x=O(y,1,`adjustment-popup svelte-4847e9`,null,x,{"align-right":i()===`right`,"align-center":i()===`center`}),E(y,`id`,r.id),E(y,`aria-label`,`${r.label} adjustment`),u(T,r.label),u(j,e),E(N,`aria-label`,r.decreaseLabel),N.disabled=r.disabled||r.decreaseDisabled,E(P,`min`,r.min),E(P,`max`,r.max),E(P,`step`,r.step),z(P,c(d)),E(P,`aria-label`,r.label),E(P,`aria-valuetext`,t),P.disabled=r.disabled,E(F,`aria-label`,r.increaseLabel),F.disabled=r.disabled||r.increaseDisabled},[()=>r.format(c(d)),()=>r.valueText(c(d))]),e(`click`,N,function(...e){r.onDecrease?.apply(this,e)}),e(`keydown`,N,m),e(`pointerdown`,P,e=>{l=e.currentTarget.valueAsNumber}),e(`input`,P,e=>{f(e.currentTarget.valueAsNumber)}),e(`pointerup`,P,e=>{e.currentTarget.valueAsNumber===l&&f(null),l=null}),w(`pointercancel`,P,()=>{l=null,f(null)}),e(`change`,P,async e=>{try{await r.onChange(e.currentTarget.valueAsNumber)}finally{f(null)}}),e(`keydown`,P,m),e(`click`,F,function(...e){r.onIncrease?.apply(this,e)}),e(`keydown`,F,m),n(t,y),R()}T([`click`,`keydown`,`pointerdown`,`input`,`pointerup`,`change`]);var Ve=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><text x="1" y="21" font-size="21" class="svelte-5cwycy">A</text><text x="19" y="21" font-size="13" class="svelte-5cwycy">A</text></svg>`),He=r(`<svg aria-hidden="true" viewBox="0 0 32 24" class="svelte-5cwycy"><path d="M5 3v18M2 6l3-3 3 3M2 18l3 3 3-3M13 4h16M13 9h16M13 15h16M13 20h16" class="svelte-5cwycy"></path></svg>`),Ue=d(`<div class="typography-control reader-adjustment-control svelte-5cwycy"><button class="control-button typography-trigger svelte-5cwycy" type="button"><!></button> <!></div>`);function We(t,r){A(r,!0);let i,a=g(()=>r.kind===`font-size`?`Font size`:`Line height`),o=g(()=>`reader-${r.kind}-popup`);function l(e){r.open&&(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),r.onClose(),i.focus())}function u(e){r.onChange(Math.min(r.max,Math.max(r.min,Math.round((r.value+e)*100)/100)))}var d=Ue(),f=p(d),m=p(f),h=e=>{n(e,Ve())},_=e=>{n(e,He())};y(m,e=>{r.kind===`font-size`?e(h):e(_,-1)}),v(f),j(f,e=>i=e,()=>i);var b=s(f,2),x=e=>{{let t=g(()=>`Decrease ${c(a).toLowerCase()}`),n=g(()=>`Increase ${c(a).toLowerCase()}`),i=g(()=>r.value<=r.min),s=g(()=>r.value>=r.max),d=g(()=>r.kind===`line-height`?`right`:`left`);Be(e,{get id(){return c(o)},get label(){return c(a)},get value(){return r.value},get min(){return r.min},get max(){return r.max},step:.01,format:e=>`${e.toFixed(2)}x`,valueText:e=>`${e.toFixed(2)} times`,get decreaseLabel(){return c(t)},get increaseLabel(){return c(n)},get disabled(){return r.disabled},get decreaseDisabled(){return c(i)},get increaseDisabled(){return c(s)},get align(){return c(d)},onDecrease:()=>u(-.1),onIncrease:()=>u(.1),get onChange(){return r.onChange},onEscape:()=>l()})}};y(b,e=>{r.open&&e(x)}),v(d),U(()=>{E(f,`aria-label`,c(a)),E(f,`aria-expanded`,r.open),E(f,`aria-controls`,r.open?c(o):void 0),E(f,`title`,c(a)),f.disabled=r.disabled}),e(`click`,f,function(...e){r.onToggle?.apply(this,e)}),e(`keydown`,f,l),n(t,d),R()}T([`click`,`keydown`]);var Ge=d(`<div class="control-group line-height-controls svelte-1tz9bb9"><!></div>`),Ke=d(`<div class="footer-content controls-mode svelte-1tz9bb9"><div class="control-group font-controls svelte-1tz9bb9"><!></div> <div class="control-group progress-controls svelte-1tz9bb9"><div class="progress-slider reader-adjustment-control svelte-1tz9bb9"><div class="progress-thumb-focus svelte-1tz9bb9"><button class="progress-thumb svelte-1tz9bb9" type="button"> </button></div> <!></div></div> <!></div>`),qe=d(`<div class="footer-content passive-mode svelte-1tz9bb9"><div class="passive-footer-shell svelte-1tz9bb9"><p class="passive-footer-metric svelte-1tz9bb9"> </p></div></div>`),Je=d(`<footer><!></footer>`);function Ye(r,i){A(i,!0);let a=_(i,`lineHeight`,3,1),l=_(i,`chapterPositionLabel`,3,void 0),d=_(i,`previousPageDisabled`,3,!1),m=_(i,`nextPageDisabled`,3,!1),b=_(i,`chapterMenuOpen`,3,!1),x=_(i,`openControl`,15,null),S=_(i,`busy`,3,!1),C=h(null),T=h(void 0),D=g(()=>c(C)??i.progressPercent);function k(e){x(x()===e?null:e),x()&&i.onAdjustmentOpen?.()}function M(e){x()&&e.target instanceof Element&&!e.target.closest(`.reader-adjustment-control`)&&x(null)}function N(e){(!e||e.key===`Escape`)&&(e?.preventDefault(),e?.stopPropagation(),x(null),c(T)?.focus())}t(()=>{(!i.controlsVisible||b())&&x(null)});var P=Je();w(`pointerdown`,f,M),w(`blur`,f,()=>x(null));let F;var I=p(P),L=t=>{var r=Ke(),f=p(r),h=p(f);{let e=g(()=>x()===`font-size`);We(h,{kind:`font-size`,get value(){return i.fontSize},min:.75,max:2,get open(){return c(e)},get disabled(){return S()},onToggle:()=>k(`font-size`),onClose:()=>x(null),get onChange(){return i.onFontSizeChange}})}v(f);var _=s(f,2),b=p(_),w=p(b),O=p(w),A=p(O);v(O),j(O,e=>o(T,e),()=>c(T)),v(w);var M=s(w,2),P=e=>{{let t=g(()=>S()||!i.onProgressChange),n=g(()=>!i.onPreviousPage||d()),r=g(()=>!i.onNextPage||m());Be(e,{id:`reader-progress-popup`,label:`Reading position`,get value(){return i.progressPercent},min:0,max:100,step:1,align:`center`,format:e=>`${Math.round(e)}%`,valueText:e=>`${Math.round(e)}% of book`,decreaseLabel:`Previous page`,increaseLabel:`Next page`,get disabled(){return c(t)},get decreaseDisabled(){return c(n)},get increaseDisabled(){return c(r)},onDecrease:()=>i.onPreviousPage?.(),onIncrease:()=>i.onNextPage?.(),onChange:e=>i.onProgressChange?.(e),onPreview:e=>o(C,e,!0),onEscape:()=>N()})}};y(M,e=>{x()===`progress`&&e(P)}),v(b),v(_);var F=s(_,2),I=e=>{var t=Ge(),r=p(t);{let e=g(()=>x()===`line-height`);We(r,{kind:`line-height`,get value(){return a()},min:1,max:2,get open(){return c(e)},get disabled(){return S()},onToggle:()=>k(`line-height`),onClose:()=>x(null),get onChange(){return i.onLineHeightChange}})}v(t),n(e,t)};y(F,e=>{i.onLineHeightChange&&e(I)}),v(r),U((e,t)=>{E(b,`title`,`${l()??`${i.currentChapterIndex+1} / ${i.totalChapters}`}: ${i.pageLabel}`),E(O,`aria-label`,e),E(O,`aria-expanded`,x()===`progress`),E(O,`aria-controls`,x()===`progress`?`reader-progress-popup`:void 0),O.disabled=S()||!i.onProgressChange,u(A,`${t??``}%`)},[()=>`Reading position, ${Math.round(c(D))}% of book`,()=>Math.round(c(D))]),e(`click`,O,()=>k(`progress`)),e(`keydown`,O,N),n(t,r)},z=e=>{var t=qe(),r=p(t),a=p(r),o=p(a,!0);v(a),v(r),v(t),U(()=>u(o,i.progressLabel)),n(e,t)};y(I,e=>{i.controlsVisible?e(L):e(z,-1)}),v(P),U(()=>F=O(P,1,`reading-footer svelte-1tz9bb9`,null,F,{"controls-visible":i.controlsVisible})),n(r,P),R()}T([`click`,`keydown`]);var Xe=d(`<p class="chapter-title svelte-v52sy3"> </p>`),Ze=d(`<p>Find the Greek words in any of eight directions, including backward. Grid letters omit accents and breathing marks.</p>`),Qe=d(`<p>Use the English clues to fill in the Greek words. Accents and breathing marks are not required.</p>`),Z=d(`<p>Write the English meaning and its letter beside each Greek word.</p>`),$e=d(`<td class="svelte-v52sy3"><span class="svelte-v52sy3"> </span></td>`),et=d(`<tr></tr>`),tt=d(`<li class="svelte-v52sy3"> </li>`),nt=d(`<div class="word-search-layout svelte-v52sy3"><table class="word-search-grid svelte-v52sy3" lang="el" aria-label="Greek word search"><tbody></tbody></table> <section class="word-search-vocabulary svelte-v52sy3"><h2 class="svelte-v52sy3">Words to find</h2> <ul class="word-search-words svelte-v52sy3" lang="el"></ul></section></div>`),rt=d(`<li class="svelte-v52sy3"><strong> </strong> </li>`),it=d(`<section><h2 class="svelte-v52sy3"> </h2> <ul class="svelte-v52sy3"></ul></section>`),at=d(`<span class="svelte-v52sy3"> </span>`),ot=d(`<td class="crossword-cell svelte-v52sy3"></td>`),st=d(`<td class="crossword-empty svelte-v52sy3"></td>`),ct=d(`<div class="crossword-layout svelte-v52sy3"><div class="crossword-clues svelte-v52sy3"></div> <table class="crossword-grid svelte-v52sy3" aria-label="Blank Greek crossword"><tbody></tbody></table></div>`),lt=d(`<li class="prompt-row svelte-v52sy3"><span class="greek-word svelte-v52sy3"> </span><span class="meaning-blank svelte-v52sy3"></span><span class="letter-box svelte-v52sy3"></span><span class="result-space"></span></li>`),ut=d(`<li class="choice-row svelte-v52sy3"><span class="choice-letter svelte-v52sy3"> </span><span> </span></li>`),dt=d(`<div class="matching-columns svelte-v52sy3"><section><h2 class="svelte-v52sy3">Greek words</h2><ul class="svelte-v52sy3"></ul></section> <section><h2 class="svelte-v52sy3">English meanings</h2><ul class="svelte-v52sy3"></ul></section></div>`),ft=d(`<section class="worksheet-print svelte-v52sy3" aria-label="Printable worksheet"><!> <h1 class="svelte-v52sy3"> </h1> <!> <p>Name: ________________________ Date: ______________</p> <!></section>`);function pt(e,t){A(t,!0);var r=ft(),i=p(r),o=e=>{var r=Xe(),i=p(r,!0);v(r),U(()=>u(i,t.activity.chapterTitle)),n(e,r)};y(i,e=>{t.activity.chapterTitle&&e(o)});var l=s(i,2),d=p(l,!0);v(l);var f=s(l,2),m=e=>{n(e,Ze())},h=e=>{n(e,Qe())},g=e=>{n(e,Z())};y(f,e=>{t.activity.kind===`word-search-v1`?e(m):t.activity.kind===`crossword-v1`?e(h,1):e(g,-1)});var _=s(f,4),b=e=>{var r=nt(),i=p(r),a=p(i);B(a,21,()=>t.activity.grid,H,(e,t)=>{var r=et();B(r,21,()=>[...c(t)],H,(e,t)=>{var r=$e(),i=p(r),a=p(i,!0);v(i),v(r),U(()=>u(a,c(t))),n(e,r)}),v(r),n(e,r)}),v(a),v(i);var o=s(i,2),l=s(p(o),2);B(l,21,()=>t.activity.words,e=>e.id,(e,t)=>{var r=tt(),i=p(r,!0);v(r),U(()=>u(i,c(t).text)),n(e,r)}),v(l),v(o),v(r),n(e,r)},x=e=>{var r=ct(),i=p(r);B(i,20,()=>[`across`,`down`],H,(e,r)=>{var i=it(),a=p(i),o=p(a,!0);v(a);var l=s(a,2);B(l,21,()=>t.activity.clues.filter(e=>e.direction===r),e=>e.id,(e,t)=>{var r=rt(),i=p(r),a=p(i);v(i);var o=s(i);v(r),U(()=>{u(a,`${c(t).number??``}.`),u(o,` ${c(t).text??``}`)}),n(e,r)}),v(l),v(i),U(()=>u(o,r===`across`?`Across`:`Down`)),n(e,i)}),v(i);var o=s(i,2),l=p(o);B(l,21,()=>t.activity.cells,H,(e,r,i)=>{var o=et();B(o,21,()=>c(r),H,(e,r,o)=>{var s=V(),l=a(s),d=e=>{var r=ot();B(r,21,()=>t.activity.clues.filter(e=>e.row===i&&e.column===o).slice(0,1),H,(e,t)=>{var r=at(),i=p(r,!0);v(r),U(()=>u(i,c(t).number)),n(e,r)}),v(r),n(e,r)},f=e=>{n(e,st())};y(l,e=>{c(r)?e(d):e(f,-1)}),n(e,s)}),v(o),n(e,o)}),v(l),v(o),v(r),U(()=>E(o,`lang`,t.activity.language)),n(e,r)},S=e=>{var r=dt(),i=p(r),a=s(p(i));B(a,21,()=>t.activity.prompts,e=>e.id,(e,t)=>{var r=lt(),i=p(r),a=p(i,!0);v(i),C(3),v(r),U(()=>{E(i,`lang`,c(t).language),u(a,c(t).text)}),n(e,r)}),v(a),v(i);var o=s(i,2),l=s(p(o));B(l,23,()=>t.activity.choices,e=>e.id,(e,t,r)=>{var i=ut(),a=p(i),o=p(a,!0);v(a);var l=s(a),d=p(l,!0);v(l),v(i),U(e=>{u(o,e),E(l,`lang`,c(t).language),u(d,c(t).text)},[()=>me(c(r))]),n(e,i)}),v(l),v(o),v(r),n(e,r)};y(_,e=>{t.activity.kind===`word-search-v1`?e(b):t.activity.kind===`crossword-v1`?e(x,1):e(S,-1)}),v(r),U(()=>u(d,t.activity.title)),n(e,r),R()}var mt=d(`<li class="svelte-5ift61"><strong> </strong>: <!></li>`),ht=d(`<p role="alert" class="svelte-5ift61"> </p>`),gt=d(`<button type="button" class="svelte-5ift61">Close without saving</button>`),_t=d(`<dialog class="reader-feature-notice svelte-5ift61" aria-labelledby="reader-feature-title" aria-describedby="reader-feature-message"><h2 id="reader-feature-title" class="svelte-5ift61"> </h2> <p id="reader-feature-message" class="svelte-5ift61"> </p> <a target="_blank" rel="noopener noreferrer" class="svelte-5ift61">Visit Study Cheetah (opens in a new tab)</a> <h3 class="svelte-5ift61">Features requested by this book</h3> <ul class="svelte-5ift61"></ul> <p class="svelte-5ift61">Active means the reader's enhancement is enabled. Each activity is validated when opened.</p> <p class="svelte-5ift61">Unavailable enhancements keep their ordinary book content. This link opens the reader website; it does not upload your book.</p> <label class="svelte-5ift61"><input type="checkbox" class="svelte-5ift61"/> Don't show this again for this book's current features</label> <!> <div class="actions svelte-5ift61"><!> <button type="button" class="svelte-5ift61">Continue reading</button></div></dialog>`);function vt(t,r){A(r,!0);let i,a=h(!1),d=h(null),f=ye.getInstance();function m(e){console.error(`[Reader] Saving or loading enhancement notice preference failed:`,e),o(d,`Could not remember your notice preference: ${e instanceof Error?e.message:String(e)}`)}function _(){try{f.setReaderNoticeDismissed(r.capability,c(a)),o(d,null),i.close()}catch(e){m(e)}}F(()=>{try{o(a,f.isReaderNoticeDismissed(r.capability),!0)}catch(e){m(e)}r.onready(()=>{i.open||i.showModal()}),(c(d)||!c(a)&&r.capability.requested.some(e=>!r.capability.active.includes(e)))&&i.showModal()});var x=_t(),S=p(x),w=p(S,!0);v(S);var T=s(S,2),D=p(T,!0);v(T);var O=s(T,2),k=s(O,4);B(k,20,()=>r.capability.requested,e=>e,(e,t)=>{var i=mt(),a=p(i),o=p(a,!0);v(a);var d=s(a,2),f=e=>{n(e,l(`Active`))},m=g(()=>r.capability.active.includes(t)),h=e=>{n(e,l(`Supported, not active`))},_=g(()=>r.capability.supported.includes(t)),b=e=>{n(e,l(`Not supported by this reader yet`))};y(d,e=>{c(m)?e(f):c(_)?e(h,1):e(b,-1)}),v(i),U(()=>u(o,t)),n(e,i)}),v(k);var M=s(k,6),N=p(M);b(N),C(),v(M);var P=s(M,2),L=e=>{var t=ht(),r=p(t,!0);v(t),U(()=>u(r,c(d))),n(e,t)};y(P,e=>{c(d)&&e(L)});var z=s(P,2),V=p(z),H=t=>{var r=gt();e(`click`,r,()=>i.close()),n(t,r)};y(V,e=>{c(d)&&e(H)});var ee=s(V,2);v(z),v(x),j(x,e=>i=e,()=>i),U(()=>{u(w,r.capability.notice.title),u(D,r.capability.notice.message),E(O,`href`,r.capability.notice.url)}),I(N,()=>c(a),e=>o(a,e)),e(`click`,ee,_),n(t,x),R()}T([`click`]);var yt=`body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
  padding-block: 0.5rem;\r
}\r
[data-study-cheetah-enhanced="matching-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-height: 0;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced] > h1 { text-align: center; }\r
body > [data-study-cheetah-enhanced="matching-v1"] > h1 { margin-block-start: 0; }\r
[data-study-cheetah-enhanced="matching-v1"] [data-study-cheetah-matching-instructions] { display: none; }\r
[data-study-cheetah-enhanced] .matching-columns {\r
  display: grid;\r
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);\r
  gap: clamp(0.75em, 3vw, 2em);\r
  flex: 1 1 auto;\r
  min-height: 6em;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section {\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section > h2 { text-decoration: underline; }\r
[data-study-cheetah-enhanced] [data-matching-prompts],\r
[data-study-cheetah-enhanced] [data-matching-choices] {\r
  display: grid;\r
  reading-flow: grid-order;\r
  align-content: start;\r
  gap: 0.4em;\r
  min-height: 0;\r
  padding: 4px;\r
  margin: 0;\r
  list-style: none;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced] li {\r
  box-sizing: border-box;\r
  position: relative;\r
  min-height: 44px;\r
  padding: 0.35em;\r
  overflow-wrap: anywhere;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 1.8em 1em;\r
  align-items: center;\r
  gap: 0.4em;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li::before {\r
  content: none;\r
}\r
[data-study-cheetah-enhanced] .answer-blank {\r
  box-sizing: border-box;\r
  min-width: 1.6em;\r
  max-width: 3em;\r
  min-height: 1.6em;\r
  padding: 0 0.15em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  text-align: center;\r
  font-weight: bold;\r
  line-height: 1.5;\r
  background: var(--ui-control-bg, transparent);\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li {\r
  display: grid;\r
  grid-template-columns: 2em minmax(0, 1fr);\r
  align-items: center;\r
  column-gap: 2ch;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li::before {\r
  content: attr(data-choice-label);\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
  font-weight: bold;\r
  text-align: center;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] .answer-blank { display: none; }\r
[data-study-cheetah-enhanced] .answer-blank {\r
  white-space: normal;\r
  color: var(--reader-control-greek, var(--reader-matching-greek, var(--coloroldgreek, #0070c0)));\r
}\r
[data-study-cheetah-enhanced] .sc-match-answer { grid-column: 2; grid-row: 1; margin-inline-end: calc(2ch - 0.4em); }\r
[data-study-cheetah-enhanced] [data-matching-prompts] .answer-blank { grid-column: 3; grid-row: 1; }\r
[data-study-cheetah-enhanced] .sc-match-result { grid-column: 4; grid-row: 1; width: 1em; height: 1em; }\r
[data-study-cheetah-enhanced] .sc-match-result svg {\r
  width: 100%;\r
  height: 100%;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 3.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] [data-result="correct"] { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] [data-result="incorrect"] { color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced] .sc-match-answer { text-align: right; min-width: 0; border-bottom: 0; color: var(--reader-page-fg, inherit); }\r
[data-study-cheetah-enhanced] .sc-match-select {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  min-height: 0;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  color: var(--reader-page-fg, inherit);\r
  background: transparent;\r
}\r
[data-study-cheetah-enhanced] .sc-match-select[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); }\r
[data-study-cheetah-enhanced] ol:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] .sc-match-footer { flex: 0 0 auto; margin-top: 0.75em; font-size: 0.8em; }\r
[data-study-cheetah-enhanced] .sc-match-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer p { margin: 0; }\r
[data-study-cheetah-enhanced] .sc-match-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(6em, 1fr) minmax(0, max-content);\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced] .sc-match-status { min-width: 0; }\r
[data-study-cheetah-enhanced] .sc-match-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-match-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
[data-study-cheetah-enhanced] .sc-match-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
body:has(> [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"]) {\r
padding-inline-end: 48px;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-match-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-match-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-match-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-match-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="matching-v1"][data-study-cheetah-orientation="landscape"] .sc-match-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
`,bt=`[data-study-cheetah-enhanced] .worksheet-name { display: none; }\r
[data-study-cheetah-enhanced] .sc-activity-button {\r
  box-sizing: border-box;\r
  min-height: 44px;\r
  padding: 0.3em 0.6em;\r
  border: 1px solid var(--ui-border, currentColor);\r
  border-radius: 3px;\r
  font: inherit;\r
  font-weight: bold;\r
  color: inherit;\r
  background: var(--ui-control-bg, transparent);\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-check, .sc-crossword-check) {\r
  color: var(--reader-control-check, var(--reader-matching-correct, #166534));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-reset, .sc-word-search-reset, .sc-crossword-reset) {\r
  color: var(--reader-control-reset, var(--reader-matching-reset, #a84300));\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-print, .sc-word-search-print, .sc-crossword-print) {\r
  color: var(--reader-control-print, #000);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:hover:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-hover, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:active:not(:disabled):not(.sc-match-select):not(.sc-crossword-clue) {\r
  background: var(--ui-control-bg-active, transparent);\r
  border-color: var(--ui-border-strong, currentColor);\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:disabled { cursor: default; }\r
[data-study-cheetah-enhanced] .sc-activity-button:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 0.5em;\r
}\r
[data-study-cheetah-enhanced] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) svg {\r
  flex: 0 0 auto;\r
  width: 1.2em;\r
  height: 1.2em;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-status-compact { display: none; }\r
@media (max-width: 480px) {\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-footer-row, .sc-word-search-footer-row, .sc-crossword-footer-row) {\r
    grid-template-columns: minmax(0, 1fr) max-content;\r
  }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-status, .sc-word-search-status, .sc-crossword-status) {\r
    min-width: 0;\r
    overflow-x: auto;\r
    text-align: left;\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-full {\r
    position: absolute;\r
    width: 1px;\r
    height: 1px;\r
    overflow: hidden;\r
    clip-path: inset(50%);\r
    white-space: nowrap;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] .sc-activity-status-compact { display: inline; }\r
  body [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) {\r
    flex-wrap: nowrap;\r
    justify-content: flex-end;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button {\r
    width: 44px;\r
    min-width: 44px;\r
    padding: 0;\r
  }\r
  [data-study-cheetah-enhanced][data-study-cheetah-orientation="portrait"] :is(.sc-match-controls, .sc-word-search-controls, .sc-crossword-controls) .sc-activity-button > span {\r
    display: none;\r
  }\r
}\r
@media print {\r
  .study-cheetah-activity-ui { display: none !important; }\r
}\r
`;function xt(e,t,n){let r=e.ownerDocument;e.setAttribute(`aria-label`,e.textContent),e.textContent=``;let i=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);i.setAttribute(`viewBox`,`0 0 24 24`),i.setAttribute(`aria-hidden`,`true`),i.setAttribute(`focusable`,`false`);let a=r.createElementNS(i.namespaceURI,`path`);a.setAttribute(`d`,n),i.append(a);let o=r.createElement(`span`);o.textContent=t,e.append(i,o)}function St(e,t){let n=e.ownerDocument,r=[];function i(e,t,n){let i=e.getAttribute(t);e.setAttribute(t,n),r.push(()=>{i===null?e.removeAttribute(t):e.setAttribute(t,i)})}function a(e,t,i){let a=n.createElement(t);return a.className=`study-cheetah-activity-ui ${i}`,e.append(a),r.push(()=>a.remove()),a}function o(e,t,n){let i=a(e,`button`,`sc-activity-button`);return i.type=`button`,i.textContent=t,i.addEventListener(`click`,n),r.push(()=>i.removeEventListener(`click`,n)),i}let s=window.matchMedia(`(orientation: portrait)`),c=n.defaultView.matchMedia(`(orientation: portrait)`),l=()=>{e.setAttribute(`data-study-cheetah-orientation`,s.matches||c.matches?`portrait`:`landscape`)};i(e,`data-study-cheetah-orientation`,`portrait`),l(),s.addEventListener(`change`,l),c.addEventListener(`change`,l),r.push(()=>{s.removeEventListener(`change`,l),c.removeEventListener(`change`,l)});let u=n.createElement(`style`);return u.textContent=`${bt}\n${t}`,n.head.append(u),r.push(()=>u.remove()),{doc:n,cleanups:r,attribute:i,append:a,button:o}}function Ct(e,t,n){let{doc:r,cleanups:i,attribute:a,append:o,button:s}=St(e,yt),c=ye.getInstance(),l=[...e.querySelectorAll(`[data-matching-prompts] > li`)],u=[...e.querySelectorAll(`[data-matching-choices] > li`)],d=[...e.querySelectorAll(`[data-matching-prompts], [data-matching-choices]`)],f={},p=null,m=!1,h=0,g=!1,_=null,v=``,y={promptIds:t.prompts.map(e=>e.id),choiceIds:t.choices.map(e=>e.id)};function b(e,t,n){let r=e.querySelector(t)??o(e,`span`,n);a(r,`class`,`${r.className} ${n}`),a(r,`aria-hidden`,`true`);let s=r.textContent;return i.push(()=>{r.textContent=s}),r}try{let e=c.getMatchingProgress(n.publicationId,t);e&&(f=e.answers,m=e.submitted,h=e.attempts),y=Object.keys(f).length>0?e?.order??y:n.order??Ce(t)}catch(e){g=!0,F(e)}n.onorder?.(y);function x(e){return me(y.choiceIds.indexOf(e))}a(e,`data-study-cheetah-enhanced`,`matching-v1`);for(let t of e.querySelectorAll(`:scope > p`))t.textContent?.trim()===`Match the Greek word with the correct English translation. Write the English meaning and its letter beside each Greek word.`&&a(t,`data-study-cheetah-matching-instructions`,``);for(let[e,t]of d.entries())a(t,`tabindex`,`0`),a(t,`aria-label`,e===0?`Greek words list`:`English meanings list`);let S=l.map((e,n)=>{let r=t.prompts[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.promptIds.indexOf(r.id)};`);let i=b(e,`.matching-answer`,`sc-match-answer`),o=b(e,`.answer-blank`,`answer-blank`),c=b(e,`.matching-result`,`sc-match-result`),l=s(e,``,()=>{p=r.id,v=`Choose an English meaning for ${r.id}.`,L()});return l.classList.add(`sc-match-select`),l.setAttribute(`aria-label`,`Greek ${r.id}: ${r.text}`),{answer:i,blank:o,result:c,control:l}}),C=u.map((e,n)=>{let r=t.choices[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.choiceIds.indexOf(r.id)};`),a(e,`data-choice-label`,x(r.id));let i=s(e,``,()=>{!p||g||(f=ge(t,f,p,r.id),v=`Matched ${p} with ${r.text}.`,p=null,m=!1,I(),L())});return i.classList.add(`sc-match-select`),i.setAttribute(`aria-label`,`English: ${r.text}`),{control:i}}),w=o(e,`div`,`sc-match-footer`),T=o(w,`p`,`sc-match-error`);T.setAttribute(`role`,`alert`);let E=o(w,`div`,`sc-match-footer-row`),D=o(E,`p`,`sc-match-status`);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=o(D,`span`,`sc-activity-status-full`),k=o(D,`span`,`sc-activity-status-compact`);k.setAttribute(`aria-hidden`,`true`);let A=o(D,`span`,`sc-match-announcement`),j=o(E,`div`,`sc-match-controls`),M=s(j,`Check answers`,()=>{m=!0,h+=1,v=``,I(),L()});M.classList.add(`sc-match-check`);let N=s(j,`Reset answers`,()=>{try{c.deleteMatchingProgress(n.publicationId,t),f={},p=null,m=!1,g=!1,v=`Answers cleared.`,I()}catch(e){F(e)}L()});N.classList.add(`sc-match-reset`);let P=s(j,`Print worksheet`,n.onprint);P.classList.add(`sc-match-print`);for(let[e,t,n]of[[M,`Check`,`M5 12l4 4L19 6`],[N,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[P,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])xt(e,t,n);function F(e){console.error(`[Reader] Matching exercise progress:`,e),_=`Could not load or save exercise progress. ${e instanceof Error?e.message:String(e)}`}function I(){try{c.saveMatchingProgress(n.publicationId,t,{revision:t.revision,answers:f,submitted:m,attempts:h,updated:Date.now(),order:y}),_=null}catch(e){F(e)}}function L(){let e=Object.keys(f).length,n=G(t,f);O.textContent=`${m?`${n} of ${t.prompts.length} correct.${n===t.prompts.length?` Exercise complete.`:``}`:`${e} of ${t.prompts.length} matched.`} Checks: ${h}.`,k.textContent=`${m?n:e}/${t.prompts.length} ${m?`correct`:`matched`}; ${h} ${h===1?`check`:`checks`}`,A.textContent=` ${v}`,T.hidden=_===null,T.textContent=_,M.disabled=g||e===0;for(let[e,{control:n,answer:i,blank:a,result:o}]of S.entries()){let s=t.prompts[e],c=t.choices.findIndex(e=>e.id===f[s.id]),l=t.choices[c],u=m&&!!l,d=l?.answerId===s.id;if(i.textContent=l?.text??``,a.textContent=l?x(l.id):``,l?.language?i.lang=l.language:i.removeAttribute(`lang`),n.disabled=g,n.setAttribute(`aria-pressed`,String(p===s.id)),n.setAttribute(`aria-description`,`${l?`Matches ${l.text}`:`Not matched`}${u?d?` Correct`:` Incorrect`:``}`),o.replaceChildren(),u){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.setAttribute(`viewBox`,`0 0 20 20`),e.setAttribute(`data-result`,d?`correct`:`incorrect`);let t=r.createElementNS(e.namespaceURI,`path`);t.setAttribute(`d`,d?`M3 10l4 4L17 4`:`M4 4l12 12M16 4L4 16`),e.append(t),o.append(e)}}for(let[e,{control:n}]of C.entries()){let r=t.choices[e],i=Object.entries(f).find(([,e])=>e===r.id)?.[0];n.disabled=g||!p,n.setAttribute(`aria-description`,`Choice ${x(r.id)}. ${i?`Used by ${i}`:`Not used`}`)}}return L(),()=>{for(let e of i.reverse())e()}}var wt=`body:has(> [data-study-cheetah-enhanced="word-search-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
  color: inherit;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-study-cheetah-word-search-instructions] { display: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="word-search-v1"] > [data-word-search-layout] { flex-grow: 1; align-content: center; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr);\r
  gap: 0.6em 1em;\r
  align-items: start;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) {\r
  grid-template-columns: minmax(0, var(--sc-word-search-board-space, 1fr)) minmax(0, 1fr);\r
  column-gap: 10em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit][data-word-search-measure="side"] {\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] > .word-search-board {\r
  box-sizing: border-box;\r
  min-width: 0;\r
  padding: 1em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] .word-search-vocabulary {\r
  justify-self: start;\r
  width: max-content;\r
  max-width: 100%;\r
  min-width: 0;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-words], [data-word-search-words] > li) {\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-words] {\r
  font-size: 1.25em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  grid-template-columns: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) .word-search-vocabulary {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr);\r
  max-height: var(--sc-word-search-height);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  min-height: 0;\r
  padding-block: 0.15em;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .word-search-vocabulary h2 {\r
  display: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] [data-word-search-grid] {\r
  width: var(--sc-word-search-width, 100%);\r
  min-width: 0;\r
  max-width: none;\r
  margin-inline: auto;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] td > span {\r
  block-size: var(--sc-word-search-cell, auto);\r
  font-size: max(1em, var(--sc-word-search-letter, 1em));\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-cell {\r
  position: absolute;\r
  top: 0;\r
  left: 0;\r
  max-width: none;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  background: transparent;\r
  color: var(--reader-page-fg, inherit);\r
  cursor: pointer;\r
  touch-action: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-grid] { user-select: none; touch-action: none; }\r
:is([data-study-cheetah-enhanced="word-search-v1"][data-sc-word-search-overlay-host],\r
  [data-study-cheetah-enhanced="word-search-v1"] [data-sc-word-search-overlay-host]) { position: relative; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-capsules {\r
  position: absolute;\r
  pointer-events: none;\r
  overflow: visible;\r
}\r
.sc-word-search-capsules rect { fill: none; }\r
.sc-word-search-found-capsule { stroke: var(--reader-matching-correct, #166534); }\r
.sc-word-search-selected-capsule { stroke: var(--reader-page-fg, currentColor); }\r
.sc-word-search-cell:focus-visible { outline: 2px solid currentColor; outline-offset: -3px; }\r
[data-sc-word-search-pointer-focus="true"] .sc-word-search-cell:focus-visible { outline: none; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-touch-preview {\r
  position: fixed;\r
  inset: auto;\r
  box-sizing: border-box;\r
  width: max-content;\r
  max-width: calc(100vw - 1rem);\r
  margin: 0;\r
  padding: 0.3em 0.75em;\r
  border: 2px solid currentColor;\r
  border-radius: 9999px;\r
  background: var(--reader-page-bg, Canvas);\r
  color: var(--reader-page-fg, CanvasText);\r
  font-size: max(1.25em, var(--sc-word-search-letter, 1em));\r
  line-height: 1.4;\r
  letter-spacing: 0.1em;\r
  text-align: center;\r
  overflow-wrap: anywhere;\r
  pointer-events: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-found-word {\r
  color: var(--reader-matching-correct, #166534);\r
  font-weight: bold;\r
  text-decoration: line-through;\r
}\r
.sc-word-search-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-word-search-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-footer p { margin: 0; }\r
.sc-word-search-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-word-search-status { min-width: 0; text-align: left; }\r
.sc-word-search-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-word-search-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
.sc-word-search-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-word-search-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-word-search-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-word-search-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-word-search-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="word-search-v1"][data-study-cheetah-orientation="landscape"] .sc-word-search-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
`;function Tt(e,t,n){let r=e.querySelector(`[data-word-search-grid]`),i=[...e.querySelectorAll(`[data-word-search-grid] td`)];if(!r||i.length!==t.grid.length*t.grid[0].length)throw Error(`The word-search grid does not match its worksheet.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l}=St(e,wt),u=r.parentElement;a.defaultView.getComputedStyle(u).position===`static`&&s(u,`data-sc-word-search-overlay-host`,``);let d=a.createElementNS(`http://www.w3.org/2000/svg`,`svg`);d.setAttribute(`class`,`study-cheetah-activity-ui sc-word-search-capsules`),d.setAttribute(`aria-hidden`,`true`),d.setAttribute(`focusable`,`false`),u.append(d),o.push(()=>d.remove());let f=ye.getInstance(),p=t.grid[0].length,m=t.grid.join(``),h=[],g=null,_=null,v=null,y=null,b=!1,x,S=!1,C=0,w=!1,T=null,E=``;function D(e){console.error(`[Reader] Word-search progress:`,e),T=`Could not load or save puzzle progress. ${e instanceof Error?e.message:String(e)}`}try{h=f.getWordSearchProgress(n.publicationId,t)?.found??[]}catch(e){w=!0,D(e)}s(e,`data-study-cheetah-enhanced`,`word-search-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Find the Greek words in any of eight directions, including backward. Grid letters are lowercase without accents or breathing marks.`,`Find words in all eight directions. Lowercase grid letters omit accents.`].includes(t.textContent?.trim()??``)&&s(t,`data-study-cheetah-word-search-instructions`,``);s(r,`role`,`grid`),s(r,`aria-rowcount`,String(t.grid.length)),s(r,`aria-colcount`,String(p)),s(r,`aria-description`,`Drag from the first letter to the last, or tap both ends. Keyboard: use arrow keys, Enter or Space to select each end, and Escape to cancel.`),s(r,`data-sc-word-search-pointer-focus`,`false`);let O=i.map((e,t)=>{s(e,`role`,`gridcell`);let n=e.querySelector(`span`);n&&s(n,`aria-hidden`,`true`);let r=c(e,`button`,`sc-word-search-cell`);return r.type=`button`,r.dataset.cellIndex=String(t),r.setAttribute(`aria-label`,`Row ${Math.floor(t/p)+1}, column ${t%p+1}: ${m[t]}`),r}),k=c(e,`div`,`sc-word-search-touch-preview`);k.popover=`manual`,k.lang=`el`,k.setAttribute(`aria-hidden`,`true`),k.hidden=!0;let A=c(e,`div`,`sc-word-search-footer`),j=c(A,`div`,`sc-word-search-footer-row`),M=c(j,`p`,`sc-word-search-status`);M.setAttribute(`role`,`status`),M.setAttribute(`aria-live`,`polite`);let N=c(M,`span`,`sc-activity-status-full`),P=c(M,`span`,`sc-activity-status-compact`);P.setAttribute(`aria-hidden`,`true`);let F=c(M,`span`,`sc-word-search-announcement`),I=c(A,`p`,`sc-word-search-error`);I.setAttribute(`role`,`alert`);let L=c(j,`div`,`sc-word-search-controls`),R=l(L,`Reset puzzle`,()=>{re();try{f.deleteWordSearchProgress(n.publicationId,t),h=[],g=null,w=!1,E=`Found words cleared.`,H()}catch(e){D(e)}pe()});R.classList.add(`sc-word-search-reset`);let z=l(L,`Print worksheet`,n.onprint);z.classList.add(`sc-word-search-print`),xt(R,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`),xt(z,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`);let B=c(A,`p`,``),V=[...e.querySelectorAll(`[data-word-search-words] > li`)];for(let e of V)s(e,`class`,e.className);function H(){try{f.saveWordSearchProgress(n.publicationId,t,{revision:t.revision,puzzle:ve(t),found:h,updated:Date.now()}),T=null}catch(e){D(e)}}function U(e,n){let r=Se(t,e,n);r?h.some(e=>e.wordId===r.id)?E=`${r.text} is already found.`:(h=[...h,{wordId:r.id,start:e,end:n}],E=`Found ${r.text}.`,H()):E=`No listed word selected. Choose a straight row, column, or diagonal.`,g=null}function ee(e){w||(C=e,g===null?(g=e,E=`First letter selected. Choose the last letter.`):U(g,e),pe())}function te(){return _!==null&&v!==null?fe(t,S?_:g??_,v)??[]:g===null?[]:[g]}function ne(){let e=r.getBoundingClientRect(),t=r.offsetWidth,n=r.offsetHeight;if(!t||!n||!e.width||!e.height){d.replaceChildren();return}d.style.width=`${t}px`,d.style.height=`${n}px`,d.setAttribute(`viewBox`,`0 0 ${t} ${n}`);let o=t/e.width,s=n/e.height,c=d.getBoundingClientRect();d.style.left=`${(Number.parseFloat(d.style.left)||0)+(e.left-c.left)*o}px`,d.style.top=`${(Number.parseFloat(d.style.top)||0)+(e.top-c.top)*s}px`;let l=a.createDocumentFragment();function u(t,n,r,c){let u=i[t].getBoundingClientRect(),f=i[n].getBoundingClientRect(),p=(u.left+u.width/2-e.left)*o,m=(u.top+u.height/2-e.top)*s,h=(f.left+f.width/2-u.left-u.width/2)*o,g=(f.top+f.height/2-u.top-u.height/2)*s,_=Math.min(u.width*o,u.height*s),v=_*.4,y=a.createElementNS(d.namespaceURI,`rect`);y.setAttribute(`class`,r),c&&y.setAttribute(`data-sc-word-id`,c),y.setAttribute(`x`,String(p-v)),y.setAttribute(`y`,String(m-v)),y.setAttribute(`width`,String(Math.hypot(h,g)+2*v)),y.setAttribute(`height`,String(2*v)),y.setAttribute(`rx`,String(v)),y.setAttribute(`stroke-width`,String(_*.08)),y.setAttribute(`transform`,`rotate(${Math.atan2(g,h)*180/Math.PI} ${p} ${m})`),l.append(y)}for(let e of h)u(e.start,e.end,`sc-word-search-found-capsule`,e.wordId);let f=te();f.length&&u(f[0],f[f.length-1],`sc-word-search-selected-capsule`),d.replaceChildren(l)}function re(){clearTimeout(x),x=void 0,k.matches(`:popover-open`)&&k.hidePopover(),k.hidden=!0,k.textContent=``}function ie(){if(k.hidden)return;let e=r.getBoundingClientRect(),t=k.getBoundingClientRect(),n=Math.max(8,Math.min(e.left+e.width/2-t.width/2,a.documentElement.clientWidth-t.width-8));k.style.left=`${n}px`,k.style.top=`${Math.max(8,e.top-t.height-8)}px`}function ae(){let e=te();if(!e.length){re();return}k.textContent=e.map(e=>m[e]).join(``),k.hidden=!1,k.matches(`:popover-open`)||k.showPopover(),ie()}function oe(e){let t=a.elementFromPoint(e.clientX,e.clientY)?.closest(`.sc-word-search-cell`);return t&&r.contains(t)?Number(t.dataset.cellIndex):null}let W=e=>{if(w||e.button!==0||y!==null)return;let t=oe(e);t!==null&&(e.preventDefault(),re(),b=e.pointerType===`touch`,_=v=t,y=e.pointerId,S=!1,C=t,r.setAttribute(`data-sc-word-search-pointer-focus`,`true`),O[t].focus({preventScroll:!0}),r.setPointerCapture(e.pointerId),pe())},se=e=>{if(e.pointerId!==y||_===null)return;let t=oe(e);t!==v&&(v=t,v!==null&&v!==_&&(S=!0),pe())},ce=e=>{if(e.pointerId!==y||_===null)return;let t=oe(e);v=t;let n=b;n&&ae(),b=!1,t===null?(g=null,E=`Selection cancelled.`):S?U(_,t):ee(t),y=_=v=null,pe(),n&&!k.hidden&&(x=setTimeout(re,1e3))},le=e=>{e&&e.pointerId!==y||(b=!1,re(),y=_=v=g=null,pe())},G=e=>{let t=e.target.closest(`.sc-word-search-cell`);e.detail===0&&t&&(re(),ee(Number(t.dataset.cellIndex)))},K=e=>{r.setAttribute(`data-sc-word-search-pointer-focus`,`false`);let t=e.target.closest(`.sc-word-search-cell`);if(!t||e.altKey||e.ctrlKey||e.metaKey)return;let n=Number(t.dataset.cellIndex),a=n;if(e.key===`ArrowLeft`)a=n%p?n-1:n;else if(e.key===`ArrowRight`)a=n%p<p-1?n+1:n;else if(e.key===`ArrowUp`)a=Math.max(n-p,n%p);else if(e.key===`ArrowDown`)a=Math.min(n+p,i.length-p+n%p);else if(e.key===`Enter`||e.key===` `)ee(n);else if(e.key===`Escape`)le(),E=`Selection cancelled.`;else return;e.preventDefault(),C=a,pe(),O[a].focus()},ue=e=>{(!(e.relatedTarget instanceof a.defaultView.Node)||!r.contains(e.relatedTarget))&&r.setAttribute(`data-sc-word-search-pointer-focus`,`false`)};r.addEventListener(`pointerdown`,W),r.addEventListener(`pointermove`,se),r.addEventListener(`pointerup`,ce),r.addEventListener(`pointercancel`,le),r.addEventListener(`lostpointercapture`,le),r.addEventListener(`click`,G),r.addEventListener(`keydown`,K),r.addEventListener(`focusout`,ue),a.addEventListener(`scroll`,ie,!0),a.defaultView?.addEventListener(`resize`,ie),o.push(()=>{re(),r.removeEventListener(`pointerdown`,W),r.removeEventListener(`pointermove`,se),r.removeEventListener(`pointerup`,ce),r.removeEventListener(`pointercancel`,le),r.removeEventListener(`lostpointercapture`,le),r.removeEventListener(`click`,G),r.removeEventListener(`keydown`,K),r.removeEventListener(`focusout`,ue),a.removeEventListener(`scroll`,ie,!0),a.defaultView?.removeEventListener(`resize`,ie)});let de=new ResizeObserver(ne);de.observe(e),de.observe(u),de.observe(r),o.push(()=>de.disconnect());function pe(){let e=new Set(h.flatMap(e=>fe(t,e.start,e.end)??[])),n=new Set(te());ne(),b&&ae();for(let[t,r]of O.entries())r.tabIndex=t===C?0:-1,r.disabled=w,r.classList.toggle(`sc-word-search-found`,e.has(t)),r.classList.toggle(`sc-word-search-selected`,n.has(t)),r.setAttribute(`aria-pressed`,String(n.has(t))),r.setAttribute(`aria-description`,e.has(t)?`Part of a found word`:`Not found`);for(let e of V)e.classList.toggle(`sc-word-search-found-word`,h.some(t=>t.wordId===e.dataset.wordId));N.textContent=`${h.length} of ${t.words.length} words found.${h.length===t.words.length?` Puzzle complete.`:``}`,P.textContent=`${h.length}/${t.words.length} found`,F.textContent=E?` ${E}`:``,I.hidden=T===null,I.textContent=T,B.hidden=T===null,B.textContent=T?`Progress is not saved.`:``}pe();let me=e.querySelector(`:scope > [data-word-search-layout]`),q=me?.querySelector(`.word-search-vocabulary`);return me&&q&&o.push(Et(e,me,r,q,p,t.grid.length)),()=>{for(let e of o.reverse())e()}}function Et(e,t,n,r,i,a){let o=Array.from(e.children).filter(e=>e!==t),s=e=>Number.parseFloat(e)||0,c=r.querySelector(`[data-word-search-words]`),l=c.getAttribute(`tabindex`);t.dataset.wordSearchFit=`stack`;function u(){l===null?c.removeAttribute(`tabindex`):c.setAttribute(`tabindex`,l)}function d(){if(!e.clientHeight||!e.clientWidth)return;let l=getComputedStyle(e),d=o.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),f=e.clientHeight-s(l.paddingTop)-s(l.paddingBottom)-s(l.rowGap)*d.length;for(let e of d){let t=getComputedStyle(e);f-=e.getBoundingClientRect().height+s(t.marginTop)+s(t.marginBottom)}t.dataset.wordSearchMeasure=`stack`;let p=getComputedStyle(t),m=t.clientWidth,h=getComputedStyle(n.parentElement),g=s(h.paddingLeft)+s(h.paddingRight),_=s(h.paddingTop)+s(h.paddingBottom),v=f-_,y=Math.ceil(s(getComputedStyle(n).fontSize)*i),b=Math.max(y,Math.min(m-g,(v-r.offsetHeight-s(p.rowGap))*i/a));t.dataset.wordSearchMeasure=`side`;let x=s(getComputedStyle(t).columnGap),S=r.offsetWidth,C=Math.max(y,v*i/a)+g,w=m-x,T=Math.min(w-S,w*C/(C+S)),E=T-g,D=Math.max(y,Math.min(E,v*i/a));delete t.dataset.wordSearchMeasure;let O=t.dataset.wordSearchFit===`side`,k=e.clientWidth>=e.clientHeight+(O?-4:4),A=E>=y+(O?0:4)&&(D>b+4||D>=b-(O?4:0)&&k||O&&D>b),j=Math.floor(A?D:b);A!==O&&(t.dataset.wordSearchFit=A?`side`:`stack`),t.style.setProperty(`--sc-word-search-width`,`${j}px`),t.style.setProperty(`--sc-word-search-cell`,`${j/i}px`),t.style.setProperty(`--sc-word-search-letter`,`${j/i*.58}px`),t.style.setProperty(`--sc-word-search-height`,`${j*a/i}px`),t.style.setProperty(`--sc-word-search-board-space`,`${Math.max(0,T)}px`),A&&c.scrollHeight>c.clientHeight?c.tabIndex=0:u()}let f=new ResizeObserver(d);f.observe(e),f.observe(r);for(let e of o)f.observe(e);return d(),()=>{f.disconnect(),delete t.dataset.wordSearchFit,t.style.removeProperty(`--sc-word-search-width`),t.style.removeProperty(`--sc-word-search-cell`),t.style.removeProperty(`--sc-word-search-letter`),t.style.removeProperty(`--sc-word-search-height`),t.style.removeProperty(`--sc-word-search-board-space`),u()}}function Dt(e,t,n,r){let i=e.contentDocument,a=i?.defaultView,o=e.parentElement;if(!i||!a||!o)throw Error(`Activity publication frame is unavailable.`);let s=n.kind===`matching-v1`,c=s?`data-reader-matching-source`:`data-reader-word-search-source`,l=e.ownerDocument.createElement(`iframe`);l.className=s?`reader-matching-frame`:`reader-word-search-frame`,l.title=`Interactive exercise: ${n.title}`,l.style.cssText=`position:absolute;inset:0;width:100%;height:100%;border:0;`,o.append(l);let u=l.contentDocument;if(!u)throw l.remove(),Error(`Could not create the reader-owned activity frame.`);let d=u.createElement(`meta`);d.httpEquiv=`Content-Security-Policy`,d.content=`default-src 'none'; style-src 'unsafe-inline'`,u.head.append(d),u.title=n.title,u.documentElement.lang=i.documentElement.lang;let f=u.createElement(`style`);f.textContent=`
    html, body { box-sizing: border-box; margin: 0; width: 100%; height: 100%; overflow: hidden; }
    h1 { margin: 0 0 1em; font-size: 1.3em; }
    h2 { margin: 0 0 0.75em; font-size: 1.1em; }
    .word-search-board { overflow: auto; }
    [data-word-search-grid] {
      width: 100%; min-width: 0; table-layout: fixed; border-collapse: collapse; margin: 0 auto;
      color: var(--reader-matching-greek, #0070c0);
    }
    [data-word-search-grid] td { position: relative; border: 0; padding: 0; text-align: center; }
    [data-word-search-grid] td > span { display: grid; place-items: center; aspect-ratio: 1; width: 100%; line-height: 1; }
    [data-word-search-words] { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); margin: 0; padding: 0; list-style: none; gap: 0.3em 1em; }
    [data-word-search-words] > li { color: var(--reader-matching-greek, #0070c0); }
  `,u.head.append(f);let p=u.createElement(`main`);p.setAttribute(`data-study-cheetah-activity`,n.kind),p.setAttribute(`data-activity-id`,n.id),p.setAttribute(`data-activity-revision`,n.revision),n.chapterTitle&&p.setAttribute(`data-chapter-title`,n.chapterTitle),s||(p.className=`word-search`);let m=u.createElement(`h1`);m.textContent=n.title,p.append(m);for(let e of t.querySelectorAll(`:scope > p`)){if(a.getComputedStyle(e).display===`none`)continue;let t=u.createElement(`p`);t.textContent=e.textContent,p.append(t)}if(n.kind===`matching-v1`){let e=u.createElement(`div`);e.className=`matching-columns`;for(let[t,r,i]of[[`Greek words`,n.prompts,!0],[`English meanings`,n.choices,!1]]){let n=u.createElement(`section`),a=u.createElement(`h2`);a.textContent=t;let o=u.createElement(`ol`);o.setAttribute(i?`data-matching-prompts`:`data-matching-choices`,``);for(let e of r){let t=u.createElement(`li`);t.setAttribute(i?`data-match-id`:`data-choice-id`,e.id);let n=u.createElement(`span`);n.setAttribute(i?`data-prompt-text`:`data-choice-text`,``),n.textContent=e.text,e.language&&(n.lang=e.language,t.lang=e.language),t.append(n),o.append(t)}n.append(a,o),e.append(n)}p.append(e)}else{let e=u.createElement(`div`);e.setAttribute(`data-word-search-layout`,``);let t=u.createElement(`div`);t.className=`word-search-board`;let r=u.createElement(`table`);r.setAttribute(`data-word-search-grid`,``),r.setAttribute(`aria-label`,`Greek word search, ${n.grid.length} rows by ${n.grid[0].length} columns`),r.lang=`el`;let i=u.createElement(`tbody`);for(let e of n.grid){let t=u.createElement(`tr`);for(let n of e){let e=u.createElement(`td`),r=u.createElement(`span`);r.textContent=n,e.append(r),t.append(e)}i.append(t)}r.append(i),t.append(r);let a=u.createElement(`section`);a.className=`word-search-vocabulary`;let o=u.createElement(`h2`);o.textContent=`Words to find`;let s=u.createElement(`ul`);s.setAttribute(`data-word-search-words`,``),s.lang=`el`;for(let e of n.words){let t=u.createElement(`li`);t.setAttribute(`data-word-id`,e.id),t.textContent=e.text,s.append(t)}a.append(o,s),e.append(t,a),p.append(e)}u.body.append(p);let h;try{h=n.kind===`matching-v1`?Ct(p,n,r):Tt(p,n,r)}catch(e){throw l.remove(),e}let g=e.getAttribute(`aria-hidden`),_=e.getAttribute(`tabindex`),v=e.style.opacity;e.setAttribute(`aria-hidden`,`true`),e.setAttribute(`tabindex`,`-1`),e.setAttribute(c,``),e.style.opacity=`0`;let y=()=>{let e=a.getComputedStyle(i.body),n=a.getComputedStyle(i.documentElement);u.documentElement.style.fontSize=n.fontSize,u.documentElement.style.backgroundColor=n.backgroundColor;for(let t of[`width`,`height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`transform`,`transform-origin`,`font-size`,`font-family`,`line-height`,`color`,`background-color`,`--reader-page-fg`,`--reader-page-bg`,`--reader-matching-correct`,`--reader-matching-incorrect`,`--reader-matching-reset`,`--reader-matching-greek`,...ae,`--reader-control-greek`,`--reader-control-check`,`--reader-control-reset`,`--reader-control-print`])u.body.style.setProperty(t,e.getPropertyValue(t));u.body.style.lineHeight=e.lineHeight===`normal`?`normal`:String(parseFloat(e.lineHeight)/parseFloat(e.fontSize));let r=a.getComputedStyle(t);if(p.style.rowGap=r.rowGap,p.style.columnGap=r.columnGap,!s){let e=t.querySelector(`[data-word-search-words]`),n=p.querySelector(`[data-word-search-words]`),r=a.getComputedStyle(e);for(let e of[`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`row-gap`,`column-gap`])n.style.setProperty(e,r.getPropertyValue(e))}let o=[...t.querySelectorAll(`h1,h2`)];for(let[e,t]of[...p.querySelectorAll(`h1,h2`)].entries()){let n=o[e];if(!n)continue;let r=a.getComputedStyle(n);for(let e of[`font-size`,`font-family`,`font-weight`,`line-height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`])t.style.setProperty(e,r.getPropertyValue(e))}};y();let b=new MutationObserver(y);b.observe(i.head,{subtree:!0,childList:!0,characterData:!0,attributes:!0}),b.observe(i.body,{attributes:!0}),b.observe(i.documentElement,{attributes:!0});let x=new ResizeObserver(y);return x.observe(e),()=>{b.disconnect(),x.disconnect(),h(),l.remove(),e.removeAttribute(c),g===null?e.removeAttribute(`aria-hidden`):e.setAttribute(`aria-hidden`,g),_===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,_),e.style.opacity=v}}var Ot=`body:has(> [data-study-cheetah-enhanced="crossword-v1"]) {\r
  padding-block: 0.5rem;\r
  padding-inline: 48px;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: flex-start;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable both-edges;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"] > h1 { margin-block-start: 0; text-align: center; }\r
[data-study-cheetah-enhanced="crossword-v1"] [data-study-cheetah-crossword-instructions] { display: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-layout {\r
  flex-grow: 1;\r
  grid-template-columns: max-content var(--sc-crossword-width, minmax(0, 1fr));\r
  justify-content: center;\r
  align-content: center;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-grid { width: var(--sc-crossword-width, 100%); max-width: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr) minmax(0, 1fr);\r
  max-height: max(var(--sc-crossword-height), 10em);\r
  min-height: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] [data-crossword-wide="true"] .crossword-clues {\r
  grid-template-columns: max-content max-content;\r
  grid-template-rows: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues h2 { margin: 0 0 0.4em; line-height: 1.2; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: auto; min-height: 0; margin: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues li { position: relative; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue {\r
  padding: 0.1em 0.2em;\r
  border: 1px solid transparent;\r
  color: inherit;\r
  background: transparent;\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[aria-pressed="true"] { border-color: var(--ui-control-bg-active, currentColor); font-weight: bold; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="correct"]::after { content: " \\2713"; color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="incorrect"]::after { content: " \\2717"; color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-input {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  box-sizing: border-box;\r
  border: 2px solid transparent;\r
  padding: 0;\r
  background: var(--ui-control-bg, transparent);\r
  color: var(--ui-control-fg, inherit);\r
  font: inherit;\r
  font-size: 1.25em;\r
  text-align: center;\r
  cursor: text;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-number { pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-number { z-index: 1; pointer-events: none; color: var(--ui-control-fg, inherit); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-selected { background: var(--ui-control-bg-active, color-mix(in srgb, currentColor 12%, transparent)); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-current { border-color: currentColor; }\r
[data-study-cheetah-enhanced="crossword-v1"] :is(.sc-crossword-input, .sc-crossword-clue):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-crossword-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-footer p { margin: 0; }\r
.sc-crossword-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) max-content;\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
.sc-crossword-status { min-width: 0; text-align: left; }\r
.sc-crossword-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
.sc-crossword-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
.sc-crossword-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] {\r
--sc-crossword-sidebar-width: clamp(7rem, 15vw, 10rem);\r
position: relative;\r
padding-inline-end: calc(var(--sc-crossword-sidebar-width) + 1rem);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] > h1 {\r
margin-inline-end: calc(-1 * (var(--sc-crossword-sidebar-width) + 1rem));\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer {\r
position: absolute;\r
inset-block-end: 0;\r
inset-inline-end: 0;\r
width: var(--sc-crossword-sidebar-width);\r
max-height: 100%;\r
margin-top: 0;\r
overflow-y: auto;\r
overflow-wrap: anywhere;\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-footer-row {\r
grid-template-columns: minmax(0, 1fr);\r
}\r
body > [data-study-cheetah-enhanced="crossword-v1"][data-study-cheetah-orientation="landscape"] .sc-crossword-controls {\r
flex-direction: column;\r
flex-wrap: nowrap;\r
}\r
`;function kt(e,t,n){let r=e.querySelector(`.crossword-grid`),i=[...e.querySelectorAll(`[data-entry-id]`)];if(!r||i.length!==t.clues.length)throw Error(`Crossword worksheet does not match its clues.`);let{cleanups:a,attribute:o,append:s,button:c}=St(e,Ot),l=ye.getInstance(),u={},d=t.clues[0],f=J(d)[0],p=d.direction,m=!1,h=0,g=!1,_=null,v=``,y=new Map;function b(e){console.error(`[Reader] Crossword progress:`,e),_=`Could not load or save crossword progress. ${e instanceof Error?e.message:String(e)}`}try{let e=l.getCrosswordProgress(n.publicationId,t);e&&(u=e.letters,m=e.submitted,h=e.attempts)}catch(e){g=!0,b(e)}o(e,`data-study-cheetah-enhanced`,`crossword-v1`);for(let t of e.querySelectorAll(`:scope > p`))[`Use the English clues to fill in the Greek words. Accents and breathing marks are not required.`,`Use the English clues to fill in the Greek words. Include accents and breathing marks.`,`Fill in the Greek words.`].includes(t.textContent?.trim()??``)&&o(t,`data-study-cheetah-crossword-instructions`,``);o(r,`role`,`grid`),o(r,`aria-description`,`Select a clue or square, then type Greek letters. Click a selected crossing again or press Enter to change direction. Use arrow keys to move.`);let x=i.map((e,n)=>{let r=t.clues[n];for(let t of e.children)o(t,`hidden`,``);let i=c(e,`${r.number}. ${r.text}`,()=>{S(r,J(r)[0],!0)});return i.classList.add(`sc-crossword-clue`),i});function S(e,t,n){if(d=e,p=e.direction,f=t,v=`${e.number} ${e.direction}: ${e.text}.`,L(),n){let e=y.get(t);e?.focus(),e?.select()}}function C(e,n){let r=t.clues.filter(t=>J(t).includes(e)),i=r.find(e=>e.direction===p),a=r.find(e=>e.direction!==p),o=(n&&e===f?a:i)??i??a;o&&S(o,e,!1)}function w(){try{l.saveCrosswordProgress(n.publicationId,t,{revision:t.revision,puzzle:be(t),letters:u,submitted:m,attempts:h,updated:Date.now()}),_=null}catch(e){b(e)}}for(let[n,i]of t.cells.entries())for(let[c,l]of i.entries()){if(!l)continue;let i=r.rows[n].cells[c],h=q(n,c);o(i,`role`,`gridcell`);let _=s(i,`input`,`sc-crossword-input`);_.type=`text`,_.lang=t.language,_.autocomplete=`off`,_.spellcheck=!1,_.dataset.crosswordCell=h,y.set(h,_);let b=!1,x=()=>{b=h===f&&e.ownerDocument.activeElement===_},S=()=>{h!==f&&C(h,!1),_.select()},T=()=>{b&&C(h,!0),b=!1,_.select()},E=e=>{if(h!==f||g)return;if(!e)delete u[h];else try{u[h]=ue(e)}catch{v=`Enter one Greek letter per square.`,L(),_.select();return}m=!1,v=``,w();let t=J(d),n=t[t.indexOf(h)+1];e&&n&&(f=n),L(),e&&n?y.get(n)?.focus():_.select()},D=e=>{if(`isComposing`in e&&!e.isComposing&&`inputType`in e&&(e.inputType===`insertText`||e.inputType===`insertReplacementText`)&&`data`in e&&typeof e.data==`string`&&e.data)return e.data},O=e=>{let t=D(e);!e.cancelable||t===void 0||(e.preventDefault(),E(t))},k=e=>{if(!(`isComposing`in e&&e.isComposing)){if(h!==f){_.value=u[h]??``;return}E(D(e)??_.value)}},A=e=>{e.data?E(e.data):(_.value=u[h]??``,h===f&&_.select())},j=e=>{if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;if(e.key===`Enter`){e.preventDefault(),C(h,!0);return}let r={ArrowLeft:[0,-1,`across`],ArrowRight:[0,1,`across`],ArrowUp:[-1,0,`down`],ArrowDown:[1,0,`down`]}[e.key];if(!r)return;e.preventDefault();let[i,a,o]=r;for(let e=n+i,r=c+a;e>=0&&e<t.rows&&r>=0&&r<t.columns;e+=i,r+=a){let t=q(e,r);if(y.has(t)){p=o,C(t,!1),y.get(t)?.focus();break}}};_.addEventListener(`pointerdown`,x),_.addEventListener(`focus`,S),_.addEventListener(`click`,T),_.addEventListener(`beforeinput`,O),_.addEventListener(`input`,k),_.addEventListener(`compositionend`,A),_.addEventListener(`keydown`,j),a.push(()=>{_.removeEventListener(`pointerdown`,x),_.removeEventListener(`focus`,S),_.removeEventListener(`click`,T),_.removeEventListener(`beforeinput`,O),_.removeEventListener(`input`,k),_.removeEventListener(`compositionend`,A),_.removeEventListener(`keydown`,j)})}let T=s(e,`div`,`sc-crossword-footer`),E=s(T,`div`,`sc-crossword-footer-row`),D=s(E,`p`,`sc-crossword-status`);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=s(D,`span`,`sc-activity-status-full`),k=s(D,`span`,`sc-activity-status-compact`);k.setAttribute(`aria-hidden`,`true`);let A=s(D,`span`,`sc-crossword-announcement`),j=s(T,`p`,`sc-crossword-error`);j.setAttribute(`role`,`alert`);let M=s(E,`div`,`sc-crossword-controls`),N=c(M,`Check answers`,()=>{m=!0,h++,v=``,w(),L()});N.classList.add(`sc-crossword-check`);let P=c(M,`Reset puzzle`,()=>{try{l.deleteCrosswordProgress(n.publicationId,t),u={},m=!1,h=0,g=!1,v=`Answers cleared.`,w()}catch(e){b(e)}L()});P.classList.add(`sc-crossword-reset`);let F=c(M,`Print worksheet`,n.onprint);F.classList.add(`sc-crossword-print`);for(let[e,t,n]of[[N,`Check`,`M5 12l4 4L19 6`],[P,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[F,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]])xt(e,t,n);let I=s(T,`p`,`sc-crossword-save-status`);function L(){let e=J(d),n=t.clues.filter(e=>K(e,u)).length;O.textContent=m?`${n} of ${t.clues.length} correct.${n===t.clues.length?` Puzzle complete.`:``}`:`${Object.keys(u).length} of ${y.size} squares filled. Not checked.`,k.textContent=m?`${n}/${t.clues.length} OK`:`${Object.keys(u).length}/${y.size} set`,A.textContent=v?` ${v}`:``,j.hidden=_===null,j.textContent=_,I.hidden=_===null,I.textContent=_?`Progress is not saved.`:``,N.disabled=g||Object.keys(u).length===0,x.forEach((e,n)=>{e.disabled=g,e.setAttribute(`aria-pressed`,String(t.clues[n].id===d.id));let r=t.clues[n],i=J(r),a=m&&i.some(e=>u[e])?K(r,u)?`correct`:`incorrect`:``;e.dataset.result=a,e.setAttribute(`aria-description`,a===`correct`?`Correct`:a===`incorrect`?`Not correct`:`Not checked`)});for(let[n,r]of y){let[i,a]=n.split(`,`).map(Number),o=u[n]??``;r.value!==o&&(r.value=o),r.disabled=g,r.tabIndex=n===f?0:-1,r.classList.toggle(`sc-crossword-selected`,e.includes(n)),r.classList.toggle(`sc-crossword-current`,n===f);let s=t.clues.filter(e=>J(e).includes(n)).map(e=>`${e.number} ${e.direction}: ${e.text}`).join(`; `);r.setAttribute(`aria-label`,`Row ${i+1}, column ${a+1}. ${s}`)}}L();let R=e.querySelector(`.crossword-layout`),z=R?.querySelector(`.crossword-clues`);if(R&&z){let n=[...e.children].filter(e=>e!==R),r=e=>Number.parseFloat(e)||0,i=()=>{if(!e.clientHeight||!e.clientWidth)return;let i=getComputedStyle(e),a=n.filter(e=>{let t=getComputedStyle(e);return t.display!==`none`&&t.position!==`absolute`&&t.position!==`fixed`}),o=e.clientHeight-r(i.paddingTop)-r(i.paddingBottom)-r(i.rowGap)*a.length;for(let e of a){let t=getComputedStyle(e);o-=e.getBoundingClientRect().height+r(t.marginTop)+r(t.marginBottom)}o-=t.rows+2;let s=e.clientWidth-r(i.paddingLeft)-r(i.paddingRight);R.dataset.crosswordWide=String(s>=700);let c=r(getComputedStyle(R).columnGap),l=s-z.offsetWidth-c,u=t.columns*24,d=Math.floor(Math.max(u,Math.min(l,o*t.columns/t.rows)));R.style.setProperty(`--sc-crossword-width`,`${d}px`),R.style.setProperty(`--sc-crossword-height`,`${Math.ceil(d*t.rows/t.columns)}px`)},o=new ResizeObserver(i);o.observe(e);for(let e of n)o.observe(e);i(),a.push(()=>{o.disconnect(),R.style.removeProperty(`--sc-crossword-width`),R.style.removeProperty(`--sc-crossword-height`),delete R.dataset.crosswordWide})}return()=>{for(let e of a.reverse())e()}}function At(e){let{pointerX:t,pointerY:n,screenWidth:r,screenHeight:i,hasPreviousChapter:a,hasNextChapter:o}=e,s=r*.33,c=r*.67,l=i*.33,u=i*.67;return t<s&&a?`previous`:t>c&&o?`next`:t>=s&&t<=c&&n>=l&&n<=u?`toggle-ui`:`none`}var jt=5e3;function Mt(){let e=document.activeElement;e instanceof Element&&(e.closest(`.chapter-menu`)?document.querySelector(`.reading-header .menu-button`)?.focus():e.closest(`.adjustment-popup`)?e.closest(`.reader-adjustment-control`)?.querySelector(`button[aria-expanded]`)?.focus():e.closest(`.theme-settings-panel`)&&e.closest(`.theme-settings`)?.querySelector(`.settings-trigger`)?.focus())}function Nt(e,t,n,r,i=()=>!1){let a;function o(){clearTimeout(a),a=void 0}function s(){o(),e()&&(a=setTimeout(()=>{t()?n():i()?s():r()},jt))}return{pause:o,reset:s}}var Pt=d(`<div class="loading-overlay svelte-1jg2usx"><div class="spinner svelte-1jg2usx" aria-hidden="true"></div> <p>Opening book...</p></div>`),Ft=d(`<div class="error-overlay svelte-1jg2usx" role="alert"><p class="error-title svelte-1jg2usx">Could not open book</p> <p class="error-body svelte-1jg2usx"> </p> <button class="svelte-1jg2usx">Back to library</button></div>`),It=d(`<img alt="" class="cover-image"/>`),Lt=d(`<p> </p>`),Rt=d(`<div class="cover-fallback" aria-hidden="true"><p> </p> <!></div>`),zt=d(`<button class="cover-overlay" type="button" aria-label="Start reading"><div class="cover-page svelte-1jg2usx" role="img"><!></div></button>`),Bt=d(`<p class="save-error svelte-1jg2usx" role="alert"> </p>`),Vt=d(`<div aria-hidden="true"></div> <div aria-hidden="true"></div>`,1),Ht=d(`<div class="immersive-reveal-edge top svelte-1jg2usx" aria-hidden="true"></div> <div class="immersive-reveal-edge bottom svelte-1jg2usx" aria-hidden="true"></div>`,1),Ut=d(`<div role="main"><dialog class="safari-warning svelte-1jg2usx" aria-labelledby="safari-warning-title" aria-describedby="safari-warning-description"><h2 id="safari-warning-title" class="svelte-1jg2usx">Safari reader limitations</h2> <p id="safari-warning-description" class="svelte-1jg2usx">Tap the left or right edge to turn pages. Other book interactions and
      some keyboard shortcuts may not work in Safari. Use the
      header or footer to show the chapter menu in the header and position slider in the footer.</p> <form method="dialog"><button type="submit" class="svelte-1jg2usx">Continue reading</button></form></dialog> <!> <!> <div class="epub-viewport svelte-1jg2usx"><!> <!> <!> <!></div> <!> <!> <!></div> <!>`,1);function Wt(r,l){A(l,!0);let d=`study-cheetah.reader.display-mode`,f=ye.getInstance(),m=xe.getInstance(),_=ne(),b=oe(),x=h(null),S=h(P([])),T=h(0),D=h(`best-fit`),k=h(null),M=h(1),I=h(!0),L=h(!1),z=h(!1),B=h(null),V=h(!1),H=h(null),ae,W=h(!1),ce=h(!0),G=h(!0),K=h(null),ue=h(null),fe=h(null),me=h(null),q=h(null),ge=h(void 0),J=h([]),ve=h(new Map),be=h(new Map),Se=h(null),Ce,Y=null,X=!1,De=!1,Oe,ke,Ae=0,je=0,Me=0,Ne=!1,Pe=new Set,Fe=Promise.resolve(),Ie=!1,Le=new AbortController,ze=new Map,Be=new Map,Ve=g(()=>c(S)[c(T)]),He=g(()=>c(J).find(e=>c(k)&&e.spineIndex>=c(k).start.index&&e.spineIndex<=c(k).end.index)?.activity),Ue=g(()=>{let e=c(k);if(!e||c(W)||c(G)||c(K))return null;let t=t=>t>=e.start.index&&t<=e.end.index;return[...c(ve).values()].some(t)?[...c(be).values()].some(t)?`activity`:`ordinary`:null}),We=g(()=>c(Se)??c(He)),Ge=g(()=>c(k)?.atEnd?100:Math.round((c(k)?.start.percentage??0)*100)),Ke=g(()=>b.resolved.endsWith(`-dark`)?`dark`:`light`),qe=g(()=>re(c(x)?.accessibility.theme,b.readerTheme)),Je=g(()=>ie(c(qe),b.palette,c(Ke))),Xe=g(()=>`Section page ${c(k)?.start.displayed.page??1} of ${c(k)?.start.displayed.total??1}`),Ze=g(()=>c(W)?`Tap to start reading`:`${c(Ge)}% complete`),Qe,Z=Nt(()=>c(I),()=>c(L)||c(z)||c(B)!==null,()=>{Mt(),o(L,!1),o(z,!1),o(B,null)},()=>{o(I,!1)},()=>!!document.querySelector(`dialog[open]`));t(()=>{c(I)||(o(L,!1),o(z,!1),o(B,null)),c(L),c(z),c(B),Pe.size?Z.pause():Z.reset()}),t(()=>{c(qe),b.palette,c(Ke),_t()});function $e(e,t){X||(console.error(`[Reader] ${e}:`,t),o(K,`${t instanceof Error?t.message:String(t)}\n\nStage: ${e}`))}function et(){let e=new URLSearchParams(window.location.search),t=e.get(`mode`)??(e.has(`horizontalPaging`)||e.has(`twoPage`)?null:localStorage.getItem(d));if(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)return t;t!==null&&console.warn(`[Reader] Unrecognized reading view:`,t);let n=e.get(`horizontalPaging`)??localStorage.getItem(`study-cheetah.reader.horizontal-paging`),r=e.get(`twoPage`)??localStorage.getItem(`study-cheetah.reader.two-page`);return n===`1`||n===`true`?`single`:r===`1`||r===`true`?`spread`:n===`0`||n===`false`?`scroll`:`best-fit`}function tt(){if(!c(x)||!Ie)return Fe;Ie=!1;let e=c(x);return Fe=Fe.then(()=>f.updateBook(e)).then(()=>{o(ue,null)}).catch(e=>{console.error(`[Reader] Saving reading preferences and position failed:`,e),Ie=!0,o(ue,`Could not save your reading position and preferences.`)}),Fe}function nt(){if(Ie=!0,c(x))try{f.checkpointReadingState(c(x))}catch(e){console.error(`[Reader] Checkpointing reading preferences and position failed:`,e),o(ue,`Could not save your reading position and preferences.`)}clearTimeout(ke),ke=setTimeout(()=>{tt()},500)}function rt(e){if(o(k,e),c(S)[c(T)]?.spineIndex!==e.start.index){let t=c(S).findIndex(t=>t.spineIndex===e.start.index);t>=0&&o(T,t,!0)}!c(x)||De||X||(o(x,{...c(x),currentLocation:{chapterId:c(Ve)?.id??String(e.start.index),chapterIndex:c(T),elementOffset:0,percentageComplete:Math.round((e.start.percentage??0)*100),cfiFragment:e.start.cfi}},!0),nt())}function it(e){if(e!==Y||X)return;let t=e.currentLocation();t&&rt(t)}function at(){for(let e of ze.values())e();ze.clear(),o(J,[]),o(ve,new Map),o(be,new Map)}function ot(e){let t=!1,n=()=>{t=!0};return e.addEventListener(`study-cheetah-event-probe`,n),e.dispatchEvent(new Event(`study-cheetah-event-probe`)),e.removeEventListener(`study-cheetah-event-probe`,n),t}function st(e){return!!e&&`closest`in e&&typeof e.closest==`function`&&!!e.closest(`a, button, input, select, textarea, summary, [contenteditable="true"], [role="button"], [role="link"], [data-study-cheetah-enhanced]`)}function ct(e){if(c(z)&&e.key===`Escape`){e.preventDefault(),o(z,!1),document.querySelector(`.settings-trigger`)?.focus();return}if(!Pe.size&&(c(L)||c(z)||c(B))&&e.target instanceof Element&&e.target.closest(`.reading-header, .reading-footer`)&&Z.reset(),document.querySelector(`dialog[open]`)||e.defaultPrevented||e.ctrlKey||e.metaKey||st(e.target))return;if(e.altKey){!e.shiftKey&&(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),Ot(e.key===`ArrowDown`?1:-1));return}if(e.key===`Escape`){if(ae.ownsFullscreen())return;e.preventDefault(),lt();return}let t=e.key===`ArrowRight`||e.key===`PageDown`,n=e.key===`ArrowLeft`||e.key===`PageUp`;!t&&!n||(e.preventDefault(),wt(t?1:-1))}function lt(){Z.pause(),o(I,!c(I)),c(I)&&dt()}function ut(){c(V)?(o(H,null),ae.leave(),o(V,!1)):(o(H,null),ae.enter(),o(V,!0),Z.pause(),o(I,!1))}function dt(){Z.reset()}function ft(e,t){if(c(W)||c(G)||document.querySelector(`dialog[open]`))return;if(!c(I)&&(t<=60||t>=window.innerHeight-60)){lt();return}let n=At({pointerX:e,pointerY:t,screenWidth:window.innerWidth,screenHeight:window.innerHeight,hasPreviousChapter:!0,hasNextChapter:!c(k)?.atEnd});n===`toggle-ui`?lt():(n===`next`||n===`previous`)&&wt(n===`next`?1:-1)}function mt(e){e.on(`relocated`,t=>{e===Y&&!X&&rt(t)}),e.on(`layout`,t=>{e===Y&&o(M,t.divisor,!0)}),e.on(`rendered`,(t,n)=>{if(e!==Y||X)return;ze.get(n.id)?.();let r=n.document,i=n.iframe;if(!r||!i)return;i.title=`Book content`;let a=ot(r),s=n.section.index;if(typeof s==`number`){let e=new Map(c(ve)),t=new Map(c(be));a?e.delete(n.id):e.set(n.id,s),r.querySelector(`[data-study-cheetah-activity]`)?t.set(n.id,s):t.delete(n.id),o(ve,e),o(be,t)}let l=[],u=new Set,d=c(me);if(d){let e=[];for(let t of d.features){let s=[];try{let o=n.section.index;if(typeof o!=`number`)throw Error(`Exercise reading-order position is unavailable.`);let c=[...r.querySelectorAll(`[data-study-cheetah-activity="${t}"]`)].map(e=>{let c=t===`word-search-v1`?de(e):t===`crossword-v1`?he(e):pe(e),l={publicationId:d.publicationId,onprint:()=>{ht(c)}};if(c.kind===`word-search-v1`)s.push(Tt(e,c,l)),!a&&e.parentElement===r.body&&s.push(Dt(i,e,c,l));else if(c.kind===`crossword-v1`)s.push(kt(e,c,l));else{let t=JSON.stringify([d.publicationId,c.id,c.revision]);s.push(Ct(e,c,{...l,order:Be.get(t),onorder:e=>{Be.set(t,e)}})),!a&&e.parentElement===r.body&&s.push(Dt(i,e,c,{...l,order:Be.get(t),onorder:e=>{Be.set(t,e)}}))}return{viewId:n.id,spineIndex:o,activity:c}});e.push(...c),l.push(...s)}catch(e){u.add(t);for(let e of s)e();console.error(`[Reader] Invalid ${t} exercise:`,e),o(fe,`Interactive exercise unavailable: ${e instanceof Error?e.message:String(e)}`)}}o(J,[...c(J).filter(e=>e.viewId!==n.id),...e])}if(c(q)){let e=c(q).active.filter(e=>!u.has(e));l.push(_e(r,c(q),e))}let f=0,p=0,m=e=>{o(z,!1),f=e.clientX,p=e.clientY},h=e=>{if(st(e.target)||r.getSelection()?.isCollapsed===!1||Math.hypot(e.clientX-f,e.clientY-p)>10)return;let t=i.getBoundingClientRect();ft(t.left+e.clientX,t.top+e.clientY)};r.addEventListener(`pointerdown`,m),r.addEventListener(`pointerup`,h),r.addEventListener(`keydown`,ct),ze.set(n.id,()=>{for(let e of l)e();r.removeEventListener(`pointerdown`,m),r.removeEventListener(`pointerup`,h),r.removeEventListener(`keydown`,ct)})}),e.on(`removed`,(e,t)=>{ze.get(t.id)?.(),ze.delete(t.id),o(J,c(J).filter(e=>e.viewId!==t.id));let n=new Map(c(ve)),r=new Map(c(be));n.delete(t.id),r.delete(t.id),o(ve,n),o(be,r)}),e.on(`displayerror`,t=>{e===Y&&!X&&$e(`chapter-display`,t)})}async function ht(e){o(Se,e,!0);try{await i(),window.print()}catch(e){console.error(`[Reader] Printing worksheet failed:`,e),o(fe,`Could not print worksheet: ${e instanceof Error?e.message:String(e)}`)}finally{o(Se,null)}}async function gt(e,t){let n,r=()=>{},i=new Promise((t,i)=>{r=i,n=setTimeout(()=>i(Error(`Chapter rendering timed out (15s).`)),15e3),e.on(`displayerror`,r)}),a=()=>r(Error(`Reader closed before chapter rendering completed.`));Le.signal.addEventListener(`abort`,a,{once:!0});try{await Promise.race([e.display(t),i])}finally{clearTimeout(n),e.off(`displayerror`,r),Le.signal.removeEventListener(`abort`,a)}}function _t(){c(x)&&m.applyTheme(c(x).id,{...c(x).accessibility,theme:c(qe),appPalette:b.palette,appTone:c(Ke)})}async function yt(e){if(!c(x)||X)return;let t=c(D)===`best-fit`&&!await m.supportsBestFit(c(x).id)?`spread`:c(D);if(X)return;at();let n=m.attachRenderer(c(x).id,Ce,t);Y=n,mt(n),await n.started,!(X||n!==Y)&&(n.spread(t===`spread`?`auto`:`none`,1e3),_t(),await gt(n,e),it(n))}async function bt(){try{o(D,et(),!0);let e=new URLSearchParams(window.location.search).get(`id`),t=e?null:we(),n;if(n=e?await f.getBook(e):t?await Te(t):await Ee(),!n)throw Error(`The selected book was not found in your library.`);if(X)return;o(x,n,!0),_.applyBookRecord(n);let r=await m.loadBook(n.id,n.opfsPath);try{o(me,await m.getActivityCapability(n.id),!0),o(q,await m.getExtensionCapability(n.id),!0)}catch(e){console.error(`[Reader] Invalid publication extension declaration:`,e),o(fe,`Book enhancements unavailable: ${e instanceof Error?e.message:String(e)}`)}if(o(S,await m.getChapters(n.id),!0),X||(r.locations.length()===0&&await r.locations.generate(1e3),X)||(o(T,Math.max(0,Math.min(n.currentLocation?.chapterIndex??0,c(S).length-1)),!0),o(W,!0),await yt(n.currentLocation?.cfiFragment??(n.currentLocation?c(S)[c(T)]?.href:void 0)??0),X))return;n.currentLocation&&(Oe=setTimeout(St,2e3)),dt()}catch(e){X||$e(`reader-init`,e)}finally{X||(o(G,!1),o(ce,!1))}}async function xt(e){if(c(G)||!Y||e===c(D))return;let t=Y.currentLocation()?.start.cfi??c(x)?.currentLocation?.cfiFragment??0;o(G,!0),De=!0,o(D,e,!0);try{localStorage.setItem(d,e),await yt(t)}catch(e){$e(`reading-view`,e)}finally{De=!1,o(G,!1),Y&&it(Y)}}function St(){clearTimeout(Oe),o(W,!1)}async function wt(e){let t=Y;if(!t||c(G)||c(K))return;if(c(W)){e===1&&St();return}let n=t.currentLocation();if(e===-1&&n?.atStart){o(W,!0);return}if(!(e===1&&n?.atEnd)){o(G,!0);try{e===1?await t.next():await t.prev(),it(t)}catch(e){$e(`page-navigation`,e)}finally{o(G,!1)}}}async function Et(e){let t=c(S)[e],n=Y;if(!(!t||!n||c(G))){o(G,!0),St();try{await gt(n,t.href??t.spineIndex),o(T,e,!0),it(n)}catch(e){$e(`chapter-navigation`,e)}finally{o(G,!1)}}}async function Ot(e){let t=Y;if(!(!c(x)||!t||c(G)||c(K)||!c(S).length))try{let n=t.currentLocation();if(!n)throw Error(`Reading position is not ready for chapter navigation.`);let r=m.getChapterPosition(c(x).id,c(S),n,c(T)),i=e===1?r.chapterIndex+1:r.atBeginning?r.chapterIndex-1:r.chapterIndex;for(;i>=0&&i<c(S).length&&c(S)[i].spineIndex<0;)i+=e;i>=0&&i<c(S).length&&await Et(i)}catch(e){$e(`chapter-navigation`,e)}}async function jt(e){let t=Y;if(!(!c(x)||!t||c(G)||c(K))){o(G,!0);try{let n=m.getCfiFromPercentage(c(x).id,e/100);St(),await gt(t,n),it(t)}catch(e){$e(`position-navigation`,e)}finally{o(G,!1)}}}async function Wt(e,t){let n=Y;if(!c(x)||!n||c(G))return;let r=n.currentLocation()?.start.cfi??0;o(x,{...c(x),accessibility:{...c(x).accessibility,[e]:Math.min(2,Math.max(e===`fontSize`?.75:1,Math.round(t*100)/100))}},!0),o(G,!0),De=!0;try{n.clear(),_t(),await gt(n,r)}catch(e){$e(`typography`,e)}finally{De=!1,o(G,!1),it(n),nt()}}function Gt(e){!c(x)||c(G)||(o(x,{...c(x),accessibility:{...c(x).accessibility,theme:e}},!0),_t(),nt())}async function Kt(){clearTimeout(ke),await tt(),c(ue)||await te(`${ee}/start/library`)}function qt(e){Ne=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`),(Ne||st(e.target))&&(Pe.add(e.pointerId),Z.pause()),je=e.clientX,Me=e.clientY}function Jt(e){if(st(e.target)||Math.hypot(e.clientX-je,e.clientY-Me)>10)return;let t=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`);if(Ne||t){Ne&&t&&!c(I)&&lt();return}ft(e.clientX,e.clientY)}function Yt(){Ne=!1}function Xt(e){!Pe.size&&(c(L)||c(z)||c(B))&&e.target instanceof Element&&e.target.closest(`.chapter-menu, .adjustment-popup, .theme-settings-panel`)&&Z.reset()}function Zt(e){Pe.delete(e.pointerId)&&!Pe.size&&Z.reset()}function Qt(){Pe.clear(),Z.reset()}function $t(e){!Pe.size&&(c(L)||c(z)||c(B))&&Z.reset(),c(W)&&e.deltaY>0&&(e.preventDefault(),St())}F(()=>{ae=le(()=>{o(V,!1),o(I,!0),dt()},e=>{o(H,e,!0)});let e=navigator.userAgent;/\bVersion\/[\d.]+.*\bSafari\//.test(e)&&!/\b(?:Chrome|Chromium|CriOS|FxiOS|Edg|EdgiOS|EdgA|OPR|OPiOS|DuckDuckGo)\//i.test(e)&&Qe.showModal(),window.addEventListener(`keydown`,ct),window.addEventListener(`pointerup`,Zt),window.addEventListener(`pointercancel`,Zt),window.addEventListener(`blur`,Qt);let t=new ResizeObserver(()=>{cancelAnimationFrame(Ae),Ae=requestAnimationFrame(()=>{if(!Y||c(G)||X||!Ce.clientWidth||!Ce.clientHeight)return;let e=Y.currentLocation()?.start.cfi;Y.resize(Ce.clientWidth,Ce.clientHeight,e)})});t.observe(Ce);let n=new MutationObserver(()=>_t());return n.observe(document.documentElement,{attributes:!0,attributeFilter:[`data-ui-theme`]}),bt(),()=>{X=!0,ae.destroy(),Le.abort(),t.disconnect(),n.disconnect(),cancelAnimationFrame(Ae),window.removeEventListener(`keydown`,ct),window.removeEventListener(`pointerup`,Zt),window.removeEventListener(`pointercancel`,Zt),window.removeEventListener(`blur`,Qt),Z.pause(),clearTimeout(Oe),clearTimeout(ke),tt(),at(),c(x)&&m.detachRenderer(c(x).id),Y=null}});var en=Ut(),Q=a(en);let tn;var nn=p(Q);j(nn,e=>Qe=e,()=>Qe);var rn=s(nn,2),an=e=>{vt(e,{get capability(){return c(q)},onready:e=>{o(ge,e,!0)}})};y(rn,e=>{c(q)&&!c(ce)&&!c(W)&&e(an)});var on=s(rn,2),sn=e=>{{let t=g(()=>_.appName||c(x).title||c(x).filename),n=g(()=>c(He)?.chapterTitle??c(Ve)?.label),r=g(()=>c(x).accessibility.theme??`inherit`);Re(e,{get bookTitle(){return c(t)},get chapterTitle(){return c(n)},get controlsVisible(){return c(I)},get readerTheme(){return c(r)},get displayMode(){return c(D)},get busy(){return c(G)},onDisplayModeChange:xt,onReaderThemeChange:Gt,get settingsOpen(){return c(z)},onSettingsOpenChange:e=>{o(z,e,!0),e&&(o(L,!1),o(B,null))},onClose:Kt,get onFeatures(){return c(ge)},get chapters(){return c(S)},get currentChapterIndex(){return c(T)},get chapterMenuOpen(){return c(L)},onChapterMenuChange:e=>{o(L,e,!0),e&&o(z,!1)},onChapterSelect:Et,get immersive(){return c(V)},onImmersiveChange:ut})}};y(on,e=>{c(x)&&e(sn)});var $=s(on,2),cn=p($),ln=e=>{n(e,Pt())},un=t=>{var r=Ft(),i=s(p(r),2),a=p(i,!0);v(i);var o=s(i,2);v(r),U(()=>u(a,c(K))),e(`click`,o,()=>te(`${ee}/start/library`)),n(t,r)},dn=t=>{var r=zt(),i=p(r),a=p(i),o=e=>{var t=It();U(()=>E(t,`src`,c(x).coverImage)),n(e,t)},l=e=>{var t=Rt(),r=p(t),i=p(r,!0);v(r);var a=s(r,2),o=e=>{var t=Lt(),r=p(t,!0);v(t),U(()=>u(r,c(x).author)),n(e,t)};y(a,e=>{c(x).author&&e(o)}),v(t),U(()=>u(i,c(x).title??c(x).filename)),n(e,t)};y(a,e=>{c(x).coverImage?e(o):e(l,-1)}),v(i),v(r),U(()=>E(i,`aria-label`,`Cover for ${c(x).title??c(x).filename}`)),e(`click`,r,St),n(t,r)};y(cn,e=>{c(ce)?e(ln):c(K)?e(un,1):c(W)&&c(x)&&e(dn,2)});var fn=s(cn,2),pn=e=>{var t=Bt(),r=p(t,!0);v(t),U(()=>u(r,c(ue))),n(e,t)};y(fn,e=>{c(ue)&&e(pn)});var mn=s(fn,2),hn=e=>{var t=Bt(),r=p(t,!0);v(t),U(()=>u(r,c(fe))),n(e,t)};y(mn,e=>{c(fe)&&e(hn)});var gn=s(mn,2),_n=e=>{var t=Vt(),r=a(t);let i;var o=s(r,2);let l;U(()=>{i=O(r,1,`page-turn-zone previous svelte-1jg2usx`,null,i,{activity:c(Ue)===`activity`}),l=O(o,1,`page-turn-zone next svelte-1jg2usx`,null,l,{activity:c(Ue)===`activity`})}),n(e,t)};y(gn,e=>{c(Ue)&&e(_n)}),v($),j($,e=>Ce=e,()=>Ce);var vn=s($,2),yn=e=>{{let t=g(()=>c(Ve)?.label??`Front matter`),n=g(()=>!c(W)&&!!c(k)?.atEnd);Ye(e,{get controlsVisible(){return c(I)},get fontSize(){return c(x).accessibility.fontSize},get lineHeight(){return c(x).accessibility.lineHeight},get progressPercent(){return c(Ge)},get currentChapterIndex(){return c(T)},get totalChapters(){return c(S).length},get chapterPositionLabel(){return c(t)},get pageLabel(){return c(Xe)},get progressLabel(){return c(Ze)},get busy(){return c(G)},onFontSizeChange:e=>Wt(`fontSize`,e),onLineHeightChange:e=>Wt(`lineHeight`,e),onProgressChange:jt,onPreviousPage:()=>wt(-1),onNextPage:()=>wt(1),get previousPageDisabled(){return c(W)},get nextPageDisabled(){return c(n)},get chapterMenuOpen(){return c(L)},onAdjustmentOpen:()=>{o(L,!1),o(z,!1)},get openControl(){return c(B)},set openControl(e){o(B,e,!0)}})}};y(vn,e=>{c(x)&&e(yn)});var bn=s(vn,2),xn=e=>{var t=Ht();C(2),n(e,t)};y(bn,e=>{c(V)&&!c(I)&&!c(W)&&e(xn)}),se(s(bn,2),{get message(){return c(H)},onDismiss:()=>{o(H,null)}}),v(Q);var Sn=s(Q,2),Cn=e=>{pt(e,{get activity(){return c(We)}})};y(Sn,e=>{c(We)&&e(Cn)}),U(()=>{tn=O(Q,1,`reader-shell svelte-1jg2usx`,null,tn,{"show-ui":c(I),immersive:c(V)}),N(Q,`--reader-page-bg: ${c(Je).background}; --reader-page-fg: ${c(Je).foreground}; --reader-page-muted: ${c(Je).muted}; --reader-page-accent: ${c(Je).accent}; --reader-page-border: ${c(Je).border};`),E($,`aria-busy`,c(G)),E($,`data-display-mode`,c(D)),E($,`data-start-cfi`,c(k)?.start.cfi),E($,`data-end-cfi`,c(k)?.end.cfi),E($,`data-spine-index`,c(k)?.start.index),E($,`data-page`,c(k)?.start.displayed.page),E($,`data-total-pages`,c(k)?.start.displayed.total),E($,`data-visible-pages`,c(M))}),e(`pointerdown`,Q,qt),e(`pointerup`,Q,Jt),w(`pointercancel`,Q,Yt),e(`pointermove`,Q,Xt),w(`wheel`,Q,$t),e(`pointerdown`,nn,e=>e.stopPropagation()),e(`pointerup`,nn,e=>e.stopPropagation()),n(r,en),R()}T([`pointerdown`,`pointerup`,`pointermove`,`click`]);export{Wt as component,Y as universal};