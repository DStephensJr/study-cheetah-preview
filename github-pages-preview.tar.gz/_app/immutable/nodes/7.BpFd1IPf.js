import{$ as e,A as t,C as n,D as r,G as i,H as a,J as o,K as s,M as c,O as l,P as u,R as d,S as f,T as p,U as m,W as h,Y as g,a as _,at as v,b as y,c as b,d as x,et as S,f as C,it as w,k as T,l as E,m as D,nt as O,o as k,p as A,q as j,r as M,rt as N,s as P,st as F,u as I,v as L,w as R,y as z}from"../chunks/l3r6VetK.js";import{t as B,u as V}from"../chunks/DAIiRXZ4.js";import"../chunks/xihTtKlq.js";import"../chunks/Dj7R34aO.js";import{n as H}from"../chunks/BTa8hn0g.js";import{t as ee}from"../chunks/Dkp_jIiQ.js";import{_ as U,a as W,c as te,d as ne,f as G,g as re,h as ie,i as ae,l as oe,m as se,n as ce,o as K,p as le,r as ue,s as q,t as de,u as J,v as Y}from"../chunks/ByD5D45t.js";import{i as fe,n as pe,r as me}from"../chunks/DtiPRl4J.js";var he=F({load:()=>ge}),ge=async()=>({readyToRender:!0}),_e=p(`<p class="chapter-title svelte-1e78rkn"> </p>`),ve=p(`<button class="features-button svelte-1e78rkn" type="button" aria-label="Book enhancements">Features</button>`),ye=p(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">View</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reading view"><option>Vertical scroll</option><option>Single page</option><option>Facing pages</option><option>Best fit</option></select></label>`),be=p(`<label class="reader-setting-wrap svelte-1e78rkn"><span class="reader-setting-label svelte-1e78rkn">Theme</span> <select class="reader-setting-select svelte-1e78rkn" aria-label="Reader theme"><option>Adaptive</option><option>Light</option><option>Dark</option><option>Sepia</option></select></label>`),xe=p(`<div class="header-content controls-mode svelte-1e78rkn"><button class="close-button svelte-1e78rkn" aria-label="Close reader">✕</button> <div class="header-text svelte-1e78rkn"><h1 class="book-title svelte-1e78rkn"> </h1> <!></div> <div class="header-settings svelte-1e78rkn"><!> <!> <!></div></div>`),Se=p(`<div class="header-content passive-mode svelte-1e78rkn"><div class="passive-header-text svelte-1e78rkn"><p class="book-title svelte-1e78rkn"> </p> <!></div></div>`),Ce=p(`<header><!></header>`);function we(t,r){S(r,!0);let i=_(r,`readerTheme`,3,`adaptive`),o=_(r,`busy`,3,!1);var s=Ce();let c;var l=a(s),u=e=>{var t=xe(),s=a(t),c=h(s,2),l=a(c),u=a(l,!0);N(l);var p=h(l,2),m=e=>{var t=_e(),i=a(t,!0);N(t),d(()=>f(i,r.chapterTitle)),n(e,t)};y(p,e=>{r.chapterTitle&&e(m)}),N(c);var g=h(c,2),_=a(g),v=e=>{var t=ve();T(`click`,t,function(...e){r.onFeatures?.apply(this,e)}),n(e,t)};y(_,e=>{r.onFeatures&&e(v)});var b=h(_,2),S=e=>{var t=ye(),i=h(a(t),2),s=a(i);s.value=s.__value=`scroll`;var c=h(s);c.value=c.__value=`single`;var l=h(c);l.value=l.__value=`spread`;var u=h(l);u.value=u.__value=`best-fit`,N(i);var f;x(i),N(t),d(()=>{i.disabled=o(),f!==(f=r.displayMode)&&(i.value=(i.__value=r.displayMode)??``,C(i,r.displayMode))}),T(`change`,i,e=>{let t=e.currentTarget.value;(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)&&r.onDisplayModeChange?.(t)}),n(e,t)};y(b,e=>{r.displayMode&&r.onDisplayModeChange&&e(S)});var w=h(b,2),E=e=>{var t=be(),s=h(a(t),2),c=a(s);c.value=c.__value=`adaptive`;var l=h(c);l.value=l.__value=`light`;var u=h(l);u.value=u.__value=`dark`;var f=h(u);f.value=f.__value=`sepia`,N(s);var p;x(s),N(t),d(()=>{s.disabled=o(),p!==(p=i())&&(s.value=(s.__value=i())??``,C(s,i()))}),T(`change`,s,e=>{let t=e.currentTarget.value;(t===`adaptive`||t===`light`||t===`dark`||t===`sepia`)&&r.onReaderThemeChange?.(t)}),n(e,t)};y(w,e=>{r.onReaderThemeChange&&e(E)}),N(g),N(t),d(()=>f(u,r.bookTitle)),T(`click`,s,function(...e){r.onClose?.apply(this,e)}),n(e,t)},p=e=>{var t=Se(),i=a(t),o=a(i),s=a(o,!0);N(o);var c=h(o,2),l=e=>{var t=_e(),i=a(t,!0);N(t),d(()=>f(i,r.chapterTitle)),n(e,t)};y(c,e=>{r.chapterTitle&&e(l)}),N(i),N(t),d(()=>f(s,r.bookTitle)),n(e,t)};y(l,e=>{r.controlsVisible?e(u):e(p,-1)}),N(s),d(()=>c=D(s,1,`reading-header svelte-1e78rkn`,null,c,{"controls-visible":r.controlsVisible})),n(t,s),e()}l([`click`,`change`]);var Te=p(`<button class="chapter-toggle svelte-1tz9bb9" type="button"><svg aria-hidden="true" viewBox="0 0 20 20"><path d="m7 4 6 6-6 6"></path></svg></button>`),Ee=p(`<div><!></div>`),De=p(`<li><div class="chapter-row svelte-1tz9bb9"><button><span class="chapter-number svelte-1tz9bb9"> </span> <span class="chapter-label svelte-1tz9bb9"> </span></button> <!></div> <!></li>`),Oe=p(`<ol class="chapter-entries svelte-1tz9bb9"></ol>`),ke=p(`<div class="control-group line-height-controls svelte-1tz9bb9"><button class="control-button svelte-1tz9bb9" aria-label="Decrease line height" title="Decrease line height">L−</button> <div class="font-display svelte-1tz9bb9"> </div> <button class="control-button svelte-1tz9bb9" aria-label="Increase line height" title="Increase line height">L+</button></div>`),Ae=p(`<div class="footer-content controls-mode svelte-1tz9bb9"><div class="control-group font-controls svelte-1tz9bb9"><button class="control-button svelte-1tz9bb9" aria-label="Decrease font size" title="Decrease font size">A−</button> <div class="font-display svelte-1tz9bb9"> </div> <button class="control-button svelte-1tz9bb9" aria-label="Increase font size" title="Increase font size">A+</button></div> <div class="control-group progress-controls svelte-1tz9bb9"><div class="progress-slider svelte-1tz9bb9"><div class="progress-track svelte-1tz9bb9" aria-hidden="true"><div class="progress-fill svelte-1tz9bb9"></div></div> <div class="progress-thumb svelte-1tz9bb9" aria-hidden="true"><span> </span></div> <input class="progress-range svelte-1tz9bb9" type="range" min="0" max="100" step="1" aria-label="Reading position"/></div></div> <div class="control-group action-controls svelte-1tz9bb9"><button class="control-button menu-button svelte-1tz9bb9" aria-label="Chapter menu" aria-controls="chapter-menu" title="Chapter menu">☰</button></div> <!></div>`),je=p(`<div class="footer-content passive-mode svelte-1tz9bb9"><div class="passive-footer-shell svelte-1tz9bb9"><p class="passive-footer-metric svelte-1tz9bb9"> </p></div></div>`),Me=p(`<div class="chapter-menu svelte-1tz9bb9" id="chapter-menu"><div class="chapter-menu-header svelte-1tz9bb9"><h2 class="svelte-1tz9bb9">Chapters</h2> <button class="close-menu svelte-1tz9bb9" aria-label="Close menu">✕</button></div> <nav class="chapter-list svelte-1tz9bb9" aria-label="Table of contents"><!></nav></div>`),Ne=p(`<footer><!> <!></footer>`);function Pe(r,l){S(l,!0);let u=(e,t=v,r)=>{let i=o(()=>w(r?.(),``));var p=Oe();L(p,23,t,e=>e.id,(e,t,r)=>{let o=g(()=>l.chapters.findIndex(e=>e.id===c(t).id)),p=g(()=>`${c(i)}${c(r)+1}`);var m=De(),_=a(m),v=a(_);let b;var S=a(v),w=a(S,!0);N(S);var k=h(S,2),A=a(k,!0);N(k),N(v);var j=h(v,2),M=e=>{var r=Te(),i=a(r);let l;N(r),d((e,t,n)=>{E(r,`aria-label`,e),E(r,`aria-expanded`,t),E(r,`aria-controls`,`chapter-children-${c(o)}`),r.disabled=x(),l=D(i,0,`svelte-1tz9bb9`,null,l,n)},[()=>`${c(O).includes(c(t).id)?`Collapse`:`Expand`} ${c(t).label}`,()=>c(O).includes(c(t).id),()=>({expanded:c(O).includes(c(t).id)})]),T(`click`,r,()=>{s(O,c(O).includes(c(t).id)?c(O).filter(e=>e!==c(t).id):[...c(O),c(t).id],!0)}),n(e,r)};y(j,e=>{c(t).subitems?.length&&e(M)}),N(_);var P=h(_,2),F=e=>{var r=Ee();u(a(r),()=>c(t).subitems,()=>`${c(p)}.`),N(r),d(e=>{E(r,`id`,`chapter-children-${c(o)}`),E(r,`hidden`,e)},[()=>!c(O).includes(c(t).id)]),n(e,r)};y(P,e=>{c(t).subitems?.length&&e(F)}),N(m),d(()=>{b=D(v,1,`chapter-item svelte-1tz9bb9`,null,b,{active:c(o)===l.currentChapterIndex}),E(v,`aria-current`,c(o)===l.currentChapterIndex?`location`:void 0),v.disabled=x(),f(w,c(p)),f(A,c(t).label)}),T(`click`,v,()=>{l.onChapterSelect(c(o)),s(C,!1)}),n(e,m)}),N(p),n(e,p)},p=_(l,`lineHeight`,3,1),m=_(l,`chapterPositionLabel`,3,void 0),x=_(l,`busy`,3,!1),C=j(!1),O=j(i([])),k=j(null),M=null,P=g(()=>c(k)??l.progressPercent),F=g(()=>{let e=new Set(l.chapters.flatMap(e=>e.subitems?.map(e=>e.id)??[]));return l.chapters.filter(t=>!e.has(t.id))});function R(e){return e.subitems?.some(e=>e.id===l.chapters[l.currentChapterIndex]?.id||R(e))??!1}function z(){s(C,!c(C)),c(C)&&s(O,[...new Set([...c(O),...l.chapters.filter(R).map(e=>e.id)])],!0)}var B=Ne();let V;var H=a(B),ee=e=>{var r=Ae(),i=a(r),o=a(i),u=h(o,2),g=a(u);N(u);var _=h(u,2);N(i);var v=h(i,2),S=a(v),w=a(S),D=a(w);N(w);var O=h(w,2),j=a(O),F=a(j);N(j),N(O);var L=h(O,2);b(L),N(S),N(v);var R=h(v,2),B=a(R);N(R);var V=h(R,2),H=e=>{var t=ke(),r=a(t),i=h(r,2),o=a(i);N(i);var s=h(i,2);N(t),d(e=>{r.disabled=x()||p()<=1,f(o,`${e??``}x`),s.disabled=x()||p()>=2},[()=>p().toFixed(2)]),T(`click`,r,function(...e){l.onLineHeightDecrease?.apply(this,e)}),T(`click`,s,function(...e){l.onLineHeightIncrease?.apply(this,e)}),n(e,t)};y(V,e=>{l.onLineHeightIncrease&&l.onLineHeightDecrease&&e(H)}),N(r),d((e,t,n)=>{o.disabled=x()||l.fontSize<=.75,f(g,`${e??``}x`),_.disabled=x()||l.fontSize>=2,E(S,`title`,`${m()??`${l.currentChapterIndex+1} / ${l.totalChapters}`}: ${l.pageLabel}`),A(D,`width: ${c(P)}%`),A(O,`left: calc(${c(P)}% - ${c(P)*.48}px)`),f(F,`${t??``}%`),I(L,c(P)),E(L,`aria-valuetext`,n),L.disabled=x()||!l.onProgressChange,E(B,`aria-expanded`,c(C)),B.disabled=x()},[()=>l.fontSize.toFixed(2),()=>Math.round(c(P)),()=>`${Math.round(c(P))}% of book`]),T(`click`,o,function(...e){l.onFontSizeDecrease?.apply(this,e)}),T(`click`,_,function(...e){l.onFontSizeIncrease?.apply(this,e)}),T(`pointerdown`,L,e=>{M=e.currentTarget.valueAsNumber}),T(`input`,L,e=>{s(k,e.currentTarget.valueAsNumber,!0)}),T(`pointerup`,L,e=>{e.currentTarget.valueAsNumber===M&&s(k,null),M=null}),t(`pointercancel`,L,()=>{s(k,null),M=null}),T(`change`,L,async e=>{let t=e.currentTarget.valueAsNumber;try{await l.onProgressChange?.(t)}finally{s(k,null)}}),T(`click`,B,z),n(e,r)},U=e=>{var t=je(),r=a(t),i=a(r),o=a(i,!0);N(i),N(r),N(t),d(()=>f(o,l.progressLabel)),n(e,t)};y(H,e=>{l.controlsVisible?e(ee):e(U,-1)});var W=h(H,2),te=e=>{var t=Me(),r=a(t),i=h(a(r),2);N(r);var o=h(r,2);u(a(o),()=>c(F)),N(o),N(t),T(`click`,i,()=>s(C,!1)),n(e,t)};y(W,e=>{c(C)&&e(te)}),N(B),d(()=>V=D(B,1,`reading-footer svelte-1tz9bb9`,null,V,{"controls-visible":l.controlsVisible,"has-line-height-controls":!!l.onLineHeightIncrease&&!!l.onLineHeightDecrease})),n(r,B),e()}l([`click`,`pointerdown`,`input`,`pointerup`,`change`]);var Fe=p(`<p class="chapter-title svelte-v52sy3"> </p>`),Ie=p(`<p>Find the Greek words in any of eight directions, including backward. Grid letters omit accents and breathing marks.</p>`),Le=p(`<p>Use the English clues to fill in the Greek words. Accents and breathing marks are not required.</p>`),Re=p(`<p>Write the English meaning and its letter beside each Greek word.</p>`),X=p(`<td class="svelte-v52sy3"><span class="svelte-v52sy3"> </span></td>`),ze=p(`<tr></tr>`),Be=p(`<li class="svelte-v52sy3"> </li>`),Ve=p(`<div class="word-search-layout svelte-v52sy3"><table class="word-search-grid svelte-v52sy3" lang="el" aria-label="Greek word search"><tbody></tbody></table> <section class="word-search-vocabulary svelte-v52sy3"><h2 class="svelte-v52sy3">Words to find</h2> <ul class="word-search-words svelte-v52sy3" lang="el"></ul></section></div>`),He=p(`<li class="svelte-v52sy3"><strong> </strong> </li>`),Ue=p(`<section><h2 class="svelte-v52sy3"> </h2> <ul class="svelte-v52sy3"></ul></section>`),We=p(`<span class="svelte-v52sy3"> </span>`),Ge=p(`<td class="crossword-cell svelte-v52sy3"></td>`),Ke=p(`<td class="crossword-empty svelte-v52sy3"></td>`),qe=p(`<div class="crossword-layout svelte-v52sy3"><div class="crossword-clues svelte-v52sy3"></div> <table class="crossword-grid svelte-v52sy3" aria-label="Blank Greek crossword"><tbody></tbody></table></div>`),Je=p(`<li class="prompt-row svelte-v52sy3"><span class="greek-word svelte-v52sy3"> </span><span class="meaning-blank svelte-v52sy3"></span><span class="letter-box svelte-v52sy3"></span><span class="result-space"></span></li>`),Ye=p(`<li class="choice-row svelte-v52sy3"><span class="choice-letter svelte-v52sy3"> </span><span> </span></li>`),Xe=p(`<div class="matching-columns svelte-v52sy3"><section><h2 class="svelte-v52sy3">Greek words</h2><ul class="svelte-v52sy3"></ul></section> <section><h2 class="svelte-v52sy3">English meanings</h2><ul class="svelte-v52sy3"></ul></section></div>`),Ze=p(`<section class="worksheet-print svelte-v52sy3" aria-label="Printable worksheet"><!> <h1 class="svelte-v52sy3"> </h1> <!> <p>Name: ________________________ Date: ______________</p> <!></section>`);function Qe(t,r){S(r,!0);var i=Ze(),o=a(i),s=e=>{var t=Fe(),i=a(t,!0);N(t),d(()=>f(i,r.activity.chapterTitle)),n(e,t)};y(o,e=>{r.activity.chapterTitle&&e(s)});var l=h(o,2),u=a(l,!0);N(l);var p=h(l,2),g=e=>{n(e,Ie())},_=e=>{n(e,Le())},v=e=>{n(e,Re())};y(p,e=>{r.activity.kind===`word-search-v1`?e(g):r.activity.kind===`crossword-v1`?e(_,1):e(v,-1)});var b=h(p,4),x=e=>{var t=Ve(),i=a(t),o=a(i);L(o,21,()=>r.activity.grid,z,(e,t)=>{var r=ze();L(r,21,()=>[...c(t)],z,(e,t)=>{var r=X(),i=a(r),o=a(i,!0);N(i),N(r),d(()=>f(o,c(t))),n(e,r)}),N(r),n(e,r)}),N(o),N(i);var s=h(i,2),l=h(a(s),2);L(l,21,()=>r.activity.words,e=>e.id,(e,t)=>{var r=Be(),i=a(r,!0);N(r),d(()=>f(i,c(t).text)),n(e,r)}),N(l),N(s),N(t),n(e,t)},C=e=>{var t=qe(),i=a(t);L(i,20,()=>[`across`,`down`],z,(e,t)=>{var i=Ue(),o=a(i),s=a(o,!0);N(o);var l=h(o,2);L(l,21,()=>r.activity.clues.filter(e=>e.direction===t),e=>e.id,(e,t)=>{var r=He(),i=a(r),o=a(i);N(i);var s=h(i);N(r),d(()=>{f(o,`${c(t).number??``}.`),f(s,` ${c(t).text??``}`)}),n(e,r)}),N(l),N(i),d(()=>f(s,t===`across`?`Across`:`Down`)),n(e,i)}),N(i);var o=h(i,2),s=a(o);L(s,21,()=>r.activity.cells,z,(e,t,i)=>{var o=ze();L(o,21,()=>c(t),z,(e,t,o)=>{var s=R(),l=m(s),u=e=>{var t=Ge();L(t,21,()=>r.activity.clues.filter(e=>e.row===i&&e.column===o).slice(0,1),z,(e,t)=>{var r=We(),i=a(r,!0);N(r),d(()=>f(i,c(t).number)),n(e,r)}),N(t),n(e,t)},p=e=>{n(e,Ke())};y(l,e=>{c(t)?e(u):e(p,-1)}),n(e,s)}),N(o),n(e,o)}),N(s),N(o),N(t),d(()=>E(o,`lang`,r.activity.language)),n(e,t)},w=e=>{var t=Xe(),i=a(t),o=h(a(i));L(o,21,()=>r.activity.prompts,e=>e.id,(e,t)=>{var r=Je(),i=a(r),o=a(i,!0);N(i),O(3),N(r),d(()=>{E(i,`lang`,c(t).language),f(o,c(t).text)}),n(e,r)}),N(o),N(i);var s=h(i,2),l=h(a(s));L(l,23,()=>r.activity.choices,e=>e.id,(e,t,r)=>{var i=Ye(),o=a(i),s=a(o,!0);N(o);var l=h(o),u=a(l,!0);N(l),N(i),d(e=>{f(s,e),E(l,`lang`,c(t).language),f(u,c(t).text)},[()=>ie(c(r))]),n(e,i)}),N(l),N(s),N(t),n(e,t)};y(b,e=>{r.activity.kind===`word-search-v1`?e(x):r.activity.kind===`crossword-v1`?e(C,1):e(w,-1)}),N(i),d(()=>f(u,r.activity.title)),n(t,i),e()}var $e=p(`<li class="svelte-5ift61"><strong> </strong>: <!></li>`),et=p(`<p role="alert" class="svelte-5ift61"> </p>`),tt=p(`<button type="button" class="svelte-5ift61">Close without saving</button>`),nt=p(`<dialog class="reader-feature-notice svelte-5ift61" aria-labelledby="reader-feature-title" aria-describedby="reader-feature-message"><h2 id="reader-feature-title" class="svelte-5ift61"> </h2> <p id="reader-feature-message" class="svelte-5ift61"> </p> <a target="_blank" rel="noopener noreferrer" class="svelte-5ift61">Visit Study Cheetah (opens in a new tab)</a> <h3 class="svelte-5ift61">Features requested by this book</h3> <ul class="svelte-5ift61"></ul> <p class="svelte-5ift61">Active means the reader's enhancement is enabled. Each activity is validated when opened.</p> <p class="svelte-5ift61">Unavailable enhancements keep their ordinary book content. This link opens the reader website; it does not upload your book.</p> <label class="svelte-5ift61"><input type="checkbox" class="svelte-5ift61"/> Don't show this again for this book's current features</label> <!> <div class="actions svelte-5ift61"><!> <button type="button" class="svelte-5ift61">Continue reading</button></div></dialog>`);function rt(t,i){S(i,!0);let o,l=j(!1),u=j(null),p=ue.getInstance();function m(e){console.error(`[Reader] Saving or loading enhancement notice preference failed:`,e),s(u,`Could not remember your notice preference: ${e instanceof Error?e.message:String(e)}`)}function _(){try{p.setReaderNoticeDismissed(i.capability,c(l)),s(u,null),o.close()}catch(e){m(e)}}M(()=>{try{s(l,p.isReaderNoticeDismissed(i.capability),!0)}catch(e){m(e)}i.onready(()=>{o.open||o.showModal()}),(c(u)||!c(l)&&i.capability.requested.some(e=>!i.capability.active.includes(e)))&&o.showModal()});var v=nt(),x=a(v),C=a(x,!0);N(x);var w=h(x,2),D=a(w,!0);N(w);var A=h(w,2),F=h(A,4);L(F,20,()=>i.capability.requested,e=>e,(e,t)=>{var o=$e(),s=a(o),l=a(s,!0);N(s);var u=h(s,2),p=e=>{n(e,r(`Active`))},m=g(()=>i.capability.active.includes(t)),_=e=>{n(e,r(`Supported, not active`))},v=g(()=>i.capability.supported.includes(t)),b=e=>{n(e,r(`Not supported by this reader yet`))};y(u,e=>{c(m)?e(p):c(v)?e(_,1):e(b,-1)}),N(o),d(()=>f(l,t)),n(e,o)}),N(F);var I=h(F,6),R=a(I);b(R),O(),N(I);var z=h(I,2),B=e=>{var t=et(),r=a(t,!0);N(t),d(()=>f(r,c(u))),n(e,t)};y(z,e=>{c(u)&&e(B)});var V=h(z,2),H=a(V),ee=e=>{var t=tt();T(`click`,t,()=>o.close()),n(e,t)};y(H,e=>{c(u)&&e(ee)});var U=h(H,2);N(V),N(v),k(v,e=>o=e,()=>o),d(()=>{f(C,i.capability.notice.title),f(D,i.capability.notice.message),E(A,`href`,i.capability.notice.url)}),P(R,()=>c(l),e=>s(l,e)),T(`click`,U,_),n(t,v),e()}l([`click`]);var it=`body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
  padding-block: 0.5rem;\r
}\r
[data-study-cheetah-enhanced="matching-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  height: 100%;\r
  min-height: 0;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced] > h1 { text-align: center; }\r
body > [data-study-cheetah-enhanced="matching-v1"] > h1 { margin-block-start: 0; }\r
[data-study-cheetah-enhanced="matching-v1"] [data-study-cheetah-matching-instructions] { display: none; }\r
[data-study-cheetah-enhanced] .matching-columns {\r
  display: grid;\r
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);\r
  gap: clamp(0.75em, 3vw, 2em);\r
  flex: 1 1 auto;\r
  min-height: 6em;\r
}\r
[data-study-cheetah-enhanced] .matching-columns > section {\r
  display: flex;\r
  flex-direction: column;\r
  min-height: 0;\r
  min-width: 0;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts],\r
[data-study-cheetah-enhanced] [data-matching-choices] {\r
  display: grid;\r
  reading-flow: grid-order;\r
  align-content: start;\r
  gap: 0.4em;\r
  min-height: 0;\r
  padding: 4px;\r
  margin: 0;\r
  list-style: none;\r
  overflow-y: auto;\r
  overscroll-behavior-y: contain;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced] li {\r
  box-sizing: border-box;\r
  position: relative;\r
  min-height: 44px;\r
  padding: 0.35em;\r
  overflow-wrap: anywhere;\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 1.8em 1em;\r
  align-items: center;\r
  gap: 0.4em;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] [data-matching-prompts] > li::before {\r
  content: none;\r
}\r
[data-study-cheetah-enhanced] .answer-blank {\r
  box-sizing: border-box;\r
  min-width: 1.6em;\r
  max-width: 3em;\r
  min-height: 1.6em;\r
  padding: 0 0.15em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  text-align: center;\r
  font-weight: bold;\r
  line-height: 1.5;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li {\r
  display: grid;\r
  grid-template-columns: 2em minmax(0, 1fr);\r
  align-items: center;\r
  column-gap: 2ch;\r
  text-align: left;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] > li::before {\r
  content: attr(data-choice-label);\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
  font-weight: bold;\r
  text-align: center;\r
}\r
[data-study-cheetah-enhanced] [data-matching-choices] .answer-blank { display: none; }\r
[data-study-cheetah-enhanced] .answer-blank {\r
  white-space: normal;\r
  color: var(--reader-matching-greek, var(--coloroldgreek, #0070c0));\r
}\r
[data-study-cheetah-enhanced] .sc-match-answer { grid-column: 2; grid-row: 1; margin-inline-end: calc(2ch - 0.4em); }\r
[data-study-cheetah-enhanced] [data-matching-prompts] .answer-blank { grid-column: 3; grid-row: 1; }\r
[data-study-cheetah-enhanced] .sc-match-result { grid-column: 4; grid-row: 1; width: 1em; height: 1em; }\r
[data-study-cheetah-enhanced] .sc-match-result svg {\r
  width: 100%;\r
  height: 100%;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 3.5;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] [data-result="correct"] { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] [data-result="incorrect"] { color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced] .sc-match-answer { text-align: right; min-width: 0; border-bottom: 0; color: var(--reader-page-fg, inherit); }\r
[data-study-cheetah-enhanced] .sc-match-check { color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced] .sc-match-reset { color: var(--reader-matching-reset, #a84300); }\r
[data-study-cheetah-enhanced] .sc-match-print { color: #000; background: #fff; }\r
[data-study-cheetah-enhanced] .sc-match-select {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  min-height: 0;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  color: var(--reader-page-fg, inherit);\r
}\r
[data-study-cheetah-enhanced] .sc-match-select[aria-pressed="true"] { border-color: currentColor; }\r
[data-study-cheetah-enhanced] ol:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
[data-study-cheetah-enhanced] .sc-match-footer { flex: 0 0 auto; margin-top: 0.75em; font-size: 0.8em; }\r
[data-study-cheetah-enhanced] .sc-match-footer p { margin: 0.35em 0; }\r
body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer p { margin: 0; }\r
[data-study-cheetah-enhanced] .sc-match-footer-row {\r
  display: grid;\r
  grid-template-columns: minmax(6em, 1fr) minmax(0, max-content);\r
  gap: 0.5em;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced] .sc-match-status { min-width: 0; }\r
[data-study-cheetah-enhanced] .sc-match-controls { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-match-controls .sc-activity-button {\r
  display: inline-flex;\r
  align-items: center;\r
  justify-content: center;\r
  gap: 0.5em;\r
}\r
[data-study-cheetah-enhanced] .sc-match-controls svg {\r
  flex: 0 0 auto;\r
  width: 1.2em;\r
  height: 1.2em;\r
  fill: none;\r
  stroke: currentColor;\r
  stroke-width: 2;\r
  stroke-linecap: round;\r
  stroke-linejoin: round;\r
}\r
[data-study-cheetah-enhanced] .sc-match-announcement {\r
  position: absolute;\r
  width: 1px;\r
  height: 1px;\r
  overflow: hidden;\r
  clip-path: inset(50%);\r
  white-space: nowrap;\r
}\r
[data-study-cheetah-enhanced] .sc-match-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
\r
@media (orientation: landscape) {\r
  body:has(> [data-study-cheetah-enhanced="matching-v1"]) {\r
    padding-inline-end: 48px;\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] {\r
    --sc-match-sidebar-width: clamp(7rem, 15vw, 10rem);\r
    position: relative;\r
    padding-inline-end: calc(var(--sc-match-sidebar-width) + 1rem);\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer {\r
    position: absolute;\r
    inset-block-end: 0;\r
    inset-inline-end: 0;\r
    width: var(--sc-match-sidebar-width);\r
    max-height: 100%;\r
    margin-top: 0;\r
    overflow-y: auto;\r
    overflow-wrap: anywhere;\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-footer-row {\r
    grid-template-columns: minmax(0, 1fr);\r
  }\r
  body > [data-study-cheetah-enhanced="matching-v1"] .sc-match-controls {\r
    flex-direction: column;\r
    flex-wrap: nowrap;\r
  }\r
}\r
`,at=`[data-study-cheetah-enhanced] .worksheet-name { display: none; }\r
[data-study-cheetah-enhanced] .sc-activity-button {\r
  box-sizing: border-box;\r
  min-height: 44px;\r
  padding: 0.3em 0.6em;\r
  border: 1px solid currentColor;\r
  border-radius: 3px;\r
  font: inherit;\r
  font-weight: bold;\r
  color: inherit;\r
  background: transparent;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced] .sc-activity-button:disabled { cursor: default; }\r
[data-study-cheetah-enhanced] .sc-activity-button:focus-visible { outline: 2px solid currentColor; outline-offset: 2px; }\r
@media print {\r
  .study-cheetah-activity-ui { display: none !important; }\r
}\r
`;function Z(e,t){let n=e.ownerDocument,r=[];function i(e,t,n){let i=e.getAttribute(t);e.setAttribute(t,n),r.push(()=>{i===null?e.removeAttribute(t):e.setAttribute(t,i)})}function a(e,t,i){let a=n.createElement(t);return a.className=`study-cheetah-activity-ui ${i}`,e.append(a),r.push(()=>a.remove()),a}function o(e,t,n){let i=a(e,`button`,`sc-activity-button`);return i.type=`button`,i.textContent=t,i.addEventListener(`click`,n),r.push(()=>i.removeEventListener(`click`,n)),i}let s=n.createElement(`style`);return s.textContent=`${at}\n${t}`,n.head.append(s),r.push(()=>s.remove()),{doc:n,cleanups:r,attribute:i,append:a,button:o}}function ot(e,t,n){let{doc:r,cleanups:i,attribute:a,append:o,button:s}=Z(e,it),c=ue.getInstance(),l=[...e.querySelectorAll(`[data-matching-prompts] > li`)],u=[...e.querySelectorAll(`[data-matching-choices] > li`)],d=[...e.querySelectorAll(`[data-matching-prompts], [data-matching-choices]`)],f={},p=null,m=!1,h=0,g=!1,_=null,v=``,y={promptIds:t.prompts.map(e=>e.id),choiceIds:t.choices.map(e=>e.id)};function b(e,t,n){let r=e.querySelector(t)??o(e,`span`,n);a(r,`class`,`${r.className} ${n}`),a(r,`aria-hidden`,`true`);let s=r.textContent;return i.push(()=>{r.textContent=s}),r}try{let e=c.getMatchingProgress(n.publicationId,t);e&&(f=e.answers,m=e.submitted,h=e.attempts),y=Object.keys(f).length>0?e?.order??y:n.order??Y(t)}catch(e){g=!0,P(e)}n.onorder?.(y);function x(e){return ie(y.choiceIds.indexOf(e))}a(e,`data-study-cheetah-enhanced`,`matching-v1`);for(let t of e.querySelectorAll(`:scope > p`))t.textContent?.trim()===`Match the Greek word with the correct English translation. Write the English meaning and its letter beside each Greek word.`&&a(t,`data-study-cheetah-matching-instructions`,``);for(let[e,t]of d.entries())a(t,`tabindex`,`0`),a(t,`aria-label`,e===0?`Greek words list`:`English meanings list`);let S=l.map((e,n)=>{let r=t.prompts[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.promptIds.indexOf(r.id)};`);let i=b(e,`.matching-answer`,`sc-match-answer`),o=b(e,`.answer-blank`,`answer-blank`),c=b(e,`.matching-result`,`sc-match-result`),l=s(e,``,()=>{p=r.id,v=`Choose an English meaning for ${r.id}.`,I()});return l.classList.add(`sc-match-select`),l.setAttribute(`aria-label`,`Greek ${r.id}: ${r.text}`),{answer:i,blank:o,result:c,control:l}}),C=u.map((e,n)=>{let r=t.choices[n];a(e,`style`,`${e.getAttribute(`style`)??``}; order: ${y.choiceIds.indexOf(r.id)};`),a(e,`data-choice-label`,x(r.id));let i=s(e,``,()=>{!p||g||(f=se(t,f,p,r.id),v=`Matched ${p} with ${r.text}.`,p=null,m=!1,F(),I())});return i.classList.add(`sc-match-select`),i.setAttribute(`aria-label`,`English: ${r.text}`),{control:i}}),w=o(e,`div`,`sc-match-footer`),T=o(w,`p`,`sc-match-error`);T.setAttribute(`role`,`alert`);let E=o(w,`div`,`sc-match-footer-row`),D=o(E,`p`,`sc-match-status`);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=o(D,`span`,``),k=o(D,`span`,`sc-match-announcement`),A=o(E,`div`,`sc-match-controls`),j=s(A,`Check answers`,()=>{m=!0,h+=1,v=``,F(),I()});j.classList.add(`sc-match-check`);let M=s(A,`Reset answers`,()=>{try{c.deleteMatchingProgress(n.publicationId,t),f={},p=null,m=!1,g=!1,v=`Answers cleared.`,F()}catch(e){P(e)}I()});M.classList.add(`sc-match-reset`);let N=s(A,`Print worksheet`,n.onprint);N.classList.add(`sc-match-print`);for(let[e,t,n]of[[j,`Check`,`M5 12l4 4L19 6`],[M,`Reset`,`M3 3v6h6M3 9a9 9 0 1 1 2.6 9.4`],[N,`Print`,`M6 9V3h12v6M6 18H3V9h18v9h-3M6 14h12v7H6zM17 12h1`]]){e.setAttribute(`aria-label`,e.textContent),e.textContent=``;let i=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);i.setAttribute(`viewBox`,`0 0 24 24`),i.setAttribute(`aria-hidden`,`true`),i.setAttribute(`focusable`,`false`);let a=r.createElementNS(i.namespaceURI,`path`);a.setAttribute(`d`,n),i.append(a),e.append(i),o(e,`span`,``).textContent=t}function P(e){console.error(`[Reader] Matching exercise progress:`,e),_=`Could not load or save exercise progress. ${e instanceof Error?e.message:String(e)}`}function F(){try{c.saveMatchingProgress(n.publicationId,t,{revision:t.revision,answers:f,submitted:m,attempts:h,updated:Date.now(),order:y}),_=null}catch(e){P(e)}}function I(){let e=Object.keys(f).length,n=U(t,f);O.textContent=`${m?`${n} of ${t.prompts.length} correct.${n===t.prompts.length?` Exercise complete.`:``}`:`${e} of ${t.prompts.length} matched.`} Checks: ${h}.`,k.textContent=` ${v}`,T.hidden=_===null,T.textContent=_,j.disabled=g||e===0;for(let[e,{control:n,answer:i,blank:a,result:o}]of S.entries()){let s=t.prompts[e],c=t.choices.findIndex(e=>e.id===f[s.id]),l=t.choices[c],u=m&&!!l,d=l?.answerId===s.id;if(i.textContent=l?.text??``,a.textContent=l?x(l.id):``,l?.language?i.lang=l.language:i.removeAttribute(`lang`),n.disabled=g,n.setAttribute(`aria-pressed`,String(p===s.id)),n.setAttribute(`aria-description`,`${l?`Matches ${l.text}`:`Not matched`}${u?d?` Correct`:` Incorrect`:``}`),o.replaceChildren(),u){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`svg`);e.setAttribute(`viewBox`,`0 0 20 20`),e.setAttribute(`data-result`,d?`correct`:`incorrect`);let t=r.createElementNS(e.namespaceURI,`path`);t.setAttribute(`d`,d?`M3 10l4 4L17 4`:`M4 4l12 12M16 4L4 16`),e.append(t),o.append(e)}}for(let[e,{control:n}]of C.entries()){let r=t.choices[e],i=Object.entries(f).find(([,e])=>e===r.id)?.[0];n.disabled=g||!p,n.setAttribute(`aria-description`,`Choice ${x(r.id)}. ${i?`Used by ${i}`:`Not used`}`)}}return I(),()=>{for(let e of i.reverse())e()}}function st(e,t,n,r){let i=e.contentDocument,a=i?.defaultView,o=e.parentElement;if(!i||!a||!o)throw Error(`Matching publication frame is unavailable.`);let s=e.ownerDocument.createElement(`iframe`);s.className=`reader-matching-frame`,s.title=`Matching exercise: ${n.title}`,s.style.cssText=`position:absolute;inset:0;width:100%;height:100%;border:0;`,o.append(s);let c=s.contentDocument;if(!c)throw s.remove(),Error(`Could not create the reader-owned matching frame.`);let l=c.createElement(`meta`);l.httpEquiv=`Content-Security-Policy`,l.content=`default-src 'none'; style-src 'unsafe-inline'`,c.head.append(l),c.title=n.title,c.documentElement.lang=i.documentElement.lang;let u=c.createElement(`style`);u.textContent=`
    html, body { box-sizing: border-box; margin: 0; width: 100%; height: 100%; overflow: hidden; }
    h1 { margin: 0 0 1em; font-size: 1.3em; }
    h2 { margin: 0 0 0.75em; font-size: 1.1em; }
  `,c.head.append(u);let d=c.createElement(`main`);d.setAttribute(`data-study-cheetah-activity`,n.kind),d.setAttribute(`data-activity-id`,n.id),d.setAttribute(`data-activity-revision`,n.revision),n.chapterTitle&&d.setAttribute(`data-chapter-title`,n.chapterTitle);let f=c.createElement(`h1`);f.textContent=n.title,d.append(f);for(let e of t.querySelectorAll(`:scope > p`)){if(a.getComputedStyle(e).display===`none`)continue;let t=c.createElement(`p`);t.textContent=e.textContent,d.append(t)}let p=c.createElement(`div`);p.className=`matching-columns`;for(let[e,t,r]of[[`Greek words`,n.prompts,!0],[`English meanings`,n.choices,!1]]){let n=c.createElement(`section`),i=c.createElement(`h2`);i.textContent=e;let a=c.createElement(`ol`);a.setAttribute(r?`data-matching-prompts`:`data-matching-choices`,``);for(let e of t){let t=c.createElement(`li`);t.setAttribute(r?`data-match-id`:`data-choice-id`,e.id);let n=c.createElement(`span`);n.setAttribute(r?`data-prompt-text`:`data-choice-text`,``),n.textContent=e.text,e.language&&(n.lang=e.language,t.lang=e.language),t.append(n),a.append(t)}n.append(i,a),p.append(n)}d.append(p),c.body.append(d);let m;try{m=ot(d,n,r)}catch(e){throw s.remove(),e}let h=e.getAttribute(`aria-hidden`),g=e.getAttribute(`tabindex`),_=e.style.opacity;e.setAttribute(`aria-hidden`,`true`),e.setAttribute(`tabindex`,`-1`),e.setAttribute(`data-reader-matching-source`,``),e.style.opacity=`0`;let v=()=>{let e=a.getComputedStyle(i.body),n=a.getComputedStyle(i.documentElement);c.documentElement.style.fontSize=n.fontSize,c.documentElement.style.backgroundColor=n.backgroundColor;for(let t of[`width`,`height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`,`padding-top`,`padding-right`,`padding-bottom`,`padding-left`,`transform`,`transform-origin`,`font-size`,`font-family`,`line-height`,`color`,`background-color`,`--reader-page-fg`,`--reader-matching-correct`,`--reader-matching-incorrect`,`--reader-matching-reset`,`--reader-matching-greek`])c.body.style.setProperty(t,e.getPropertyValue(t));c.body.style.lineHeight=e.lineHeight===`normal`?`normal`:String(parseFloat(e.lineHeight)/parseFloat(e.fontSize));let r=[...t.querySelectorAll(`h1,h2`)];for(let[e,t]of[...d.querySelectorAll(`h1,h2`)].entries()){let n=r[e];if(!n)continue;let i=a.getComputedStyle(n);for(let e of[`font-size`,`font-family`,`font-weight`,`line-height`,`margin-top`,`margin-right`,`margin-bottom`,`margin-left`])t.style.setProperty(e,i.getPropertyValue(e))}};v();let y=new MutationObserver(v);y.observe(i.head,{subtree:!0,childList:!0,characterData:!0,attributes:!0}),y.observe(i.body,{attributes:!0}),y.observe(i.documentElement,{attributes:!0});let b=new ResizeObserver(v);return b.observe(e),()=>{y.disconnect(),b.disconnect(),m(),s.remove(),e.removeAttribute(`data-reader-matching-source`),h===null?e.removeAttribute(`aria-hidden`):e.setAttribute(`aria-hidden`,h),g===null?e.removeAttribute(`tabindex`):e.setAttribute(`tabindex`,g),e.style.opacity=_}}var ct=`[data-study-cheetah-enhanced="word-search-v1"] {\r
  box-sizing: border-box;\r
  display: flex;\r
  flex-direction: column;\r
  justify-content: safe center;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
  color: inherit;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] {\r
  display: grid;\r
  grid-template-columns: minmax(0, 1fr);\r
  gap: 0.6em 1em;\r
  align-items: start;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) {\r
  grid-template-columns: minmax(0, var(--sc-word-search-width, 1fr)) max-content;\r
  justify-content: center;\r
  align-items: center;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  grid-template-columns: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) .word-search-vocabulary {\r
  display: grid;\r
  grid-template-rows: auto minmax(0, 1fr);\r
  max-height: var(--sc-word-search-height);\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] :is([data-word-search-measure="side"], [data-word-search-fit="side"]:not([data-word-search-measure])) [data-word-search-words] {\r
  min-height: 0;\r
  padding-block: 0.15em;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .word-search-vocabulary h2 {\r
  font-size: 1.1em;\r
  margin: 0 0 0.4em;\r
  text-decoration: underline;\r
  text-underline-offset: 0.15em;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] [data-word-search-grid] {\r
  width: var(--sc-word-search-width, 100%);\r
  min-width: 0;\r
  max-width: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-fit] td > span {\r
  block-size: var(--sc-word-search-cell, auto);\r
  font-size: max(1em, var(--sc-word-search-letter, 1em));\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-cell {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  padding: 0;\r
  border: 2px solid transparent;\r
  background: transparent;\r
  color: var(--reader-page-fg, inherit);\r
  cursor: pointer;\r
  touch-action: none;\r
  user-select: none;\r
}\r
[data-study-cheetah-enhanced="word-search-v1"] [data-word-search-grid] { user-select: none; touch-action: none; }\r
.sc-word-search-cell.sc-word-search-selected { border-color: currentColor; }\r
.sc-word-search-cell.sc-word-search-found { background: color-mix(in srgb, var(--reader-matching-correct, #166534) 20%, transparent); }\r
.sc-word-search-cell:focus-visible { outline: 2px solid currentColor; outline-offset: -3px; }\r
[data-study-cheetah-enhanced="word-search-v1"] .sc-word-search-found-word {\r
  color: var(--reader-matching-correct, #166534);\r
  font-weight: bold;\r
  text-decoration: line-through;\r
}\r
.sc-word-search-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-word-search-footer p { margin: 0.35em 0; }\r
.sc-word-search-controls { display: flex; flex-wrap: wrap; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-word-search-reset { color: var(--reader-matching-reset, #a84300); }\r
[data-study-cheetah-enhanced] .sc-word-search-print { color: #000; background: #fff; }\r
.sc-word-search-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
`;function lt(e,t,n){let r=e.querySelector(`[data-word-search-grid]`),i=[...e.querySelectorAll(`[data-word-search-grid] td`)];if(!r||i.length!==t.grid.length*t.grid[0].length)throw Error(`The word-search grid does not match its worksheet.`);let{doc:a,cleanups:o,attribute:s,append:c,button:l}=Z(e,ct),u=ue.getInstance(),d=t.grid[0].length,f=[],p=null,m=null,h=null,g=null,_=!1,v=0,y=!1,b=null,x=``;function S(e){console.error(`[Reader] Word-search progress:`,e),b=`Could not load or save puzzle progress. ${e instanceof Error?e.message:String(e)}`}try{f=u.getWordSearchProgress(n.publicationId,t)?.found??[]}catch(e){y=!0,S(e)}s(e,`data-study-cheetah-enhanced`,`word-search-v1`),s(r,`role`,`grid`),s(r,`aria-rowcount`,String(t.grid.length)),s(r,`aria-colcount`,String(d));let C=i.map((e,n)=>{s(e,`role`,`gridcell`);let r=e.querySelector(`span`);r&&s(r,`aria-hidden`,`true`);let i=c(e,`button`,`sc-word-search-cell`);return i.type=`button`,i.dataset.cellIndex=String(n),i.setAttribute(`aria-label`,`Row ${Math.floor(n/d)+1}, column ${n%d+1}: ${t.grid.join(``)[n]}`),i}),w=c(e,`div`,`sc-word-search-footer`),T=c(w,`p`,``);T.textContent=`Drag from the first letter to the last, or tap both ends. Keyboard: use arrow keys, Enter or Space to select each end, and Escape to cancel.`;let E=c(w,`p`,``);E.setAttribute(`role`,`status`),E.setAttribute(`aria-live`,`polite`);let D=c(w,`p`,`sc-word-search-error`);D.setAttribute(`role`,`alert`);let O=c(w,`div`,`sc-word-search-controls`);l(O,`Reset puzzle`,()=>{try{u.deleteWordSearchProgress(n.publicationId,t),f=[],p=null,y=!1,x=`Found words cleared.`,j()}catch(e){S(e)}V()}).classList.add(`sc-word-search-reset`),l(O,`Print worksheet`,n.onprint).classList.add(`sc-word-search-print`);let k=c(w,`p`,``),A=[...e.querySelectorAll(`[data-word-search-words] > li`)];for(let e of A)s(e,`class`,e.className);function j(){try{u.saveWordSearchProgress(n.publicationId,t,{revision:t.revision,puzzle:le(t),found:f,updated:Date.now()}),b=null}catch(e){S(e)}}function M(e,n){let r=J(t,e,n);r?f.some(e=>e.wordId===r.id)?x=`${r.text} is already found.`:(f=[...f,{wordId:r.id,start:e,end:n}],x=`Found ${r.text}.`,j()):x=`No listed word selected. Choose a straight row, column, or diagonal.`,p=null}function N(e){y||(v=e,p===null?(p=e,x=`First letter selected. Choose the last letter.`):M(p,e),V())}function P(e){let t=a.elementFromPoint(e.clientX,e.clientY)?.closest(`.sc-word-search-cell`);return t&&r.contains(t)?Number(t.dataset.cellIndex):null}let F=e=>{if(y||e.button!==0||g!==null)return;let t=P(e);t!==null&&(e.preventDefault(),m=h=t,g=e.pointerId,_=!1,v=t,C[t].focus({preventScroll:!0}),r.setPointerCapture(e.pointerId))},I=e=>{if(e.pointerId!==g||m===null)return;let t=P(e);t!==h&&(h=t,h!==null&&h!==m&&(_=!0),V())},L=e=>{if(e.pointerId!==g||m===null)return;let t=P(e);t===null?(p=null,x=`Selection cancelled.`):_?M(m,t):N(t),g=m=h=null,V()},R=()=>{g=m=h=p=null,V()},z=e=>{let t=e.target.closest(`.sc-word-search-cell`);e.detail===0&&t&&N(Number(t.dataset.cellIndex))},B=e=>{let t=e.target.closest(`.sc-word-search-cell`);if(!t||e.altKey||e.ctrlKey||e.metaKey)return;let n=Number(t.dataset.cellIndex),r=n;if(e.key===`ArrowLeft`)r=n%d?n-1:n;else if(e.key===`ArrowRight`)r=n%d<d-1?n+1:n;else if(e.key===`ArrowUp`)r=Math.max(n-d,n%d);else if(e.key===`ArrowDown`)r=Math.min(n+d,i.length-d+n%d);else if(e.key===`Enter`||e.key===` `)N(n);else if(e.key===`Escape`)p=null,x=`Selection cancelled.`;else return;e.preventDefault(),v=r,V(),C[r].focus()};r.addEventListener(`pointerdown`,F),r.addEventListener(`pointermove`,I),r.addEventListener(`pointerup`,L),r.addEventListener(`pointercancel`,R),r.addEventListener(`click`,z),r.addEventListener(`keydown`,B),o.push(()=>{r.removeEventListener(`pointerdown`,F),r.removeEventListener(`pointermove`,I),r.removeEventListener(`pointerup`,L),r.removeEventListener(`pointercancel`,R),r.removeEventListener(`click`,z),r.removeEventListener(`keydown`,B)});function V(){let e=new Set(f.flatMap(e=>G(t,e.start,e.end)??[])),n=new Set(m!==null&&h!==null&&_?G(t,m,h)??[]:p===null?[]:[p]);for(let[t,r]of C.entries())r.tabIndex=t===v?0:-1,r.disabled=y,r.classList.toggle(`sc-word-search-found`,e.has(t)),r.classList.toggle(`sc-word-search-selected`,n.has(t)),r.setAttribute(`aria-pressed`,String(n.has(t))),r.setAttribute(`aria-description`,e.has(t)?`Part of a found word`:`Not found`);for(let e of A)e.classList.toggle(`sc-word-search-found-word`,f.some(t=>t.wordId===e.dataset.wordId));E.textContent=`${f.length} of ${t.words.length} words found.${f.length===t.words.length?` Puzzle complete.`:``} ${x}`.trim(),D.hidden=b===null,D.textContent=b,k.textContent=b?`Progress is not saved.`:`Progress is saved on this device.`}V();let H=e.querySelector(`:scope > [data-word-search-layout]`),ee=H?.querySelector(`.word-search-vocabulary`);return H&&ee&&o.push(ut(e,H,r,ee,d,t.grid.length)),()=>{for(let e of o.reverse())e()}}function ut(e,t,n,r,i,a){let o=Array.from(e.children).filter(e=>e!==t),s=e=>Number.parseFloat(e)||0,c=r.querySelector(`[data-word-search-words]`),l=c.getAttribute(`tabindex`);t.dataset.wordSearchFit=`stack`;function u(){l===null?c.removeAttribute(`tabindex`):c.setAttribute(`tabindex`,l)}function d(){if(!e.clientHeight||!e.clientWidth)return;let l=getComputedStyle(e),d=o.filter(e=>getComputedStyle(e).display!==`none`),f=e.clientHeight-s(l.paddingTop)-s(l.paddingBottom)-s(l.rowGap)*d.length;for(let e of d){let t=getComputedStyle(e);f-=e.getBoundingClientRect().height+s(t.marginTop)+s(t.marginBottom)}t.dataset.wordSearchMeasure=`stack`;let p=getComputedStyle(t),m=t.clientWidth,h=Math.ceil(s(getComputedStyle(n).fontSize)*i),g=Math.max(h,Math.min(m,(f-r.offsetHeight-s(p.rowGap))*i/a));t.dataset.wordSearchMeasure=`side`;let _=m-r.offsetWidth-s(p.columnGap),v=Math.max(h,Math.min(_,f*i/a));delete t.dataset.wordSearchMeasure;let y=t.dataset.wordSearchFit===`side`,b=e.clientWidth>=e.clientHeight+(y?-4:4),x=_>=h+(y?0:4)&&(v>g+4||v>=g-(y?4:0)&&b||y&&v>g),S=Math.floor(x?v:g);x!==y&&(t.dataset.wordSearchFit=x?`side`:`stack`),t.style.setProperty(`--sc-word-search-width`,`${S}px`),t.style.setProperty(`--sc-word-search-cell`,`${S/i}px`),t.style.setProperty(`--sc-word-search-letter`,`${S/i*.58}px`),t.style.setProperty(`--sc-word-search-height`,`${S*a/i}px`),x&&c.scrollHeight>c.clientHeight?c.tabIndex=0:u()}let f=new ResizeObserver(d);f.observe(e),f.observe(r);for(let e of o)f.observe(e);return d(),()=>{f.disconnect(),delete t.dataset.wordSearchFit,t.style.removeProperty(`--sc-word-search-width`),t.style.removeProperty(`--sc-word-search-cell`),t.style.removeProperty(`--sc-word-search-letter`),t.style.removeProperty(`--sc-word-search-height`),u()}}var dt=`[data-study-cheetah-enhanced="crossword-v1"] {\r
  box-sizing: border-box;\r
  height: 100%;\r
  min-height: 0;\r
  overflow: auto;\r
  scrollbar-gutter: stable;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] > * { flex-shrink: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-layout {\r
  grid-template-columns: max-content var(--sc-crossword-width, minmax(0, 1fr));\r
  justify-content: center;\r
  min-width: max-content;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-grid { width: var(--sc-crossword-width, 100%); max-width: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues {\r
  display: grid;\r
  grid-template-rows: minmax(0, 1fr) minmax(0, 1fr);\r
  max-height: max(var(--sc-crossword-height), 10em);\r
  min-height: 0;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] [data-crossword-wide="true"] .crossword-clues {\r
  grid-template-columns: max-content max-content;\r
  grid-template-rows: minmax(0, 1fr);\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues section { display: grid; grid-template-rows: auto minmax(0, 1fr); min-height: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues h2 { margin: 0 0 0.4em; line-height: 1.2; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues ol { overflow: auto; min-height: 0; margin: 0; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-clues li { position: relative; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue {\r
  padding: 0.1em 0.2em;\r
  border: 1px solid transparent;\r
  color: inherit;\r
  background: transparent;\r
  font: inherit;\r
  text-align: left;\r
  cursor: pointer;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[aria-pressed="true"] { border-color: currentColor; font-weight: bold; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="correct"]::after { content: " \\2713"; color: var(--reader-matching-correct, #166534); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-clue[data-result="incorrect"]::after { content: " \\2717"; color: var(--reader-matching-incorrect, #b91c1c); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-input {\r
  position: absolute;\r
  inset: 0;\r
  width: 100%;\r
  height: 100%;\r
  box-sizing: border-box;\r
  border: 2px solid transparent;\r
  padding: 0;\r
  background: transparent;\r
  color: inherit;\r
  font: inherit;\r
  font-size: 1.25em;\r
  text-align: center;\r
  cursor: text;\r
}\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-number { pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .crossword-number { z-index: 1; pointer-events: none; }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-selected { background: color-mix(in srgb, currentColor 12%, transparent); }\r
[data-study-cheetah-enhanced="crossword-v1"] .sc-crossword-current { border-color: currentColor; }\r
[data-study-cheetah-enhanced="crossword-v1"] :is(.sc-crossword-input, .sc-crossword-clue):focus-visible { outline: 2px solid currentColor; outline-offset: -2px; }\r
.sc-crossword-footer { margin-top: 0.5em; font-size: 0.8em; }\r
.sc-crossword-footer p { margin: 0.35em 0; }\r
.sc-crossword-controls { display: flex; flex-wrap: wrap; gap: 0.5em; }\r
[data-study-cheetah-enhanced] .sc-crossword-reset { color: var(--reader-matching-reset, #a84300); }\r
[data-study-cheetah-enhanced] .sc-crossword-print { color: #000; background: #fff; }\r
.sc-crossword-error { border: 2px solid currentColor; padding: 0.5em; white-space: pre-wrap; }\r
`;function ft(e,t,n){let r=e.querySelector(`.crossword-grid`),i=[...e.querySelectorAll(`[data-entry-id]`)];if(!r||i.length!==t.clues.length)throw Error(`Crossword worksheet does not match its clues.`);let{cleanups:a,attribute:o,append:s,button:c}=Z(e,dt),l=ue.getInstance(),u={},d=t.clues[0],f=K(d)[0],p=d.direction,m=!1,h=0,g=!1,_=null,v=``,y=new Map;function b(e){console.error(`[Reader] Crossword progress:`,e),_=`Could not load or save crossword progress. ${e instanceof Error?e.message:String(e)}`}try{let e=l.getCrosswordProgress(n.publicationId,t);e&&(u=e.letters,m=e.submitted,h=e.attempts)}catch(e){g=!0,b(e)}o(e,`data-study-cheetah-enhanced`,`crossword-v1`),o(r,`role`,`grid`);let x=i.map((e,n)=>{let r=t.clues[n];for(let t of e.children)o(t,`hidden`,``);let i=c(e,`${r.number}. ${r.text}`,()=>{S(r,K(r)[0],!0)});return i.classList.add(`sc-crossword-clue`),i});function S(e,t,n){if(d=e,p=e.direction,f=t,v=`${e.number} ${e.direction}: ${e.text}.`,M(),n){let e=y.get(t);e?.focus(),e?.select()}}function C(e,n){let r=t.clues.filter(t=>K(t).includes(e)),i=r.find(e=>e.direction===p),a=r.find(e=>e.direction!==p),o=(n&&e===f?a:i)??i??a;o&&S(o,e,!1)}function w(){try{l.saveCrosswordProgress(n.publicationId,t,{revision:t.revision,puzzle:q(t),letters:u,submitted:m,attempts:h,updated:Date.now()}),_=null}catch(e){b(e)}}for(let[n,i]of t.cells.entries())for(let[c,l]of i.entries()){if(!l)continue;let i=r.rows[n].cells[c],h=ae(n,c);o(i,`role`,`gridcell`);let _=s(i,`input`,`sc-crossword-input`);_.type=`text`,_.lang=t.language,_.autocomplete=`off`,_.spellcheck=!1,_.dataset.crosswordCell=h,y.set(h,_);let b=!1,x=()=>{b=h===f&&e.ownerDocument.activeElement===_},S=()=>{h!==f&&C(h,!1),_.select()},T=()=>{b&&C(h,!0),b=!1,_.select()},E=e=>{if(h!==f||g)return;if(!e)delete u[h];else try{u[h]=te(e)}catch{v=`Enter one Greek letter per square.`,M(),_.select();return}m=!1,v=``,w();let t=K(d),n=t[t.indexOf(h)+1];e&&n&&(f=n),M(),e&&n?y.get(n)?.focus():_.select()},D=e=>{if(`isComposing`in e&&!e.isComposing&&`inputType`in e&&(e.inputType===`insertText`||e.inputType===`insertReplacementText`)&&`data`in e&&typeof e.data==`string`&&e.data)return e.data},O=e=>{let t=D(e);!e.cancelable||t===void 0||(e.preventDefault(),E(t))},k=e=>{if(!(`isComposing`in e&&e.isComposing)){if(h!==f){_.value=u[h]??``;return}E(D(e)??_.value)}},A=e=>{e.data?E(e.data):(_.value=u[h]??``,h===f&&_.select())},j=e=>{if(e.ctrlKey||e.metaKey||e.altKey||e.isComposing)return;if(e.key===`Enter`){e.preventDefault(),C(h,!0);return}let r={ArrowLeft:[0,-1,`across`],ArrowRight:[0,1,`across`],ArrowUp:[-1,0,`down`],ArrowDown:[1,0,`down`]}[e.key];if(!r)return;e.preventDefault();let[i,a,o]=r;for(let e=n+i,r=c+a;e>=0&&e<t.rows&&r>=0&&r<t.columns;e+=i,r+=a){let t=ae(e,r);if(y.has(t)){p=o,C(t,!1),y.get(t)?.focus();break}}};_.addEventListener(`pointerdown`,x),_.addEventListener(`focus`,S),_.addEventListener(`click`,T),_.addEventListener(`beforeinput`,O),_.addEventListener(`input`,k),_.addEventListener(`compositionend`,A),_.addEventListener(`keydown`,j),a.push(()=>{_.removeEventListener(`pointerdown`,x),_.removeEventListener(`focus`,S),_.removeEventListener(`click`,T),_.removeEventListener(`beforeinput`,O),_.removeEventListener(`input`,k),_.removeEventListener(`compositionend`,A),_.removeEventListener(`keydown`,j)})}let T=s(e,`div`,`sc-crossword-footer`),E=s(T,`p`,``);E.textContent=`Select a clue or square, then type Greek letters. Click a selected crossing again or press Enter to change direction. Use arrow keys to move.`;let D=s(T,`p`,``);D.setAttribute(`role`,`status`),D.setAttribute(`aria-live`,`polite`);let O=s(T,`p`,`sc-crossword-error`);O.setAttribute(`role`,`alert`);let k=s(T,`div`,`sc-crossword-controls`),A=c(k,`Check answers`,()=>{m=!0,h++,v=``,w(),M()});c(k,`Reset puzzle`,()=>{try{l.deleteCrosswordProgress(n.publicationId,t),u={},m=!1,h=0,g=!1,v=`Answers cleared.`,w()}catch(e){b(e)}M()}).classList.add(`sc-crossword-reset`),c(k,`Print worksheet`,n.onprint).classList.add(`sc-crossword-print`);let j=s(T,`p`,``);function M(){let e=K(d),n=t.clues.filter(e=>W(e,u)).length;D.textContent=`${m?`${n} of ${t.clues.length} correct.${n===t.clues.length?` Puzzle complete.`:``}`:`${Object.keys(u).length} of ${y.size} squares filled. Not checked.`} ${v}`.trim(),O.hidden=_===null,O.textContent=_,j.textContent=`Checks: ${h}. ${_?`Progress is not saved.`:`Progress is saved on this device.`}`,A.disabled=g||Object.keys(u).length===0,x.forEach((e,n)=>{e.disabled=g,e.setAttribute(`aria-pressed`,String(t.clues[n].id===d.id));let r=t.clues[n],i=K(r),a=m&&i.some(e=>u[e])?W(r,u)?`correct`:`incorrect`:``;e.dataset.result=a,e.setAttribute(`aria-description`,a===`correct`?`Correct`:a===`incorrect`?`Not correct`:`Not checked`)});for(let[n,r]of y){let[i,a]=n.split(`,`).map(Number),o=u[n]??``;r.value!==o&&(r.value=o),r.disabled=g,r.tabIndex=n===f?0:-1,r.classList.toggle(`sc-crossword-selected`,e.includes(n)),r.classList.toggle(`sc-crossword-current`,n===f);let s=t.clues.filter(e=>K(e).includes(n)).map(e=>`${e.number} ${e.direction}: ${e.text}`).join(`; `);r.setAttribute(`aria-label`,`Row ${i+1}, column ${a+1}. ${s}`)}}M();let N=e.querySelector(`.crossword-layout`),P=N?.querySelector(`.crossword-clues`);if(N&&P){let n=[...e.children].filter(e=>e!==N),r=e=>Number.parseFloat(e)||0,i=()=>{if(!e.clientHeight||!e.clientWidth)return;let i=getComputedStyle(e),a=n.filter(e=>getComputedStyle(e).display!==`none`),o=e.clientHeight-r(i.paddingTop)-r(i.paddingBottom)-r(i.rowGap)*a.length;for(let e of a){let t=getComputedStyle(e);o-=e.getBoundingClientRect().height+r(t.marginTop)+r(t.marginBottom)}o-=t.rows+2,N.dataset.crosswordWide=String(e.clientWidth>=700);let s=r(getComputedStyle(N).columnGap),c=e.clientWidth-P.offsetWidth-s,l=t.columns*24,u=Math.floor(Math.max(l,Math.min(c,o*t.columns/t.rows)));N.style.setProperty(`--sc-crossword-width`,`${u}px`),N.style.setProperty(`--sc-crossword-height`,`${Math.ceil(u*t.rows/t.columns)}px`)},o=new ResizeObserver(i);o.observe(e);for(let e of n)o.observe(e);i(),a.push(()=>{o.disconnect(),N.style.removeProperty(`--sc-crossword-width`),N.style.removeProperty(`--sc-crossword-height`),delete N.dataset.crosswordWide})}return()=>{for(let e of a.reverse())e()}}function pt(e){let{pointerX:t,pointerY:n,screenWidth:r,screenHeight:i,hasPreviousChapter:a,hasNextChapter:o}=e,s=r*.33,c=r*.67,l=i*.33,u=i*.67;return t<s&&a?`previous`:t>c&&o?`next`:t>=s&&t<=c&&n>=l&&n<=u?`toggle-ui`:`none`}var mt=p(`<div class="loading-overlay svelte-1jg2usx"><div class="spinner svelte-1jg2usx" aria-hidden="true"></div> <p>Opening book...</p></div>`),ht=p(`<div class="error-overlay svelte-1jg2usx" role="alert"><p class="error-title svelte-1jg2usx">Could not open book</p> <p class="error-body svelte-1jg2usx"> </p> <button class="svelte-1jg2usx">Back to library</button></div>`),gt=p(`<img alt="" class="cover-image"/>`),_t=p(`<p> </p>`),vt=p(`<div class="cover-fallback" aria-hidden="true"><p> </p> <!></div>`),yt=p(`<button class="cover-overlay" type="button" aria-label="Start reading"><div class="cover-page svelte-1jg2usx" role="img"><!></div></button>`),bt=p(`<p class="save-error svelte-1jg2usx" role="alert"> </p>`),xt=p(`<div aria-hidden="true"></div> <div aria-hidden="true"></div>`,1),St=p(`<div role="main"><dialog class="safari-warning svelte-1jg2usx" aria-labelledby="safari-warning-title" aria-describedby="safari-warning-description"><h2 id="safari-warning-title" class="svelte-1jg2usx">Safari reader limitations</h2> <p id="safari-warning-description" class="svelte-1jg2usx">Tap the left or right edge to turn pages. Other book interactions and
      some keyboard shortcuts may not work in Safari. Use the
      header or footer to show the chapter menu and position slider.</p> <form method="dialog"><button type="submit" class="svelte-1jg2usx">Continue reading</button></form></dialog> <!> <!> <div class="epub-viewport svelte-1jg2usx"><!> <!> <!> <!></div> <!></div> <!>`,1);function Ct(r,o){S(o,!0);let l=`study-cheetah.reader.display-mode`,p=ue.getInstance(),_=de.getInstance(),v=H(),b=j(null),x=j(i([])),C=j(0),w=j(`best-fit`),O=j(null),P=j(1),F=j(!0),I=j(!1),L=j(!0),R=j(!0),z=j(null),U=j(null),W=j(null),te=j(null),G=j(null),ie=j(void 0),ae=j([]),se=j(new Map),K=j(new Map),le=j(null),q,J=null,Y=!1,he=!1,ge,_e,ve,ye=0,be=0,xe=0,Se=!1,Ce=Promise.resolve(),Te=!1,Ee=new AbortController,De=new Map,Oe=new Map,ke=g(()=>c(x)[c(C)]),Ae=g(()=>c(ae).find(e=>c(O)&&e.spineIndex>=c(O).start.index&&e.spineIndex<=c(O).end.index)?.activity),je=g(()=>{let e=c(O);if(!e||c(I)||c(R)||c(z))return null;let t=t=>t>=e.start.index&&t<=e.end.index;return[...c(se).values()].some(t)?[...c(K).values()].some(t)?`activity`:`ordinary`:null}),Me=g(()=>c(le)??c(Ae)),Ne=g(()=>c(O)?.atEnd?100:Math.round((c(O)?.start.percentage??0)*100)),Fe=g(()=>ee(c(b)?.accessibility.theme??`adaptive`)),Ie=g(()=>`Section page ${c(O)?.start.displayed.page??1} of ${c(O)?.start.displayed.total??1}`),Le=g(()=>c(I)?`Tap to start reading`:`${c(Ne)}% complete`),Re;function X(e,t){Y||(console.error(`[Reader] ${e}:`,t),s(z,`${t instanceof Error?t.message:String(t)}\n\nStage: ${e}`))}function ze(){let e=new URLSearchParams(window.location.search),t=e.get(`mode`)??(e.has(`horizontalPaging`)||e.has(`twoPage`)?null:localStorage.getItem(l));if(t===`scroll`||t===`single`||t===`spread`||t===`best-fit`)return t;t!==null&&console.warn(`[Reader] Unrecognized reading view:`,t);let n=e.get(`horizontalPaging`)??localStorage.getItem(`study-cheetah.reader.horizontal-paging`),r=e.get(`twoPage`)??localStorage.getItem(`study-cheetah.reader.two-page`);return n===`1`||n===`true`?`single`:r===`1`||r===`true`?`spread`:n===`0`||n===`false`?`scroll`:`best-fit`}function Be(){if(!c(b)||!Te)return Ce;Te=!1;let e=c(b);return Ce=Ce.then(()=>p.updateBook(e)).then(()=>{s(U,null)}).catch(e=>{console.error(`[Reader] Saving reading preferences and position failed:`,e),Te=!0,s(U,`Could not save your reading position and preferences.`)}),Ce}function Ve(){if(Te=!0,c(b))try{p.checkpointReadingState(c(b))}catch(e){console.error(`[Reader] Checkpointing reading preferences and position failed:`,e),s(U,`Could not save your reading position and preferences.`)}clearTimeout(ve),ve=setTimeout(()=>{Be()},500)}function He(e){if(s(O,e),c(x)[c(C)]?.spineIndex!==e.start.index){let t=c(x).findIndex(t=>t.spineIndex===e.start.index);t>=0&&s(C,t,!0)}!c(b)||he||Y||(s(b,{...c(b),currentLocation:{chapterId:c(ke)?.id??String(e.start.index),chapterIndex:c(C),elementOffset:0,percentageComplete:Math.round((e.start.percentage??0)*100),cfiFragment:e.start.cfi}},!0),Ve())}function Ue(e){if(e!==J||Y)return;let t=e.currentLocation();t&&He(t)}function We(){for(let e of De.values())e();De.clear(),s(ae,[]),s(se,new Map),s(K,new Map)}function Ge(e){let t=!1,n=()=>{t=!0};return e.addEventListener(`study-cheetah-event-probe`,n),e.dispatchEvent(new Event(`study-cheetah-event-probe`)),e.removeEventListener(`study-cheetah-event-probe`,n),t}function Ke(e){return!!e&&`closest`in e&&typeof e.closest==`function`&&!!e.closest(`a, button, input, select, textarea, summary, [contenteditable="true"], [role="button"], [role="link"], [data-study-cheetah-enhanced]`)}function qe(e){if(document.querySelector(`dialog[open]`)||e.defaultPrevented||e.ctrlKey||e.metaKey||Ke(e.target))return;if(e.altKey){!e.shiftKey&&(e.key===`ArrowUp`||e.key===`ArrowDown`)&&(e.preventDefault(),dt(e.key===`ArrowDown`?1:-1));return}if(e.key===`Escape`){e.preventDefault(),Je();return}let t=e.key===`ArrowRight`||e.key===`PageDown`,n=e.key===`ArrowLeft`||e.key===`PageUp`;!t&&!n||(e.preventDefault(),ct(t?1:-1))}function Je(){clearTimeout(ge),s(F,!c(F)),c(F)&&Ye()}function Ye(){clearTimeout(ge),ge=setTimeout(()=>{document.querySelector(`.reading-footer .chapter-menu, dialog[open]`)?Ye():s(F,!1)},5e3)}function Xe(e,t){if(c(I)||c(R)||document.querySelector(`dialog[open]`))return;if(!c(F)&&(t<=60||t>=window.innerHeight-60)){Je();return}let n=pt({pointerX:e,pointerY:t,screenWidth:window.innerWidth,screenHeight:window.innerHeight,hasPreviousChapter:!0,hasNextChapter:!c(O)?.atEnd});n===`toggle-ui`?Je():(n===`next`||n===`previous`)&&ct(n===`next`?1:-1)}function Ze(e){e.on(`relocated`,t=>{e===J&&!Y&&He(t)}),e.on(`layout`,t=>{e===J&&s(P,t.divisor,!0)}),e.on(`rendered`,(t,n)=>{if(e!==J||Y)return;De.get(n.id)?.();let r=n.document,i=n.iframe;if(!r||!i)return;i.title=`Book content`;let a=Ge(r),o=n.section.index;if(typeof o==`number`){let e=new Map(c(se)),t=new Map(c(K));a?e.delete(n.id):e.set(n.id,o),r.querySelector(`[data-study-cheetah-activity]`)?t.set(n.id,o):t.delete(n.id),s(se,e),s(K,t)}let l=[],u=new Set,d=c(te);if(d){let e=[];for(let t of d.features){let o=[];try{let s=n.section.index;if(typeof s!=`number`)throw Error(`Exercise reading-order position is unavailable.`);let c=[...r.querySelectorAll(`[data-study-cheetah-activity="${t}"]`)].map(e=>{let c=t===`word-search-v1`?ne(e):t===`crossword-v1`?oe(e):re(e),l={publicationId:d.publicationId,onprint:()=>{$e(c)}};if(c.kind===`word-search-v1`)o.push(lt(e,c,l));else if(c.kind===`crossword-v1`)o.push(ft(e,c,l));else{let t=JSON.stringify([d.publicationId,c.id,c.revision]);o.push(ot(e,c,{...l,order:Oe.get(t),onorder:e=>{Oe.set(t,e)}})),!a&&e.parentElement===r.body&&o.push(st(i,e,c,{...l,order:Oe.get(t),onorder:e=>{Oe.set(t,e)}}))}return{viewId:n.id,spineIndex:s,activity:c}});e.push(...c),l.push(...o)}catch(e){u.add(t);for(let e of o)e();console.error(`[Reader] Invalid ${t} exercise:`,e),s(W,`Interactive exercise unavailable: ${e instanceof Error?e.message:String(e)}`)}}s(ae,[...c(ae).filter(e=>e.viewId!==n.id),...e])}if(c(G)){let e=c(G).active.filter(e=>!u.has(e));l.push(ce(r,c(G),e))}let f=0,p=0,m=e=>{f=e.clientX,p=e.clientY},h=e=>{if(Ke(e.target)||r.getSelection()?.isCollapsed===!1||Math.hypot(e.clientX-f,e.clientY-p)>10)return;let t=i.getBoundingClientRect();Xe(t.left+e.clientX,t.top+e.clientY)};r.addEventListener(`pointerdown`,m),r.addEventListener(`pointerup`,h),r.addEventListener(`keydown`,qe),De.set(n.id,()=>{for(let e of l)e();r.removeEventListener(`pointerdown`,m),r.removeEventListener(`pointerup`,h),r.removeEventListener(`keydown`,qe)})}),e.on(`removed`,(e,t)=>{De.get(t.id)?.(),De.delete(t.id),s(ae,c(ae).filter(e=>e.viewId!==t.id));let n=new Map(c(se)),r=new Map(c(K));n.delete(t.id),r.delete(t.id),s(se,n),s(K,r)}),e.on(`displayerror`,t=>{e===J&&!Y&&X(`chapter-display`,t)})}async function $e(e){s(le,e,!0);try{await u(),window.print()}catch(e){console.error(`[Reader] Printing worksheet failed:`,e),s(W,`Could not print worksheet: ${e instanceof Error?e.message:String(e)}`)}finally{s(le,null)}}async function et(e,t){let n,r=()=>{},i=new Promise((t,i)=>{r=i,n=setTimeout(()=>i(Error(`Chapter rendering timed out (15s).`)),15e3),e.on(`displayerror`,r)}),a=()=>r(Error(`Reader closed before chapter rendering completed.`));Ee.signal.addEventListener(`abort`,a,{once:!0});try{await Promise.race([e.display(t),i])}finally{clearTimeout(n),e.off(`displayerror`,r),Ee.signal.removeEventListener(`abort`,a)}}function tt(){c(b)&&_.applyTheme(c(b).id,{...c(b).accessibility,theme:c(b).accessibility.theme??`adaptive`})}async function nt(e){if(!c(b)||Y)return;let t=c(w)===`best-fit`&&!await _.supportsBestFit(c(b).id)?`spread`:c(w);if(Y)return;We();let n=_.attachRenderer(c(b).id,q,t);J=n,Ze(n),await n.started,!(Y||n!==J)&&(n.spread(t===`spread`?`auto`:`none`,1e3),tt(),await et(n,e),Ue(n))}async function it(){try{s(w,ze(),!0);let e=new URLSearchParams(window.location.search).get(`id`),t=e?null:fe(),n;if(n=e?await p.getBook(e):t?await pe(t):await me(),!n)throw Error(`The selected book was not found in your library.`);if(Y)return;s(b,n,!0),v.applyBookRecord(n);let r=await _.loadBook(n.id,n.opfsPath);try{s(te,await _.getActivityCapability(n.id),!0),s(G,await _.getExtensionCapability(n.id),!0)}catch(e){console.error(`[Reader] Invalid publication extension declaration:`,e),s(W,`Book enhancements unavailable: ${e instanceof Error?e.message:String(e)}`)}if(s(x,await _.getChapters(n.id),!0),Y||(r.locations.length()===0&&await r.locations.generate(1e3),Y)||(s(C,Math.max(0,Math.min(n.currentLocation?.chapterIndex??0,c(x).length-1)),!0),s(I,!0),await nt(n.currentLocation?.cfiFragment??(n.currentLocation?c(x)[c(C)]?.href:void 0)??0),Y))return;n.currentLocation&&(_e=setTimeout(Z,2e3)),Ye()}catch(e){Y||X(`reader-init`,e)}finally{Y||(s(R,!1),s(L,!1))}}async function at(e){if(c(R)||!J||e===c(w))return;let t=J.currentLocation()?.start.cfi??c(b)?.currentLocation?.cfiFragment??0;s(R,!0),he=!0,s(w,e,!0);try{localStorage.setItem(l,e),await nt(t)}catch(e){X(`reading-view`,e)}finally{he=!1,s(R,!1),J&&Ue(J)}}function Z(){clearTimeout(_e),s(I,!1)}async function ct(e){let t=J;if(!t||c(R)||c(z))return;if(c(I)){e===1&&Z();return}let n=t.currentLocation();if(e===-1&&n?.atStart){s(I,!0);return}if(!(e===1&&n?.atEnd)){s(R,!0);try{e===1?await t.next():await t.prev(),Ue(t)}catch(e){X(`page-navigation`,e)}finally{s(R,!1)}}}async function ut(e){let t=c(x)[e],n=J;if(!(!t||!n||c(R))){s(R,!0),Z();try{await et(n,t.href??t.spineIndex),s(C,e,!0),Ue(n)}catch(e){X(`chapter-navigation`,e)}finally{s(R,!1)}}}async function dt(e){let t=J;if(!(!c(b)||!t||c(R)||c(z)||!c(x).length))try{let n=t.currentLocation();if(!n)throw Error(`Reading position is not ready for chapter navigation.`);let r=_.getChapterPosition(c(b).id,c(x),n,c(C)),i=e===1?r.chapterIndex+1:r.atBeginning?r.chapterIndex-1:r.chapterIndex;for(;i>=0&&i<c(x).length&&c(x)[i].spineIndex<0;)i+=e;i>=0&&i<c(x).length&&await ut(i)}catch(e){X(`chapter-navigation`,e)}}async function Ct(e){let t=J;if(!(!c(b)||!t||c(R)||c(z))){s(R,!0);try{let n=_.getCfiFromPercentage(c(b).id,e/100);Z(),await et(t,n),Ue(t)}catch(e){X(`position-navigation`,e)}finally{s(R,!1)}}}async function wt(e,t){let n=J;if(!c(b)||!n||c(R))return;let r=n.currentLocation()?.start.cfi??0;s(b,{...c(b),accessibility:{...c(b).accessibility,[e]:Math.min(2,Math.max(e===`fontSize`?.75:1,Math.round((c(b).accessibility[e]+t)*100)/100))}},!0),s(R,!0),he=!0;try{n.clear(),tt(),await et(n,r)}catch(e){X(`typography`,e)}finally{he=!1,s(R,!1),Ue(n),Ve()}}function Tt(e){!c(b)||c(R)||(s(b,{...c(b),accessibility:{...c(b).accessibility,theme:e}},!0),tt(),Ve())}async function Et(){clearTimeout(ve),await Be(),c(U)||await B(`${V}/start/library`)}function Dt(e){Se=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`),(Se||Ke(e.target))&&clearTimeout(ge),be=e.clientX,xe=e.clientY}function Ot(e){if(c(F)&&(Se||Ke(e.target))&&Ye(),Ke(e.target)||Math.hypot(e.clientX-be,e.clientY-xe)>10)return;let t=e.target instanceof Element&&!!e.target.closest(`.reading-header, .reading-footer`);if(Se||t){Se&&t&&!c(F)&&Je();return}Xe(e.clientX,e.clientY)}function kt(){c(F)&&Ye(),Se=!1}function At(e){c(I)&&e.deltaY>0&&(e.preventDefault(),Z())}M(()=>{let e=navigator.userAgent;/\bVersion\/[\d.]+.*\bSafari\//.test(e)&&!/\b(?:Chrome|Chromium|CriOS|FxiOS|Edg|EdgiOS|EdgA|OPR|OPiOS|DuckDuckGo)\//i.test(e)&&Re.showModal(),window.addEventListener(`keydown`,qe);let t=new ResizeObserver(()=>{cancelAnimationFrame(ye),ye=requestAnimationFrame(()=>{if(!J||c(R)||Y||!q.clientWidth||!q.clientHeight)return;let e=J.currentLocation()?.start.cfi;J.resize(q.clientWidth,q.clientHeight,e)})});return t.observe(q),it(),()=>{Y=!0,Ee.abort(),t.disconnect(),cancelAnimationFrame(ye),window.removeEventListener(`keydown`,qe),clearTimeout(ge),clearTimeout(_e),clearTimeout(ve),Be(),We(),c(b)&&_.detachRenderer(c(b).id),J=null}});var jt=St(),Q=m(jt);let Mt;var Nt=a(Q);k(Nt,e=>Re=e,()=>Re);var Pt=h(Nt,2),Ft=e=>{rt(e,{get capability(){return c(G)},onready:e=>{s(ie,e,!0)}})};y(Pt,e=>{c(G)&&!c(L)&&!c(I)&&e(Ft)});var It=h(Pt,2),Lt=e=>{{let t=g(()=>v.appName||c(b).title||c(b).filename),n=g(()=>c(Ae)?.chapterTitle??c(ke)?.label),r=g(()=>c(b).accessibility.theme??`adaptive`);we(e,{get bookTitle(){return c(t)},get chapterTitle(){return c(n)},get controlsVisible(){return c(F)},get readerTheme(){return c(r)},get displayMode(){return c(w)},get busy(){return c(R)},onDisplayModeChange:at,onReaderThemeChange:Tt,onClose:Et,get onFeatures(){return c(ie)}})}};y(It,e=>{c(b)&&e(Lt)});var $=h(It,2),Rt=a($),zt=e=>{n(e,mt())},Bt=e=>{var t=ht(),r=h(a(t),2),i=a(r,!0);N(r);var o=h(r,2);N(t),d(()=>f(i,c(z))),T(`click`,o,()=>B(`${V}/start/library`)),n(e,t)},Vt=e=>{var t=yt(),r=a(t),i=a(r),o=e=>{var t=gt();d(()=>E(t,`src`,c(b).coverImage)),n(e,t)},s=e=>{var t=vt(),r=a(t),i=a(r,!0);N(r);var o=h(r,2),s=e=>{var t=_t(),r=a(t,!0);N(t),d(()=>f(r,c(b).author)),n(e,t)};y(o,e=>{c(b).author&&e(s)}),N(t),d(()=>f(i,c(b).title??c(b).filename)),n(e,t)};y(i,e=>{c(b).coverImage?e(o):e(s,-1)}),N(r),N(t),d(()=>E(r,`aria-label`,`Cover for ${c(b).title??c(b).filename}`)),T(`click`,t,Z),n(e,t)};y(Rt,e=>{c(L)?e(zt):c(z)?e(Bt,1):c(I)&&c(b)&&e(Vt,2)});var Ht=h(Rt,2),Ut=e=>{var t=bt(),r=a(t,!0);N(t),d(()=>f(r,c(U))),n(e,t)};y(Ht,e=>{c(U)&&e(Ut)});var Wt=h(Ht,2),Gt=e=>{var t=bt(),r=a(t,!0);N(t),d(()=>f(r,c(W))),n(e,t)};y(Wt,e=>{c(W)&&e(Gt)});var Kt=h(Wt,2),qt=e=>{var t=xt(),r=m(t);let i;var a=h(r,2);let o;d(()=>{i=D(r,1,`page-turn-zone previous svelte-1jg2usx`,null,i,{activity:c(je)===`activity`}),o=D(a,1,`page-turn-zone next svelte-1jg2usx`,null,o,{activity:c(je)===`activity`})}),n(e,t)};y(Kt,e=>{c(je)&&e(qt)}),N($),k($,e=>q=e,()=>q);var Jt=h($,2),Yt=e=>{{let t=g(()=>c(ke)?.label??`Front matter`);Pe(e,{get controlsVisible(){return c(F)},get fontSize(){return c(b).accessibility.fontSize},get lineHeight(){return c(b).accessibility.lineHeight},get progressPercent(){return c(Ne)},get currentChapterIndex(){return c(C)},get totalChapters(){return c(x).length},get chapterPositionLabel(){return c(t)},get pageLabel(){return c(Ie)},get progressLabel(){return c(Le)},get chapters(){return c(x)},get busy(){return c(R)},onFontSizeIncrease:()=>wt(`fontSize`,.1),onFontSizeDecrease:()=>wt(`fontSize`,-.1),onLineHeightIncrease:()=>wt(`lineHeight`,.1),onLineHeightDecrease:()=>wt(`lineHeight`,-.1),onProgressChange:Ct,onChapterSelect:ut})}};y(Jt,e=>{c(b)&&e(Yt)}),N(Q);var Xt=h(Q,2),Zt=e=>{Qe(e,{get activity(){return c(Me)}})};y(Xt,e=>{c(Me)&&e(Zt)}),d(()=>{Mt=D(Q,1,`reader-shell svelte-1jg2usx`,null,Mt,{"show-ui":c(F)}),A(Q,`--reader-page-bg: ${c(Fe).background}; --reader-page-fg: ${c(Fe).foreground}; --reader-page-muted: ${c(Fe).muted}; --reader-page-accent: ${c(Fe).accent}; --reader-page-border: ${c(Fe).border};`),E($,`aria-busy`,c(R)),E($,`data-display-mode`,c(w)),E($,`data-start-cfi`,c(O)?.start.cfi),E($,`data-end-cfi`,c(O)?.end.cfi),E($,`data-spine-index`,c(O)?.start.index),E($,`data-page`,c(O)?.start.displayed.page),E($,`data-total-pages`,c(O)?.start.displayed.total),E($,`data-visible-pages`,c(P))}),T(`pointerdown`,Q,Dt),T(`pointerup`,Q,Ot),t(`pointercancel`,Q,kt),t(`wheel`,Q,At),T(`pointerdown`,Nt,e=>e.stopPropagation()),T(`pointerup`,Nt,e=>e.stopPropagation()),n(r,jt),e()}l([`pointerdown`,`pointerup`,`click`]);export{Ct as component,he as universal};